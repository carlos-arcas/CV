"""Helpers compartidos de ClinicDesk."""
