"""Shared dialogs and helpers for page-level UI."""
