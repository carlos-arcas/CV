from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from PySide6.QtCore import QDate, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QWidget,
)

from clinicdesk.app.domain.enums import TipoDocumento
from clinicdesk.app.domain.exceptions import ValidationError
from clinicdesk.app.domain.modelos import Medico
from clinicdesk.app.ui.error_presenter import present_error
from clinicdesk.app.ui.label_utils import required_label


@dataclass(slots=True)
class MedicoFormData:
    medico: Medico


class MedicoFormDialog(QDialog):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Médico")
        self._medico_id: Optional[int] = None

        self.cbo_tipo_documento = QComboBox()
        self.cbo_tipo_documento.addItems([t.value for t in TipoDocumento])

        self.txt_documento = QLineEdit()
        self.txt_nombre = QLineEdit()
        self.txt_apellidos = QLineEdit()
        self.txt_telefono = QLineEdit()
        self.txt_email = QLineEdit()
        self.date_fecha_nacimiento = QDateEdit()
        self.date_fecha_nacimiento.setDisplayFormat("yyyy-MM-dd")
        self.date_fecha_nacimiento.setCalendarPopup(True)
        self.date_fecha_nacimiento.setDate(QDate.currentDate())
        self.chk_sin_fecha = QCheckBox("Sin fecha")
        self.chk_sin_fecha.setChecked(True)
        self.chk_sin_fecha.toggled.connect(self._toggle_fecha_nacimiento)
        self._toggle_fecha_nacimiento(True)
        self.txt_direccion = QLineEdit()
        self.txt_num_colegiado = QLineEdit()
        self.txt_especialidad = QLineEdit()
        self.chk_activo = QCheckBox("Activo")
        self.chk_activo.setChecked(True)

        form = QFormLayout()
        form.addRow(required_label("Tipo documento"), self.cbo_tipo_documento)
        form.addRow(required_label("Documento"), self.txt_documento)
        form.addRow(required_label("Nombre"), self.txt_nombre)
        form.addRow(required_label("Apellidos"), self.txt_apellidos)
        form.addRow("Teléfono", self.txt_telefono)
        form.addRow("Email", self.txt_email)
        fecha_layout = QHBoxLayout()
        fecha_layout.addWidget(self.date_fecha_nacimiento)
        fecha_layout.addWidget(self.chk_sin_fecha)
        fecha_widget = QWidget()
        fecha_widget.setLayout(fecha_layout)
        form.addRow("Fecha nacimiento", fecha_widget)
        form.addRow("Dirección", self.txt_direccion)
        form.addRow(required_label("Nº colegiado"), self.txt_num_colegiado)
        form.addRow(required_label("Especialidad"), self.txt_especialidad)
        form.addRow("", self.chk_activo)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("Guardar")
        buttons.button(QDialogButtonBox.Cancel).setText("Cancelar")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QFormLayout(self)
        layout.addRow(form)
        layout.addRow(buttons)

    def set_medico(self, medico: Medico) -> None:
        self._medico_id = medico.id
        self.cbo_tipo_documento.setCurrentText(medico.tipo_documento.value)
        self.txt_documento.setText(medico.documento)
        self.txt_nombre.setText(medico.nombre)
        self.txt_apellidos.setText(medico.apellidos)
        self.txt_telefono.setText(medico.telefono or "")
        self.txt_email.setText(medico.email or "")
        if medico.fecha_nacimiento:
            self.date_fecha_nacimiento.setDate(
                QDate(
                    medico.fecha_nacimiento.year,
                    medico.fecha_nacimiento.month,
                    medico.fecha_nacimiento.day,
                )
            )
            self.chk_sin_fecha.setChecked(False)
        else:
            self.chk_sin_fecha.setChecked(True)
        self.txt_direccion.setText(medico.direccion or "")
        self.txt_num_colegiado.setText(medico.num_colegiado)
        self.txt_especialidad.setText(medico.especialidad)
        self.chk_activo.setChecked(medico.activo)

    def get_data(self) -> Optional[MedicoFormData]:
        try:
            fecha_dt = None
            if not self.chk_sin_fecha.isChecked():
                fecha_dt = self.date_fecha_nacimiento.date().toPython()

            medico = Medico(
                id=self._medico_id,
                tipo_documento=TipoDocumento(self.cbo_tipo_documento.currentText()),
                documento=self.txt_documento.text().strip(),
                nombre=self.txt_nombre.text().strip(),
                apellidos=self.txt_apellidos.text().strip(),
                telefono=self.txt_telefono.text().strip() or None,
                email=self.txt_email.text().strip() or None,
                fecha_nacimiento=fecha_dt,
                direccion=self.txt_direccion.text().strip() or None,
                activo=self.chk_activo.isChecked(),
                num_colegiado=self.txt_num_colegiado.text().strip(),
                especialidad=self.txt_especialidad.text().strip(),
            )
            medico.validar()
        except (ValueError, ValidationError) as exc:
            self._highlight_for_error(exc)
            present_error(self, exc)
            return None

        return MedicoFormData(medico=medico)

    def _toggle_fecha_nacimiento(self, checked: bool) -> None:
        self.date_fecha_nacimiento.setEnabled(not checked)

    def _mark_invalid(self, widget: QWidget) -> None:
        widget.setStyleSheet("border: 1px solid #d9534f;")
        QTimer.singleShot(2500, lambda: widget.setStyleSheet(""))

    def _highlight_for_error(self, exc: Exception) -> None:
        message = str(exc).lower()
        if "documento" in message:
            self._mark_invalid(self.txt_documento)
        elif "nombre" in message and "apellidos" not in message:
            self._mark_invalid(self.txt_nombre)
        elif "apellidos" in message:
            self._mark_invalid(self.txt_apellidos)
        elif "teléfono" in message or "telefono" in message:
            self._mark_invalid(self.txt_telefono)
        elif "email" in message:
            self._mark_invalid(self.txt_email)
        elif "fecha" in message:
            self._mark_invalid(self.date_fecha_nacimiento)
