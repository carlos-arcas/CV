from __future__ import annotations


def required_label(label: str) -> str:
    return f"{label} *"
