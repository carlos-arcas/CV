DROP INDEX IF EXISTS ux_solicitudes_uuid;
DROP INDEX IF EXISTS ux_personas_uuid;
