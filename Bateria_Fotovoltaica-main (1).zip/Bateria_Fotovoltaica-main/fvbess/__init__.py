"""FV+BESS package."""

from infrastructure.version import __version__

__all__ = ["__version__"]
