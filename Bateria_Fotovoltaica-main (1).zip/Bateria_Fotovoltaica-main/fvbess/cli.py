"""CLI estable para FV+BESS."""

from __future__ import annotations

import argparse

from cli.benchmark_cli import benchmark_project
from cli.project_cli import batch_run_project, cache_clear_project, init_project, run_project, show_project


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fvbess")
    parser.add_argument("--debug", action="store_true", help="Activa modo debug y dump de errores.")
    parser.add_argument("--export-detail", action="store_true", help="Calcula/exporta detalle por periodo.")
    parser.add_argument("--no-cache", action="store_true", help="Desactiva cache de simulaciones.")

    subparsers = parser.add_subparsers(dest="command")
    project_parser = subparsers.add_parser("project", help="Comandos de gestión de proyectos")
    project_subparsers = project_parser.add_subparsers(dest="project_command")

    project_init = project_subparsers.add_parser("init", help="Inicializa la estructura de un proyecto")
    project_init.add_argument("project_dir", help="Ruta del proyecto")

    project_show = project_subparsers.add_parser("show", help="Muestra la configuración del proyecto")
    project_show.add_argument("project_dir", help="Ruta del proyecto")

    project_run = project_subparsers.add_parser("run", help="Ejecuta una simulación única usando project.json")
    project_run.add_argument("project_dir", help="Ruta del proyecto")
    project_run.add_argument("--fast", action="store_true", help="Activa modo rápido agregado")
    project_run.add_argument("--export-detail", action="store_true", help="Exporta detalle horario completo")
    project_run.add_argument("--no-executive", action="store_true", help="Desactiva el resumen ejecutivo")
    project_run.add_argument("--no-cache", action="store_true", help="Ignora cache y fuerza recálculo")

    project_batch = project_subparsers.add_parser("batch-run", help="Ejecuta batch drop & run en un proyecto")
    project_batch.add_argument("project_dir", help="Ruta del proyecto")
    project_batch.add_argument("--pattern", default="*.xlsx,*.csv", help="Patrones glob separados por coma")
    project_batch.add_argument("--overwrite", action="store_true", help="Reprocesa aunque exista salida previa")
    project_batch.add_argument("--workers", type=int, default=1, help="Número de workers concurrentes")
    project_batch.add_argument("--strict", action="store_true", help="Trata warnings de validación como error")
    project_batch.add_argument("--fast", action="store_true", help="Activa modo rápido agregado")
    project_batch.add_argument("--export-detail", action="store_true", help="Exporta detalle horario completo")
    project_batch.add_argument("--grid", action="store_true", help="Activa barrido de configuraciones desde battery_grid.json")
    project_batch.add_argument("--capacities", default="", help="Lista CSV de capacidades kWh (ej: 5,10,15)")
    project_batch.add_argument("--powers", default="", help="Lista CSV de potencias kW (ej: 3,5)")
    project_batch.add_argument("--metric", default="roi", choices=["roi", "npv", "savings", "irr", "payback"], help="Métrica de ranking")
    project_batch.add_argument("--top", type=int, default=3, help="Top N a mostrar en consola")
    project_batch.add_argument("--force-grid", action="store_true", help="Permite ejecutar grids >100 variantes")
    project_batch.add_argument("--no-executive", action="store_true", help="Desactiva el resumen ejecutivo")
    project_batch.add_argument("--no-cache", action="store_true", help="Ignora cache y fuerza recálculo")

    project_cache_clear = project_subparsers.add_parser("cache-clear", help="Elimina cache del proyecto")
    project_cache_clear.add_argument("project_dir", help="Ruta del proyecto")

    benchmark_parser = subparsers.add_parser("benchmark", help="Ejecuta benchmark del motor FV+BESS")
    benchmark_parser.add_argument("project_dir", help="Ruta del proyecto")
    benchmark_parser.add_argument("--runs", type=int, default=5, help="Número de ejecuciones para promediar")
    benchmark_parser.add_argument("--fast", action="store_true", help="Benchmark solo en modo FAST")
    benchmark_parser.add_argument("--grid", action="store_true", help="Evalúa el grid completo de baterías")
    benchmark_parser.add_argument("--workers", type=int, default=1, help="Workers para benchmark en grid")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "project":
        if args.project_command == "init":
            return init_project(args.project_dir)
        if args.project_command == "show":
            return show_project(args.project_dir)
        if args.project_command == "run":
            return run_project(
                args.project_dir,
                fast=args.fast,
                export_detail=args.export_detail,
                include_executive=not args.no_executive,
                no_cache=args.no_cache,
            )
        if args.project_command == "batch-run":
            return batch_run_project(
                args.project_dir,
                pattern=args.pattern,
                overwrite=args.overwrite,
                workers=args.workers,
                strict=args.strict,
                fast=args.fast,
                export_detail=args.export_detail,
                use_grid=args.grid,
                capacities=args.capacities,
                powers=args.powers,
                metric=args.metric,
                top_n=args.top,
                force_grid=args.force_grid,
                include_executive=not args.no_executive,
                no_cache=args.no_cache,
            )
        if args.project_command == "cache-clear":
            return cache_clear_project(args.project_dir)
        parser.error("Debes indicar un subcomando de proyecto: init | show | run | batch-run | cache-clear")

    if args.command == "benchmark":
        return benchmark_project(
            args.project_dir,
            runs=args.runs,
            fast=args.fast,
            use_grid=args.grid,
            workers=args.workers,
        )

    from ui.main import run_ui

    return run_ui(debug=args.debug, export_detail=args.export_detail, no_cache=args.no_cache)
