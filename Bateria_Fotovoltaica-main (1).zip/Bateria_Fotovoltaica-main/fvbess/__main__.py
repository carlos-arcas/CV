from .cli import main

raise SystemExit(main())
