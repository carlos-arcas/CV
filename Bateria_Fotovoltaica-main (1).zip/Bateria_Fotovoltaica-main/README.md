# Simulador BESS/FV

Implementación en Python 3.11+ con PySide6 y Clean Architecture para simular operación anual de batería/FV.

## Estructura

- `domain/`: modelos y errores de dominio.
- `application/`: DTOs, casos de uso, motor óptimo y flujo de imitación ML.
- `infrastructure/`: carga de archivos, validaciones/normalización, exportación y model store ML.
- `ui/`: ventana principal, páginas y viewmodel compartido.
- `fvbess/`: paquete instalable con CLI estable y entrypoint (`fvbess`).
- `main.py`: wrapper legacy compatible con ejecución histórica.

## Requisitos

- Python 3.11 o superior.
- Dependencias definidas en `requirements.txt`.
- Windows 10/11 compatible con launcher por doble click.

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate  # En Windows: .venv\Scripts\activate
pip install -e .
```

Instalación para desarrollo/test:

```bash
pip install -r requirements-dev.txt
```

Compatibilidad legacy: `python main.py ...` sigue disponible y delega al mismo CLI.

## Testing & Coverage

### Estructura de tests

```text
tests/
  unit/         # lógica pura y validaciones deterministas
  integration/  # flujos entre casos de uso/motor sin UI
  performance/  # checks básicos de rendimiento relativo
```

### Cómo ejecutar tests

```bash
pytest
```

`pytest.ini` ya apunta a `tests/` y usa salida resumida (`-ra -q`).

### Cómo medir cobertura

```bash
pytest --cov=application --cov=infrastructure --cov-report=term-missing
```

Objetivo práctico: mínimo 70% en módulos críticos (`finance`, `dataset_validator`, `cache`, motor principal).

### Filosofía de testing

- **Unit**: tests pequeños, rápidos y sin IO pesado; validan comportamiento de funciones puras y reglas de negocio.
- **Integration**: validan que los casos de uso encadenados devuelven KPIs y artefactos esperados con datasets sintéticos.
- **Performance**: validan tendencias (FAST vs detallado) y umbrales razonables para datasets pequeños, sin benchmarking absoluto.

Esta estructura deja el repositorio listo para conectar fácilmente un futuro workflow de CI en `.github/workflows/test.yml`.

## Cómo ejecutar (Windows, doble click)

1. Haz doble click en **`00_EJECUTAR_SIMULADOR.bat`** (único punto de entrada para usuario final).
2. El launcher detecta Python (`py -3`, `py`, `python` o rutas típicas de Windows), crea `.venv`, actualiza `pip` e instala `requirements.txt`.
3. Después ejecuta el simulador con `main.py` usando siempre `.venv\Scripts\python.exe`.
4. Si hay un problema, revisa consola y `logs/launcher.log` (el launcher no se cierra en error).

> Nota: si no tienes Python instalado, el launcher muestra instrucciones para instalar Python 3.11+ y/o Python Launcher (`py.exe`) y volver a ejecutar el BAT.

## Flujo recomendado (1 año por cliente)

- Carga **1 archivo anual** (página Datos).
- Ejecuta **Óptimo (recomendado)** como simulación base/final.
- Usa **Dimensionamiento** para barrido y recomendación de tamaño.
- Exporta informe final en Excel.
- **ML queda como opción experimental** para acelerar barridos masivos o portfolio.

## Teacher → Student (Imitation Learning)

- **Teacher**: simulador óptimo (LP) genera decisiones por periodo.
- **Student**: modelos supervisados (clasificación y regresión) aprenden a imitar esas decisiones.
- **Objetivo**: acelerar simulaciones masivas/barridos de escenarios con una aproximación rápida.

### Cuándo usar ML

- Solo para aceleración en barridos masivos o portfolio multi-cliente.
- No como flujo principal para un único cliente/año.

### Limitaciones

- ML aproxima la política óptima; puede perder ahorro frente al solver exacto.
- El modo óptimo sigue siendo el benchmark de referencia para validación final.

## Comandos/flujos ML

### 1) Generar dataset de imitación

Desde UI: **Escenario → Generar dataset**.

Programáticamente:

```python
from application.use_cases import GenerateDatasetUseCase
# uc.execute(input_dto, scenario, "imitation_dataset.csv")
```


### Entrenamiento multi-año (sin data leakage)

Ahora puedes seleccionar **N archivos** (CSV/XLSX), uno por año, desde **Datos → Añadir años**. El pipeline:

1. Normaliza cada archivo a 15 minutos de forma independiente.
2. Genera dataset de imitación por año usando el teacher óptimo.
3. Concatena todos los años en un único dataset multi-año.
4. Entrena separando **train/test por años** (ejemplo: train `2022-2024`, test `2025`).

Ejemplo rápido desde UI:
- Carga `2022.xlsx`, `2023.xlsx`, `2024.xlsx` y `2025.xlsx` con **Añadir años**.
- Ve a **Escenario → Generar dataset** para producir `dataset_multi.parquet`.
- En **Años de test** escribe `2025`.
- Pulsa **Entrenar**.

El `metadata.json` del modelo guarda:
- `years_used`
- `total_rows`
- `metrics` globales
- `metrics_by_year`
- `test_years`

### 2) Entrenar imitador

Desde UI: **Escenario → Entrenar**.

Programáticamente:

```python
from application.use_cases import TrainImitatorUseCase
# uc.execute(dataset_df, "model_imitator.pkl", mode="classification")
```

### 3) Simular ML (rápido)

Desde UI: **Simulación → Simular ML (rápido)**.

Programáticamente:

```python
from application.use_cases import RunSimulationFastUseCase
# uc.execute(input_dto, scenario, "model_imitator.pkl")
```

### 4) Comparar óptimo vs ML

Desde UI: **Simulación → Comparar**.

Programáticamente:

```python
from application.use_cases import CompareSimulationsUseCase
# uc.execute(input_dto, scenario, "model_imitator.pkl")
```


## Uso interno en 5 minutos (ventas/ingeniería)

1. **Datos**: carga un único Excel/CSV anual (consumo + FV opcional + precios).
2. **Escenario**: configura batería, red y tarifa.
3. **Simulación**: ejecuta **Óptimo (LP diario)** como fuente de verdad.
4. **Dimensionamiento**: ejecuta barrido capacidad/potencia en modo rápido o completo y revisa la recomendación automática (`max_savings`, `max_savings_per_eur`, `min_payback`).
5. **Exportar**: desde Simulación exporta Excel con hojas:
   - `Resumen Ejecutivo`
   - `KPIs`
   - `Mensual`
   - `Dimensioning`
   - `Supuestos y límites`
   - `Detalle periodos` (solo si marcas exportado detallado).

## Export Profesional

El sistema genera por defecto un **Resumen Ejecutivo** adicional al export técnico tradicional.

### Qué incluye el resumen ejecutivo

- **Resumen clave**: ahorro anual, VAN, TIR, payback, ROI, energía gestionada por batería y % de autoconsumo.
- **Datos técnicos**: capacidad, potencia, vida útil, CAPEX, OPEX y tasa de descuento.
- **Comparativa** (si existe baseline con/sin batería): ahorro incremental y mejora de autoconsumo.
- En batch, se añade un fichero por cliente (`<cliente>__executive_summary.xlsx`) con tabla **Top 3 configuraciones**.

### Para qué sirve

- Compartir resultados con cliente final, comercial y dirección sin exponer tablas técnicas de cientos de columnas.
- Facilitar decisión comercial en reuniones y propuestas.

### Diferencia entre export técnico y ejecutivo

- **Export técnico**: detalle completo de KPIs y periodos (si se activa `--export-detail`).
- **Export ejecutivo**: hoja limpia en formato vertical `Métrica | Valor`, pensada para lectura de negocio.

### CLI

- Activado por defecto en `project run` y `project batch-run`.
- Puedes desactivarlo con `--no-executive`.


## Modo Comercial

La UI incluye un asistente visual de **5 pasos** orientado a comerciales no técnicos.

### Guía rápida (5 pasos)

1. **Cargar Datos**: selecciona Excel/CSV y valida año, registros y si hay FV.
2. **Configuración Básica**: define capacidad, potencia, venta a red y potencia contratada opcional.
3. **Simulación**: pulsa **Calcular Ahorro Óptimo** y espera el progreso diario.
4. **Resultados Visuales**: revisa KPIs clave y curvas simples de ahorro/SoC.
5. **Oferta Comercial**: ajusta coste, plazo y margen para obtener cuota y rentabilidad.

El modo comercial evita exponer parámetros avanzados por defecto, aplica validaciones fuertes y mantiene la lógica de negocio en UseCases.

## Modo Presentación Cliente

Se añadió un dashboard ejecutivo pensado para reuniones comerciales en pantalla grande.

### Cómo usarlo

1. Ejecuta una simulación y entra en **Resultados Visuales**.
2. Pulsa el botón **Modo Presentación**.
3. Se abrirá una ventana fullscreen con solo métricas clave y gráficos limpios.
4. Para salir, pulsa **ESC** o **Volver**.

### Qué muestra

- Título ejecutivo con año analizado.
- Ahorro anual estimado con contador animado.
- KPIs de ahorro mensual, reducción de factura y autoconsumo.
- Gráfico de ahorro mensual.
- Gráfico de cashflow acumulado (si hay datos financieros, se priorizan esos valores).
- Tarjeta de batería recomendada (capacidad, potencia, payback y cuota si hay renting).

### Recomendaciones en reunión

- Usa una pantalla externa o TV para maximizar legibilidad.
- Navega desde esta vista para explicar valor de negocio sin entrar en parámetros técnicos.
- Calcula la oferta previamente para completar payback y cuota en la tarjeta recomendada.


## Validación de dataset (pre-simulación)

Antes de normalizar/simular, el sistema genera un informe con:
- **ERRORES** (bloquean ejecución).
- **WARNINGS** (permiten continuar).
- **STATS** (rango temporal, timestep detectado, NaN por columna, min/max/mediana).

En CLI batch puedes endurecer la validación:

```bash
fvbess project batch-run <project_dir> --strict
```

Con `--strict`, cualquier warning también bloquea la corrida y devuelve `exit code 3`.

## Ejecución UI

```bash
fvbess
```

## Análisis de dimensionamiento (scenario sweep)

La app incluye una página **Dimensionamiento** para recomendar automáticamente el tamaño de batería.

Flujo recomendado:
1. Cargar y validar un año real (página Datos).
2. Simular en modo óptimo (página Simulación).
3. Ejecutar barrido de capacidad/potencia en la página Dimensionamiento en modo LP recomendado.
4. (Opcional) usar ML experimental solo para acelerar mallas grandes.
5. Exportar informe profesional (`outputs/dimensioning_report.xlsx`) con tablas y PNG.

### Qué configura el usuario

- Rango de capacidad (`min`, `max`, `paso`) en kWh.
- Rango de potencia (`min`, `max`, `paso`) en kW.
- Modo de simulación:
  - `Óptimo (recomendado)`: solver exacto LP.
  - `ML (aceleración) [experimental]`: requiere entrenamiento y puede aproximar.

- Tipo de barrido:
  - `Barrido rápido LP`: sin guardar periodos completos (más veloz).
  - `Barrido exhaustivo (top-N)`: conserva periodos completos de los mejores escenarios.
- Parámetros financieros: CAPEX por kWh, CAPEX por kW, vida útil y tasa de descuento.
- Criterio de recomendación automática:
  - máximo ahorro absoluto,
  - máximo ahorro/€ invertido,
  - mínimo payback.

### Diferencias óptimo vs ML

- **Óptimo**: referencia técnica para decisión final, más lento.
- **ML**: aproximación de alta velocidad para explorar muchas combinaciones.

Tiempos típicos esperados:
- **Óptimo**: segundos a minutos según tamaño de la malla de barrido.
- **ML**: casi instantáneo una vez entrenado el modelo.

## Persistencia profesional de proyectos

La aplicación ahora permite gestionar proyectos completos desde **Archivo → Nuevo Proyecto / Abrir Proyecto / Guardar Proyecto**.

### Qué se guarda

En la carpeta del proyecto:

- `project.json`: configuración general del proyecto.
  - ruta de datos (`data_path`)
  - rutas de exportación (`export_folder`)
  - ruta de modelos (`model_folder`)
  - metadata de versión (`app_version`, `schema_version`)
- `scenario.json`: parámetros de escenario (batería/red/tarifa).
- `results_cache.parquet` (opcional): cache de resultados de simulación.
- `models/<nombre>/` (cuando entrenas/guardas modelos):
  - `action_model.joblib`
  - `charge_model.joblib`
  - `discharge_model.joblib`
  - `metadata.json`

### Dónde se guarda

- Puedes elegir cualquier carpeta desde el selector de **Guardar Proyecto**.
- Para modelos ML, selecciona una carpeta en el panel **Escenario → Seleccionar carpeta de modelos**.

### Cómo mover un proyecto a otro PC

1. Copia la carpeta completa del proyecto (incluyendo `project.json`, `scenario.json`, `results_cache.parquet` y carpeta `models/` si existe).
2. En el otro PC, abre la app y usa **Archivo → Abrir Proyecto** sobre esa carpeta.
3. Si la ruta de datos original cambió, vuelve a cargar el dataset manualmente en la página **Datos**.

### Compatibilidad y seguridad

- Se guarda `schema_version` y se aplica migración ligera si se detecta un esquema antiguo.
- Si la versión de app difiere, la carga muestra warning e intenta compatibilidad hacia atrás.
- Se prioriza `joblib` para serialización de modelos.
- Fallback: si no hay `joblib`, se usa `pickle` (solo para artefactos confiables; `pickle` puede ejecutar código al deserializar).
- Si no tienes stack ML instalado, el proyecto sigue cargando y el modo óptimo continúa disponible.


## Modo Batch (Drop & Run)

Flujo pensado para usuario no técnico dentro de un proyecto:

1. Copia archivos Excel/CSV a `./projects/<mi_proyecto>/batches/input/`.
2. Ejecuta `fvbess project batch-run ./projects/<mi_proyecto>`.
3. Recoge resultados en `./projects/<mi_proyecto>/batches/output/`.

Comandos base:

```bash
fvbess project init ./projects/comercial_2026
fvbess project batch-run ./projects/comercial_2026 --workers 4
```

Qué hace `batch-run`:
- Carga `project.json` y `scenario.json` del proyecto.
- Ejecuta una simulación por cada archivo de `batches/input/`.
- Si no hay grid, usa la batería del escenario (1 variante).
- Si activas grid (`--grid` o `--capacities/--powers`), ejecuta producto cartesiano multi-batería por cliente.
- Exporta resultados individuales por variante en `batches/output/<cliente>__<variant_id>__result.xlsx`.
- Exporta ranking por cliente en `batches/output/<cliente>__ranking.xlsx` (o CSV fallback).
- Exporta ranking global en `batches/output/__global_ranking.xlsx` (o CSV fallback).
- Genera manifest por variante en `batches/_runs/<run_id>/<cliente>/<variant_id>.manifest.json` con `input_hash` y `scenario_hash` para reproducibilidad.
- Guarda traceback por fallo en `batches/logs/<run_id>/<cliente>__<variant_id>.log`.
- Archiva entradas procesadas en `batches/archive/<run_id>/` para evitar reprocesado accidental.


Ejemplo de `battery_grid.json` (opcional en la raíz del proyecto):

```json
{
  "capacities_kwh": [5, 10, 15],
  "powers_kw": [3, 5],
  "roundtrip_efficiency": [0.9],
  "max_c_rate": [1.0],
  "constraints_profile": "default"
}
```

Ejecución con grid:

```bash
fvbess project batch-run ./projects/comercial_2026 --grid --metric roi --top 3
fvbess project batch-run ./projects/comercial_2026 --capacities 5,10,15 --powers 3,5 --metric npv
```

Métricas de ranking soportadas: `roi`, `npv`, `savings`, `irr`, `payback`.
Si una métrica no está disponible en KPIs reales del motor, el ranking cae automáticamente a ahorro (`total_savings_eur`).

Códigos de salida:
- `0`: al menos un job terminó OK.
- `2`: no hay inputs o falta estructura mínima.
- `3`: todos fallaron en validación de dataset.
- `4`: todos fallaron en simulación/procesado.



### Modo FAST para comparativas comerciales

El motor ahora soporta dos niveles:
- **Detallado (óptimo)**: conserva detalle horario completo para auditoría y trazabilidad técnica.
- **FAST (agregado)**: calcula únicamente KPIs ejecutivos sin materializar detalle horario completo.

KPIs principales en FAST:
- Energía cargada/descargada (`energia_cargada_kwh`, `energia_descargada_kwh`).
- Ahorro anual (`total_savings_eur`).
- Autoconsumo (`autoconsumo_pct`).
- Ciclos estimados (`ciclos_estimados`).
- ROI estimado (`ROI_estimado`).

CLI:

```bash
fvbess project run ./projects/comercial_2026 --fast
fvbess project batch-run ./projects/comercial_2026 --fast
```

En modo FAST se exporta por defecto un resumen ejecutivo (`kpis_only`).
Si necesitas detalle horario explícito, añade `--export-detail`.

> **Nota**: Modo FAST está pensado para comparativas rápidas de sizing comercial, no para auditoría energética de precisión forense.

## Interfaz Comercial Premium

La interfaz comercial fue actualizada con una estética **SaaS energética profesional** sin tocar el motor de negocio.

### Diseño modular

- `ui/theme.py`: tokens visuales (paleta, tipografía base y carga de stylesheet).
- `ui/styles.qss`: estilo centralizado para mantener consistencia visual.
- `ui/components/`: componentes reutilizables premium (`kpi_card`, `modern_button`, `toggle_switch`, `numeric_input`).
- `ui/animations.py`: animaciones cortas (fade-in) para transiciones suaves.
- `ui/main_window.py`: layout con sidebar fija + navegación por pasos + bloqueo de flujo.
- `ui/pages/`: páginas comerciales con enfoque visual y claridad ejecutiva.

### Experiencia comercial

- Sidebar con pasos numerados y progreso vertical.
- Resultados con KPI destacados, contador animado de ahorro anual y gráficos premium en matplotlib.
- Bloque de oferta con propuesta recomendada, cuota sugerida y visualización de payback.
- Validaciones visuales inmediatas en inputs y navegación bloqueada hasta completar hitos.

## Robustez empresarial (hardening final)

### Cómo funciona el motor óptimo
- El motor usa optimización LP como fuente de verdad para despacho FV+BESS.
- Antes de simular se valida dataset (columnas requeridas, NaN, no negativos y continuidad temporal).
- Al finalizar se ejecutan validaciones de seguridad de solución (SoC en límites, balances, flujos no negativos y ausencia de NaN).

### Qué garantiza
- Trazabilidad completa por ejecución con `session_id` único.
- Registro explícito de inicio app, carga de dataset, inicio/fin simulación, cache hit/miss, exportaciones y errores.
- Excepciones no capturadas quedan en `logs/crash.log` mediante `sys.excepthook` global.

### Dónde están los logs
- `logs/app.log` (rotación 5 archivos x 5 MB).
- `logs/crash.log` para excepciones inesperadas.
- Formato: `timestamp | level | session_id | module | message`.

### Cómo interpretar el export
- `Resumen Ejecutivo`: versión app, fecha simulación, modo solución, hash dataset y KPIs principales.
- `Resultados Mensuales`: ahorro por mes.
- `Detalle Horario` (opcional): serie horaria (SoC u otras series).
- Escritura atómica (archivo temporal + rename) para evitar ficheros corruptos.

## KPIs financieros del motor FV+BESS

La simulación técnica ahora incorpora KPIs financieros para traducir ahorro energético en valor de negocio:

- **VAN (NPV)**: valor actual de todos los flujos futuros menos inversión inicial.
- **TIR (IRR)**: tasa que hace VAN = 0 (si existe solución).
- **Payback simple**: años (fraccionarios) para recuperar inversión sin descuento.
- **Payback descontado**: años (fraccionarios) para recuperar inversión descontando flujos.
- **ROI total**: beneficio neto acumulado sobre la inversión inicial.
- **Flujo de caja anual**: lista completa `[-CAPEX, flujo_año1, flujo_año2, ...]`.

### Fórmulas usadas

- `cashflow[0] = -CAPEX`
- `cashflow[n] = annual_savings * (1 - degradation_rate)^(n-1) - annual_opex`
- `NPV = Σ cashflow[i] / (1 + discount_rate)^i`
- `ROI_total = (Σ cashflow[1:] - CAPEX) / CAPEX`

La TIR se calcula de forma robusta con Newton-Raphson y fallback binario cuando Newton diverge o no es estable.

### Supuestos

- Horizonte anual discreto (`lifetime_years`).
- Los flujos ocurren al cierre de cada año.
- El CAPEX ocurre en `t=0`.
- OPEX anual constante (salvo personalización explícita).
- Tasa de descuento por defecto: `5%` cuando no se especifica.

### Limitaciones

- No se modela inflación de forma implícita.
- No incluye impuestos, amortización fiscal ni coste de oportunidad avanzado.
- Si no hay cambio de signo en flujos, la TIR se reporta como `None`.

## Logging & Crash Reporting

Cada ejecución de proyecto (CLI) genera trazabilidad local en:

```text
<project_dir>/logs/
  runs/
    <run_id>/
      run.log
      environment.json
      crash.json   # solo si hay fallo inesperado
```

### Qué contiene cada archivo

- `run.log`: eventos de ejecución con formato `[timestamp] [LEVEL] [module] message`.
- `environment.json`: snapshot de reproducibilidad con `scenario_hash`, `dataset_hash`, modo rápido y metadata de entorno.
- `crash.json`: reporte automático si ocurre un crash no controlado (tipo de excepción, mensaje, traceback completo y contexto).

### Reproducir un run

1. Localiza el `run_id` y abre `environment.json`.
2. Reutiliza el mismo dataset (`dataset_hash`) y configuración (`scenario_hash`).
3. Ejecuta de nuevo `project run` o `project batch-run` con los mismos flags (`fast_mode`, `grid_mode`) para comparar.

### UI

La UI escribe logs en `./logs/ui/` y mantiene captura global de excepciones críticas.

## Sistema de Cache

El proyecto incorpora un cache determinístico por simulación en `<project_dir>/cache/<simulation_hash>/`.

### Cómo funciona

- Antes de simular, se calcula un `simulation_hash` SHA256 con:
  - contenido del dataset (hash por archivo),
  - `scenario` serializado,
  - modo (`FAST` o detallado),
  - parámetros financieros (si se informan).
- Si existe cache para ese hash: **Cache hit** y se devuelve resultado sin recalcular.
- Si no existe: **Cache miss**, se ejecuta simulación y se guarda cache.

Cada entrada puede contener:
- `result.json`
- `kpis.json`
- `metadata.json`
- `hourly_detail.pkl` (cuando hay detalle temporal)

### Qué invalida cache

Cualquier cambio en:
- dataset,
- escenario,
- modo FAST vs detallado,
- parámetros financieros.

### Forzar recálculo

Puedes ignorar cache con `--no-cache`:

```bash
fvbess project run <project_dir> --no-cache
fvbess project batch-run <project_dir> --no-cache
```

Esto fuerza recálculo y sobrescribe la entrada de cache correspondiente.

### Limpiar cache

```bash
fvbess project cache-clear <project_dir>
```

El comando borra la carpeta `cache` completa del proyecto.

### Beneficios

- Acelera ejecuciones repetidas de `project run`.
- Reduce tiempo total en `batch-run` y barridos multi-batería cuando hay combinaciones repetidas.
- Mejora reproducibilidad: misma entrada → mismo hash → mismo resultado cacheado.


## Benchmark del motor

Puedes medir rendimiento real del motor FV+BESS con dataset y proyecto reales, sin dependencias externas.

### Ejecutar benchmark

```bash
fvbess benchmark <project_dir> [--runs 5] [--fast] [--grid] [--workers N]
```

- Sin `--fast`, el comando ejecuta **comparativa automática** entre modo detallado y modo FAST.
- Con `--fast`, ejecuta solo FAST.
- `--grid` evalúa todas las variantes de `battery_grid.json`.
- `--workers` paraleliza variantes cuando usas grid.

### Qué métricas entrega

- Filas de dataset y filas procesadas por run.
- Tiempo medio, desviación estándar, mínimo y máximo.
- Tiempo de carga de dataset y tiempo de simulación pura (separados).
- Tiempo por 1000 filas.
- Throughput (`rows/sec`) y `runs/sec`.
- `variantes/sec` (clave en evaluación masiva de escenarios).
- `Speedup FAST` frente a detallado (si se ejecutan ambos modos).

### Salida JSON para evidencias

Cada corrida guarda un archivo en:

```text
<project_dir>/benchmark/benchmark_<timestamp>.json
```

El JSON incluye los bloques por modo, throughput y speedup, para que puedas usar evidencia reproducible en demos técnicas, propuestas comerciales o portfolio de performance engineering.

### Interpretación rápida (portfolio)

- **¿Cuánto tarda en simular un año?** Mira `simulation_mean_time_sec`.
- **¿FAST realmente acelera?** Mira `speedup_fast_vs_detailed`.
- **¿Cómo escala?** Compara `rows_per_sec` y `variantes/sec` entre datasets y grids más grandes.
- **¿Cuántas variantes por segundo evalúas?** Usa `variants_per_sec` como KPI de capacidad de exploración.
