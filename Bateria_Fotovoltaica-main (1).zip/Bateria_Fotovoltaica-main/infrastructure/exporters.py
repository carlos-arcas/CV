"""Exportadores de resultados para formatos de salida externos."""

from __future__ import annotations

import logging
import time
from pathlib import Path

import pandas as pd

from infrastructure.version import __version__
from application.dto import ResultsBundleDTO
from application.export.executive_report import build_executive_summary
from infrastructure.io.excel_writer import atomic_excel_write

logger = logging.getLogger(__name__)


def _annual_energy_stats(results: ResultsBundleDTO) -> dict[str, float]:
    scenario = results.scenario
    return {
        "battery_capacity_kwh": float(scenario.battery.capacity_kwh),
        "battery_power_kw": float(scenario.battery.power_kw),
    }


def _executive_rows(
    results: ResultsBundleDTO,
    comparison: dict | None,
    *,
    project_name: str = "Simulación FV+BESS",
    client_name: str | None = None,
    scenario_name: str | None = None,
) -> list[dict[str, object]]:
    summary = build_executive_summary(
        project_name=project_name,
        client_name=client_name,
        scenario_name=scenario_name,
        kpis=results.kpis,
        annual_energy_stats=_annual_energy_stats(results),
        comparison=comparison,
    )
    rows = list(summary.get("rows", []))
    return rows[:25]


def _write_executive_sheet(
    *,
    writer: pd.ExcelWriter,
    rows: list[dict[str, object]],
    title: str = "Resumen Ejecutivo",
) -> None:
    output_rows: list[dict[str, object]] = []
    section = None
    for item in rows:
        row_section = str(item.get("section", ""))
        if row_section != section:
            output_rows.append({"Métrica": row_section, "Valor": ""})
            section = row_section

        output_rows.append({"Métrica": item.get("metric"), "Valor": "" if item.get("value") is None else item.get("value")})

    executive_df = pd.DataFrame(output_rows)
    executive_df.to_excel(writer, sheet_name="Resumen Ejecutivo", index=False, startrow=1)

    ws = writer.sheets.get("Resumen Ejecutivo")
    if ws is None:
        return

    if writer.engine == "xlsxwriter":
        book = writer.book
        title_format = book.add_format({"bold": True, "font_size": 13})
        section_format = book.add_format({"bold": True, "bg_color": "#F2F2F2"})
        ws.set_column(0, 0, 42)
        ws.set_column(1, 1, 24)
        ws.write(0, 0, title, title_format)
        for row_idx, value in enumerate(executive_df["Métrica"], start=3):
            if value in {"RESUMEN CLAVE", "DATOS TÉCNICOS", "COMPARATIVA"}:
                ws.write(row_idx - 1, 0, value, section_format)
    else:
        ws.column_dimensions["A"].width = 42
        ws.column_dimensions["B"].width = 24
        ws["A1"].value = title
        ws["A1"].font = ws["A1"].font.copy(bold=True)
        for row_idx in range(3, 3 + len(executive_df)):
            cell = ws[f"A{row_idx}"]
            if cell.value in {"RESUMEN CLAVE", "DATOS TÉCNICOS", "COMPARATIVA"}:
                cell.font = cell.font.copy(bold=True)


def export_results_to_excel(
    results: ResultsBundleDTO,
    path: str,
    compare_metrics: dict | None = None,
    dataset_df: pd.DataFrame | None = None,
    dataset_output_path: str | None = None,
    dataset_multi_output_path: str | None = None,
    ml_metrics_by_year: dict | None = None,
    dimensioning_df: pd.DataFrame | None = None,
    dimensioning_recommendation_df: pd.DataFrame | None = None,
    dimensioning_params_df: pd.DataFrame | None = None,
    export_level: str = "kpis_only",
    chart_paths: list[str] | None = None,
    finance_payload: dict | None = None,
    offer_payload: dict | None = None,
    include_executive: bool = True,
) -> None:
    """Exporta informe Excel con hojas ejecutivas, KPI y detalle opcional por periodos."""
    if export_level not in {"full", "kpis_only"}:
        raise ValueError("export_level debe ser full o kpis_only.")

    monthly_df = results.kpis.get("monthly") if isinstance(results.kpis.get("monthly"), pd.DataFrame) else pd.DataFrame()
    kpi_rows = [{"kpi": k, "valor": v} for k, v in results.kpis.items() if not isinstance(v, (pd.DataFrame, list, dict))]
    kpis_df = pd.DataFrame(kpi_rows)
    compare_df = pd.DataFrame([compare_metrics]) if compare_metrics else pd.DataFrame()

    ml_metrics_rows: list[dict] = []
    if ml_metrics_by_year:
        for year, metrics in ml_metrics_by_year.items():
            ml_metrics_rows.append({"year": year, "mae_charge": metrics.get("mae_charge"), "mae_discharge": metrics.get("mae_discharge")})
    ml_metrics_df = pd.DataFrame(ml_metrics_rows)

    executive_rows = _executive_rows(results, compare_metrics) if include_executive else []

    assumptions_df = pd.DataFrame(
        [
            {"supuesto": "Horizonte", "valor": "1 año, paso 15 minutos"},
            {"supuesto": "Motor", "valor": "Optimización LP diaria (SciPy) "},
            {"supuesto": "Limitaciones", "valor": "Resultado óptimo sujeto a límites de potencia, SoC y red"},
            {"supuesto": "Versión app", "valor": __version__},
        ]
    )

    detail_periods_df = results.series if export_level == "full" else pd.DataFrame()

    finance_summary_df = pd.DataFrame()
    finance_amortization_df = pd.DataFrame()
    finance_scenarios_df = pd.DataFrame()

    sales_offer_df = pd.DataFrame()
    if offer_payload:
        rows = []
        selected = offer_payload.get("selected_strategy")
        for item in offer_payload.get("results", []):
            rows.append(
                {
                    "selected_strategy": selected,
                    "strategy": item.strategy,
                    "parameters": ", ".join(f"{k}={v}" for k, v in item.parameters.items()),
                    "cuota_recomendada": item.cuota_recomendada,
                    "ahorro_cliente_mensual": item.ahorro_cliente_mensual,
                    "margen_total_empresa": item.margen_total_empresa,
                    "margen_mensual_empresa": item.margen_mensual_empresa,
                    "payback_equivalente_cliente": item.payback_equivalente_cliente,
                }
            )
        sales_offer_df = pd.DataFrame(rows)

    if finance_payload:
        summary = finance_payload.get("summary")
        if summary is not None:
            finance_summary_df = pd.DataFrame(
                [
                    {
                        "annual_savings_eur": summary.annual_savings_eur,
                        "capex_total_eur": summary.capex_total_eur,
                        "purchase_payback_years": summary.purchase_payback_years,
                        "purchase_roi_annual": summary.purchase_roi_annual,
                        "npv_eur": summary.npv_eur,
                        "loan_monthly_payment_eur": summary.loan_monthly_payment_eur,
                        "loan_payback_month": summary.loan_payback_month,
                        "rental_base_fee_eur": summary.rental_base_fee_eur,
                        "rental_customer_fee_eur": summary.rental_customer_fee_eur,
                        "rental_total_margin_eur": summary.rental_total_margin_eur,
                        "rental_monthly_margin_eur": summary.rental_monthly_margin_eur,
                        "customer_monthly_benefit_eur": summary.customer_monthly_benefit_eur,
                    }
                ]
            )
        finance_amortization_df = pd.DataFrame(finance_payload.get("amortization", []))
        finance_scenarios_df = pd.DataFrame(finance_payload.get("scenarios", []))

    try:
        import xlsxwriter  # noqa: F401

        engine = "xlsxwriter"
    except Exception:
        engine = "openpyxl"

    logger.info("Exportando informe a %s con engine=%s", path, engine)
    summary_start = time.perf_counter()

    def _write(target_path: str) -> None:
        with pd.ExcelWriter(target_path, engine=engine) as writer:
            if include_executive:
                _write_executive_sheet(writer=writer, rows=executive_rows)
            kpis_df.to_excel(writer, sheet_name="KPIs", index=False)
            monthly_df.to_excel(writer, sheet_name="Mensual", index=False)
            if dimensioning_df is not None and not dimensioning_df.empty:
                dimensioning_df.to_excel(writer, sheet_name="Dimensioning", index=False)
            assumptions_df.to_excel(writer, sheet_name="Supuestos y límites", index=False)
            compare_df.to_excel(writer, sheet_name="Comparativa", index=False)
            ml_metrics_df.to_excel(writer, sheet_name="ML metrics", index=False)
            if dimensioning_params_df is not None and not dimensioning_params_df.empty:
                dimensioning_params_df.to_excel(writer, sheet_name="Parametros", index=False)
            if export_level == "full" and not detail_periods_df.empty:
                detail_periods_df.to_excel(writer, sheet_name="Detalle periodos", index=False)
            if not finance_summary_df.empty:
                finance_summary_df.to_excel(writer, sheet_name="finance_summary", index=False)
            if not finance_amortization_df.empty:
                finance_amortization_df.to_excel(writer, sheet_name="amortization", index=False)
            if not finance_scenarios_df.empty:
                finance_scenarios_df.to_excel(writer, sheet_name="scenarios", index=False)
            if not sales_offer_df.empty:
                sales_offer_df.to_excel(writer, sheet_name="sales_offer", index=False)

            if engine == "xlsxwriter" and chart_paths:
                ws = writer.sheets.get("Resumen Ejecutivo")
                if ws is not None:
                    row = 8
                    for chart in chart_paths:
                        if Path(chart).exists():
                            ws.insert_image(row, 0, chart)
                            row += 20

    atomic_excel_write(path, _write)
    if include_executive:
        logger.info(
            "Executive summary generated | path=%s | elapsed_ms=%.2f",
            path,
            (time.perf_counter() - summary_start) * 1000.0,
        )

    if dataset_df is not None and dataset_output_path and export_level == "full":
        dataset_df.to_csv(dataset_output_path, index=False, compression="gzip")
    if dataset_df is not None and dataset_multi_output_path and export_level == "full":
        dataset_df.to_parquet(dataset_multi_output_path, index=False)


def export_dimensioning_to_excel(
    path: str,
    dimensioning_df: pd.DataFrame,
    recommendation_df: pd.DataFrame,
    params_df: pd.DataFrame,
    top_periods: dict[str, pd.DataFrame] | None = None,
) -> None:
    """Exporta análisis de dimensionamiento con tablas y recomendación."""
    if dimensioning_df.empty:
        raise ValueError("No hay datos de dimensionamiento para exportar.")

    try:
        import xlsxwriter  # noqa: F401

        engine = "xlsxwriter"
    except Exception:
        engine = "openpyxl"

    def _write(target_path: str) -> None:
        with pd.ExcelWriter(target_path, engine=engine) as writer:
            dimensioning_df.to_excel(writer, sheet_name="Dimensioning", index=False)
            recommendation_df.to_excel(writer, sheet_name="Resumen Ejecutivo", index=False)
            params_df.to_excel(writer, sheet_name="Supuestos y límites", index=False)
            if top_periods:
                for sheet_name, period_df in top_periods.items():
                    period_df.to_excel(writer, sheet_name=sheet_name[:31], index=False)

    atomic_excel_write(path, _write)


def export_executive_summary_to_excel(
    *,
    results: ResultsBundleDTO,
    path: str,
    comparison: dict | None = None,
    top_configurations: list[dict[str, object]] | None = None,
    project_name: str = "Simulación FV+BESS",
    client_name: str | None = None,
    scenario_name: str | None = None,
) -> None:
    """Exporta únicamente el resumen ejecutivo en un archivo dedicado."""
    rows = _executive_rows(
        results,
        comparison,
        project_name=project_name,
        client_name=client_name,
        scenario_name=scenario_name,
    )

    def _write(target_path: str) -> None:
        with pd.ExcelWriter(target_path, engine="openpyxl") as writer:
            _write_executive_sheet(writer=writer, rows=rows)
            if top_configurations:
                pd.DataFrame(top_configurations[:3]).to_excel(writer, sheet_name="Top 3 configuraciones", index=False)

    started = time.perf_counter()
    atomic_excel_write(path, _write)
    logger.info(
        "Executive summary generated | path=%s | elapsed_ms=%.2f",
        path,
        (time.perf_counter() - started) * 1000.0,
    )
