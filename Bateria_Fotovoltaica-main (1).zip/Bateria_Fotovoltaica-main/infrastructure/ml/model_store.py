"""Persistencia de bundles de modelos ML para simulación rápida."""

from __future__ import annotations

from datetime import datetime, timezone
import pickle
from typing import Any


try:  # pragma: no cover - depende entorno
    import joblib

    JOBLIB_AVAILABLE = True
except Exception:  # pragma: no cover
    joblib = None
    JOBLIB_AVAILABLE = False


def save_model(obj: Any, path: str) -> None:
    """Guarda un objeto de modelo incluyendo metadata de versionado.

    Entradas:
        obj: Bundle de modelos o artefacto serializable.
        path: Ruta destino (`.joblib`/`.pkl`).

    Salidas:
        Archivo persistido en disco listo para carga posterior.

    Errores relevantes:
        OSError: Si falla la escritura del archivo destino.
    """
    bundle = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "version": "1.0",
        "payload": obj,
    }
    if JOBLIB_AVAILABLE:
        joblib.dump(bundle, path)
    else:
        with open(path, "wb") as fh:
            pickle.dump(bundle, fh)


def load_model(path: str) -> Any:
    """Carga un bundle de modelo persistido con joblib o pickle.

    Entradas:
        path: Ruta al artefacto serializado.

    Salidas:
        Objeto restaurado con metadata y payload.

    Errores relevantes:
        FileNotFoundError/OSError: Si el archivo no existe o está corrupto.
    """
    if JOBLIB_AVAILABLE:
        return joblib.load(path)
    with open(path, "rb") as fh:
        return pickle.load(fh)
