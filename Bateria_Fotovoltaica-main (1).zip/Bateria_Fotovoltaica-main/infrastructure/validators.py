"""Compatibilidad de validadores de infraestructura (delegan en application.validators)."""

from __future__ import annotations

import pandas as pd

from application.validators import normalize_dataset_15min, validate_schema as _validate_schema


def validate_schema(df: pd.DataFrame) -> list[str]:
    return _validate_schema(df)


def normalize_timestep_15min(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    return normalize_dataset_15min(df)
