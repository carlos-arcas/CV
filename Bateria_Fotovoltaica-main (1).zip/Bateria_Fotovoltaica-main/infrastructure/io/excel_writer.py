"""Escritura segura de Excel con archivo temporal y chequeo de bloqueo."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from domain.errors import ExportError


def assert_excel_not_locked(path: str) -> None:
    """Comprueba si un archivo Excel destino está bloqueado por otra app."""
    target = Path(path)
    if not target.exists():
        return
    try:
        with open(target, "a+b"):
            pass
    except OSError as exc:
        raise ExportError(f"El archivo destino está abierto/bloqueado: {path}. Cierre Excel y reintente.") from exc


def atomic_excel_write(path: str, write_callback) -> None:
    """Escribe usando temporal y renombra al final para evitar corrupción."""
    assert_excel_not_locked(path)
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=dest.stem + "_", suffix=dest.suffix, dir=str(dest.parent))
    os.close(fd)
    tmp_path = Path(tmp)
    try:
        write_callback(str(tmp_path))
        tmp_path.replace(dest)
    except Exception as exc:
        tmp_path.unlink(missing_ok=True)
        if isinstance(exc, ExportError):
            raise
        raise ExportError(f"Error al exportar Excel en modo seguro: {exc}") from exc
