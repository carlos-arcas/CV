"""Cache de resultados de simulación por hash(dataset+config)."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

import pandas as pd

from application.dto import ResultsBundleDTO
from domain.models import ScenarioConfig, SimulationMode


def hash_dataframe(df: pd.DataFrame) -> str:
    """Genera hash estable del contenido tabular."""
    payload = pd.util.hash_pandas_object(df, index=True).values.tobytes()
    return hashlib.sha256(payload).hexdigest()


def hash_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build_cache_key(dataset_hash: str, scenario: ScenarioConfig, *, include_detail: bool, mode: SimulationMode = SimulationMode.OPTIMAL) -> str:
    raw = json.dumps(
        {
            "dataset_hash": dataset_hash,
            "scenario": {
                "battery": asdict(scenario.battery),
                "tariff": asdict(scenario.tariff),
                "grid": asdict(scenario.grid),
                "timestep_minutes": scenario.timestep_minutes,
            },
            "include_detail": include_detail,
            "mode": str(mode),
        },
        sort_keys=True,
        ensure_ascii=False,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class CacheStore:
    def __init__(self, cache_dir: Path) -> None:
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, key: str) -> Path:
        return self.cache_dir / f"{key}.pkl"

    def get(self, key: str) -> ResultsBundleDTO | None:
        path = self._cache_path(key)
        if not path.exists():
            return None
        return pd.read_pickle(path)

    def put(self, key: str, value: ResultsBundleDTO) -> None:
        pd.to_pickle(value, self._cache_path(key))
