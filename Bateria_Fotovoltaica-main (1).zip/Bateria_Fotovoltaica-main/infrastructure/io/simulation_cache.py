"""Cache determinístico por hash para simulaciones de proyecto."""

from __future__ import annotations

import hashlib
import json
import logging
import pickle
import shutil
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import pandas as pd

from application.dto import ResultsBundleDTO
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from infrastructure.io.cache_store import hash_file

logger = logging.getLogger(__name__)

SimulationResult = ResultsBundleDTO


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if hasattr(value, "item"):
        return value.item()
    return str(value)


def _json_default(value: Any) -> Any:
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Tipo no serializable para cache: {type(value)!r}")


def _scenario_to_dict(scenario: ScenarioConfig) -> dict[str, Any]:
    return {
        "battery": asdict(scenario.battery),
        "tariff": asdict(scenario.tariff),
        "grid": asdict(scenario.grid),
        "timestep_minutes": scenario.timestep_minutes,
    }


def _scenario_from_dict(data: dict[str, Any]) -> ScenarioConfig:
    return ScenarioConfig(
        battery=BatteryParams(**data.get("battery", {})),
        tariff=TariffParams(**data.get("tariff", {})),
        grid=GridParams(**data.get("grid", {})),
        timestep_minutes=int(data.get("timestep_minutes", 15)),
    )


def build_simulation_hash(
    *,
    dataset_path: Path,
    scenario_config: dict[str, Any],
    fast_mode: bool,
    financial_params: dict[str, Any] | None,
) -> str:
    """Construye hash determinístico a partir de dataset+escenario+modo+finanzas."""
    dataset_hash = hash_file(str(dataset_path))
    payload = {
        "dataset_hash": dataset_hash,
        "scenario_config": scenario_config,
        "fast_mode": bool(fast_mode),
        "financial_params": financial_params or {},
    }
    text = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=_json_default)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cache_root(project_dir: Path, simulation_hash: str) -> Path:
    return project_dir / "cache" / simulation_hash


def _directory_size_bytes(folder: Path) -> int:
    total = 0
    for item in folder.rglob("*"):
        if item.is_file():
            total += item.stat().st_size
    return total


def _build_metadata(*, scenario_hash: str, dataset_hash: str, fast_mode: bool, simulation_hash: str) -> dict[str, Any]:
    return {
        "simulation_hash": simulation_hash,
        "scenario_hash": scenario_hash,
        "dataset_hash": dataset_hash,
        "fast_mode": bool(fast_mode),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _load_cached_result(cache_dir: Path) -> SimulationResult:
    result_payload = json.loads((cache_dir / "result.json").read_text(encoding="utf-8"))
    kpis = json.loads((cache_dir / "kpis.json").read_text(encoding="utf-8"))
    detail_path = cache_dir / "hourly_detail.pkl"
    detail = pd.DataFrame()
    if detail_path.exists():
        with detail_path.open("rb") as fh:
            detail = pickle.load(fh)

    scenario = _scenario_from_dict(result_payload["scenario"])
    logs = result_payload.get("logs", [])
    return ResultsBundleDTO(scenario=scenario, series=detail, kpis=kpis, logs=logs)


def run_with_cache(
    *,
    project_dir: Path,
    simulation_hash: str,
    compute_func: Callable[[], SimulationResult],
) -> SimulationResult:
    """Ejecuta cálculo con persistencia de cache local en el proyecto."""
    cache_dir = _cache_root(project_dir, simulation_hash)
    started = time.perf_counter()

    if cache_dir.exists():
        try:
            logger.info("Cache hit simulation_hash=%s", simulation_hash)
            result = _load_cached_result(cache_dir)
            logger.info("Cache load completed in %.4f sec simulation_hash=%s", time.perf_counter() - started, simulation_hash)
            return result
        except Exception as exc:  # noqa: BLE001
            logger.warning("Cache corrupt/invalid for %s (%s). Recomputing.", simulation_hash, exc)
            shutil.rmtree(cache_dir, ignore_errors=True)

    logger.info("Cache miss simulation_hash=%s", simulation_hash)
    result = compute_func()
    cache_dir.mkdir(parents=True, exist_ok=True)

    scenario_dict = _scenario_to_dict(result.scenario)
    dataset_hash = str(result.kpis.get("dataset_hash", ""))
    scenario_hash = hashlib.sha256(json.dumps(scenario_dict, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
    fast_mode = bool(result.kpis.get("simulation_fast_mode", False))

    (cache_dir / "result.json").write_text(
        json.dumps({"scenario": scenario_dict, "logs": list(result.logs)}, indent=2, ensure_ascii=False, default=_json_default),
        encoding="utf-8",
    )
    (cache_dir / "kpis.json").write_text(
        json.dumps(_json_safe(result.kpis), indent=2, ensure_ascii=False, default=_json_default),
        encoding="utf-8",
    )
    (cache_dir / "metadata.json").write_text(
        json.dumps(
            _build_metadata(
                scenario_hash=scenario_hash,
                dataset_hash=dataset_hash,
                fast_mode=fast_mode,
                simulation_hash=simulation_hash,
            ),
            indent=2,
            ensure_ascii=False,
            default=_json_default,
        ),
        encoding="utf-8",
    )

    if not result.series.empty:
        with (cache_dir / "hourly_detail.pkl").open("wb") as fh:
            pickle.dump(result.series, fh)

    logger.info("Cache stored simulation_hash=%s size_bytes=%s", simulation_hash, _directory_size_bytes(cache_dir))
    return result


def clear_project_cache(project_dir: Path) -> bool:
    """Elimina cache completa del proyecto."""
    cache_dir = project_dir / "cache"
    if not cache_dir.exists():
        return False
    shutil.rmtree(cache_dir)
    return True
