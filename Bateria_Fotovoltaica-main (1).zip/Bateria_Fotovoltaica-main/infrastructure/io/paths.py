"""Helpers de rutas por defecto para proyectos, exportaciones y modelos."""

from __future__ import annotations

from pathlib import Path


APP_FOLDER_NAME = "bess_fv"


def default_projects_dir() -> Path:
    """Devuelve la carpeta por defecto de proyectos de la aplicación."""
    return Path.home() / APP_FOLDER_NAME / "projects"


def default_exports_dir() -> Path:
    """Devuelve la carpeta por defecto para exportaciones de resultados."""
    return Path.home() / APP_FOLDER_NAME / "exports"


def default_models_dir() -> Path:
    """Devuelve la carpeta por defecto para bundles de modelos ML."""
    return Path.home() / APP_FOLDER_NAME / "models"


def ensure_dir(path: str | Path) -> Path:
    """Crea una carpeta si no existe y devuelve su ruta absoluta."""
    resolved = Path(path).expanduser().resolve()
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved
