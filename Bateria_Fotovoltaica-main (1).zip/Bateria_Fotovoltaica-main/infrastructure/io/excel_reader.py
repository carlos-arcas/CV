"""Lectura de Excel/CSV con hash para trazabilidad."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from infrastructure.io.cache_store import hash_file


def read_tabular(path: str) -> tuple[pd.DataFrame, str]:
    p = Path(path)
    if p.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path)
    return df, hash_file(path)
