"""Persistencia robusta de ModelBundle con serialización preferente joblib."""

from __future__ import annotations

from datetime import datetime, timezone
import importlib
import importlib.util
import json
from pathlib import Path
import pickle
from typing import Any

from application.ml.model_bundle import ModelBundle


def _joblib_module() -> Any | None:
    """Obtiene el módulo joblib si está instalado, o None si no existe."""
    if importlib.util.find_spec("joblib") is None:
        return None
    return importlib.import_module("joblib")


def save_model_bundle(bundle: ModelBundle, folder: str) -> str:
    """Guarda un bundle en carpeta con archivos individuales y metadata JSON."""
    target = Path(folder).expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)

    metadata = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "serialization": "joblib" if _joblib_module() else "pickle",
        **bundle.metadata,
    }
    serializer = _joblib_module()

    if serializer is not None:
        serializer.dump(bundle.action_model, target / "action_model.joblib")
        serializer.dump(bundle.charge_model, target / "charge_model.joblib")
        serializer.dump(bundle.discharge_model, target / "discharge_model.joblib")
    else:
        # Riesgo documentado: pickle permite ejecución de código al deserializar fuentes no confiables.
        with open(target / "action_model.joblib", "wb") as fh:
            pickle.dump(bundle.action_model, fh)
        with open(target / "charge_model.joblib", "wb") as fh:
            pickle.dump(bundle.charge_model, fh)
        with open(target / "discharge_model.joblib", "wb") as fh:
            pickle.dump(bundle.discharge_model, fh)

    with open(target / "metadata.json", "w", encoding="utf-8") as fh:
        json.dump(metadata, fh, indent=2, ensure_ascii=False)
    return str(target)


def load_model_bundle(folder: str) -> ModelBundle:
    """Carga un ModelBundle desde disco validando presencia de archivos esperados."""
    source = Path(folder).expanduser().resolve()
    meta_path = source / "metadata.json"
    action_path = source / "action_model.joblib"
    charge_path = source / "charge_model.joblib"
    discharge_path = source / "discharge_model.joblib"
    for file_path in (meta_path, action_path, charge_path, discharge_path):
        if not file_path.exists():
            raise FileNotFoundError(f"Falta el archivo requerido del modelo: {file_path.name}")

    with open(meta_path, "r", encoding="utf-8") as fh:
        metadata = json.load(fh)

    serializer = _joblib_module()
    if serializer is not None:
        action_model = serializer.load(action_path)
        charge_model = serializer.load(charge_path)
        discharge_model = serializer.load(discharge_path)
    else:
        # Riesgo documentado: pickle solo debe usarse con artefactos de confianza.
        with open(action_path, "rb") as fh:
            action_model = pickle.load(fh)
        with open(charge_path, "rb") as fh:
            charge_model = pickle.load(fh)
        with open(discharge_path, "rb") as fh:
            discharge_model = pickle.load(fh)

    return ModelBundle(
        action_model=action_model,
        charge_model=charge_model,
        discharge_model=discharge_model,
        metadata=metadata,
    )
