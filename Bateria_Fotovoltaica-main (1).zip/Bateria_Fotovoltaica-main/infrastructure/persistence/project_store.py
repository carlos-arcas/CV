"""Persistencia de proyectos en formato JSON legible con cache opcional."""

from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path

import pandas as pd

from domain.models_project import ModelBundleRef, ProjectConfig

CURRENT_SCHEMA_VERSION = 2


def _migrate_project_dict(raw: dict) -> dict:
    """Migra esquemas antiguos añadiendo claves nuevas con valores por defecto."""
    schema_version = int(raw.get("schema_version", 1))
    migrated = dict(raw)
    if schema_version < 2:
        migrated.setdefault("export_folder", "")
        migrated.setdefault("model_folder", "")
        migrated.setdefault("results_cache_path", None)
        migrated["schema_version"] = 2
    return migrated


def save_project(project_config: ProjectConfig, path: str) -> str:
    """Guarda configuración de proyecto, escenario y cache de resultados en carpeta."""
    project_dir = Path(path).expanduser().resolve()
    project_dir.mkdir(parents=True, exist_ok=True)

    project_data = asdict(project_config)
    scenario_data = project_data.pop("scenario", {})
    results_cache_path = project_data.get("results_cache_path")

    project_data["schema_version"] = CURRENT_SCHEMA_VERSION
    with open(project_dir / "project.json", "w", encoding="utf-8") as fh:
        json.dump(project_data, fh, indent=2, ensure_ascii=False)

    with open(project_dir / "scenario.json", "w", encoding="utf-8") as fh:
        json.dump(scenario_data, fh, indent=2, ensure_ascii=False)

    if results_cache_path:
        cache_df = pd.read_parquet(results_cache_path) if Path(results_cache_path).exists() else pd.DataFrame()
        if not cache_df.empty:
            cache_df.to_parquet(project_dir / "results_cache.parquet", index=False)

    return str(project_dir)


def load_project(path: str) -> tuple[ProjectConfig, pd.DataFrame | None, list[str]]:
    """Carga un proyecto desde carpeta aplicando migraciones y warnings de versión."""
    project_dir = Path(path).expanduser().resolve()
    project_file = project_dir / "project.json"
    scenario_file = project_dir / "scenario.json"
    if not project_file.exists():
        raise FileNotFoundError("No existe project.json en la carpeta seleccionada.")

    warnings: list[str] = []
    with open(project_file, "r", encoding="utf-8") as fh:
        raw_project = json.load(fh)

    original_schema = int(raw_project.get("schema_version", 1))
    migrated = _migrate_project_dict(raw_project)
    if original_schema != migrated.get("schema_version"):
        warnings.append(
            f"schema_version {original_schema} detectado. Se aplicó migración ligera a {migrated.get('schema_version')}."
        )

    with open(scenario_file, "r", encoding="utf-8") as fh:
        scenario_data = json.load(fh)

    model_ref = None
    raw_model_ref = migrated.get("model_bundle")
    if isinstance(raw_model_ref, dict) and raw_model_ref.get("folder"):
        model_ref = ModelBundleRef(**raw_model_ref)

    config = ProjectConfig(
        name=migrated.get("name", project_dir.name),
        data_path=migrated.get("data_path", ""),
        model_folder=migrated.get("model_folder", ""),
        export_folder=migrated.get("export_folder", ""),
        scenario=scenario_data,
        results_cache_path=str(project_dir / "results_cache.parquet") if (project_dir / "results_cache.parquet").exists() else None,
        model_bundle=model_ref,
        app_version=migrated.get("app_version", "1.0.0"),
        schema_version=int(migrated.get("schema_version", CURRENT_SCHEMA_VERSION)),
    )

    cache_df = None
    cache_file = project_dir / "results_cache.parquet"
    if cache_file.exists():
        cache_df = pd.read_parquet(cache_file)

    return config, cache_df, warnings
