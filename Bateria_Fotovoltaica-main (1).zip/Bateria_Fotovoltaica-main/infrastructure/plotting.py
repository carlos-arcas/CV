"""Utilidades de gráficos para análisis de dimensionamiento."""

from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd


def plot_savings_vs_capacity(sweep_df: pd.DataFrame, power_kw: float, output_path: str) -> str:
    """Genera curva 1D de ahorro anual frente a capacidad para potencia fija.

    Entradas:
        sweep_df: DataFrame del barrido con columnas de ahorro/capacidad/potencia.
        power_kw: Potencia objetivo a filtrar para la curva.
        output_path: Ruta PNG de salida.

    Salidas:
        Ruta del archivo generado.

    Errores relevantes:
        ValueError: Si no hay datos para la potencia solicitada.
    """
    subset = sweep_df[sweep_df["power_kw"] == float(power_kw)].sort_values("capacity_kwh")
    if subset.empty:
        raise ValueError("No hay datos para la potencia seleccionada en la curva 1D.")

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(subset["capacity_kwh"], subset["annual_savings"], marker="o")
    ax.set_title(f"Ahorro anual vs capacidad (P={power_kw:.1f} kW)")
    ax.set_xlabel("Capacidad (kWh)")
    ax.set_ylabel("Ahorro anual (€)")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return output_path


def plot_savings_heatmap(sweep_df: pd.DataFrame, output_path: str) -> str:
    """Genera heatmap 2D de ahorro anual por capacidad y potencia.

    Entradas:
        sweep_df: DataFrame del barrido con columnas `capacity_kwh`, `power_kw`, `annual_savings`.
        output_path: Ruta PNG de salida.

    Salidas:
        Ruta del archivo generado.

    Errores relevantes:
        ValueError: Si no existe malla suficiente para construir el heatmap.
    """
    pivot = sweep_df.pivot(index="capacity_kwh", columns="power_kw", values="annual_savings")
    if pivot.empty:
        raise ValueError("No se pudo construir la matriz del heatmap.")

    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(pivot.values, origin="lower", aspect="auto")
    ax.set_title("Heatmap ahorro anual (€)")
    ax.set_xlabel("Potencia (kW)")
    ax.set_ylabel("Capacidad (kWh)")
    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels([f"{v:.0f}" for v in pivot.columns])
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels([f"{v:.0f}" for v in pivot.index])
    fig.colorbar(im, ax=ax, label="€ / año")
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return output_path


def plot_roi_vs_capacity(sweep_df: pd.DataFrame, power_kw: float, output_path: str) -> str:
    """Genera curva ROI/NPV frente a capacidad para una potencia fija.

    Entradas:
        sweep_df: DataFrame con columna `npv_eur` y variables de dimensionado.
        power_kw: Potencia objetivo para filtrar.
        output_path: Ruta PNG de salida.

    Salidas:
        Ruta del archivo generado.

    Errores relevantes:
        ValueError: Si faltan columnas financieras o no hay datos filtrados.
    """
    if "npv_eur" not in sweep_df.columns:
        raise ValueError("La columna npv_eur es obligatoria para la curva ROI.")

    subset = sweep_df[sweep_df["power_kw"] == float(power_kw)].sort_values("capacity_kwh")
    if subset.empty:
        raise ValueError("No hay datos para la potencia seleccionada en curva ROI.")

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(subset["capacity_kwh"], subset["npv_eur"], marker="o", color="#2a9d8f")
    ax.axhline(0.0, linestyle="--", color="gray", linewidth=1)
    ax.set_title(f"NPV vs capacidad (P={power_kw:.1f} kW)")
    ax.set_xlabel("Capacidad (kWh)")
    ax.set_ylabel("NPV (€)")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)
    return output_path
