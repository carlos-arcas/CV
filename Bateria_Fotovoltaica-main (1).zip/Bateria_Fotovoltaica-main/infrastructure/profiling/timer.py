"""Utilidades de profiling liviano para casos de uso."""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager


@contextmanager
def log_timed(logger: logging.Logger, label: str):
    """Context manager que registra tiempo de inicio/fin en segundos."""
    start = time.perf_counter()
    logger.info("%s | inicio", label)
    try:
        yield
    finally:
        logger.info("%s | fin | %.3fs", label, time.perf_counter() - start)
