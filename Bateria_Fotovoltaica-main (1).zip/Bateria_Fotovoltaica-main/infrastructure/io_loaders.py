"""Adaptadores de carga de datos tabulares desde disco."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_dataframe(path: str) -> pd.DataFrame:
    """Carga un DataFrame desde archivo CSV o Excel.

    Entradas:
        path: Ruta absoluta o relativa del archivo de entrada.

    Salidas:
        DataFrame con el contenido tabular del archivo.

    Errores relevantes:
        ValueError: Si la extensión no está soportada.
        FileNotFoundError: Si la ruta no existe.
        pandas.errors.ParserError: Si el archivo está corrupto.
    """
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"No existe el archivo: {path}")

    suffix = file_path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(file_path)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(file_path)

    raise ValueError(f"Formato no soportado: {suffix}")
