"""Manejador global de excepciones no controladas."""

from __future__ import annotations

import json
import logging
import platform
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


def _default_show_error(message: str) -> None:
    try:
        from PySide6.QtWidgets import QMessageBox

        QMessageBox.critical(None, "Error inesperado", message)
    except Exception:
        logging.getLogger(__name__).error(message)


def install_global_crash_handler(
    crash_log_path: Path,
    *,
    show_error: Callable[[str], None] | None = None,
) -> None:
    """Instala sys.excepthook para registrar traceback y notificar al usuario."""
    crash_log_path.parent.mkdir(parents=True, exist_ok=True)
    show_cb = show_error or _default_show_error
    logger = logging.getLogger(__name__)

    def _handle(exc_type: type[BaseException], exc_value: BaseException, exc_tb: object) -> None:
        trace = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        crash_log_path.write_text(trace, encoding="utf-8")
        logger.exception("Excepción inesperada registrada en crash.log")
        show_cb("Ha ocurrido un error inesperado. Consulte crash.log")

    sys.excepthook = _handle


def run_with_crash_report(func, *, project_dir: Path, run_id: str, context: dict[str, object]) -> int:
    """Ejecuta una función y genera crash.json automáticamente ante fallos inesperados."""
    logger = logging.getLogger(__name__)
    try:
        return int(func())
    except Exception as exc:  # noqa: BLE001
        trace = traceback.format_exc()
        run_dir = project_dir / "logs" / "runs" / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        crash_path = run_dir / "crash.json"
        payload = {
            "run_id": run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "exception_type": exc.__class__.__name__,
            "message": str(exc),
            "traceback": trace,
            "context": context,
            "python_version": sys.version,
            "platform": platform.platform(),
        }
        crash_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        logger.critical("Run finalizado con crash inesperado. Reporte: %s", crash_path)
        return 5
