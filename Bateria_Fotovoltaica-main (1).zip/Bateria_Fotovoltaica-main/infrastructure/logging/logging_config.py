"""Configuración empresarial de logging para UI y ejecuciones de proyecto."""

from __future__ import annotations

import json
import logging
import time
import uuid
from contextlib import contextmanager
from datetime import datetime
from hashlib import sha256
from logging.handlers import RotatingFileHandler
from pathlib import Path

SESSION_ID = str(uuid.uuid4())


class SessionIDFilter(logging.Filter):
    """Inyecta session_id único por ejecución en todos los logs."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.session_id = SESSION_ID
        return True


def configure_logging(logs_dir: Path, *, debug: bool = False) -> tuple[Path, Path]:
    """Inicializa logs de aplicación y crash con formato empresarial."""
    logs_dir.mkdir(parents=True, exist_ok=True)
    app_log = logs_dir / "app.log"
    crash_log = logs_dir / "crash.log"

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.DEBUG if debug else logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(session_id)s | %(name)s | %(message)s",
    )
    session_filter = SessionIDFilter()

    app_handler = RotatingFileHandler(
        app_log,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    app_handler.setFormatter(formatter)
    app_handler.addFilter(session_filter)

    crash_handler = RotatingFileHandler(
        crash_log,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    crash_handler.setFormatter(formatter)
    crash_handler.setLevel(logging.ERROR)
    crash_handler.addFilter(session_filter)

    root.addHandler(app_handler)
    root.addHandler(crash_handler)

    logging.getLogger(__name__).info("Inicio aplicación")
    return app_log, crash_log


def generate_run_id(dataset_hash: str | None = None) -> str:
    """Genera un run_id UTC legible con hash corto estable."""
    timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H-%M-%S")
    entropy = f"{dataset_hash or 'run'}_{uuid.uuid4().hex}_{time.time_ns()}"
    short_hash = sha256(entropy.encode("utf-8")).hexdigest()[:8]
    return f"{timestamp}__{short_hash}"


def setup_project_logging(project_dir: Path, run_id: str, level: int = logging.INFO) -> Path:
    """Configura logging para una corrida de proyecto en <project>/logs/runs/<run_id>."""
    run_dir = project_dir / "logs" / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    run_log = run_dir / "run.log"

    root = logging.getLogger()
    root.setLevel(level)

    for handler in list(root.handlers):
        if getattr(handler, "_fv_project_logging", False):
            root.removeHandler(handler)
            handler.close()

    formatter = logging.Formatter("[%(asctime)s] [%(levelname)s] [%(module)s] %(message)s")

    file_handler = logging.FileHandler(run_log, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    file_handler._fv_project_logging = True  # type: ignore[attr-defined]

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(level)
    stream_handler.setFormatter(formatter)
    stream_handler._fv_project_logging = True  # type: ignore[attr-defined]

    root.addHandler(file_handler)
    root.addHandler(stream_handler)
    logging.getLogger(__name__).info("Run logging inicializado: %s", run_log)
    return run_dir


def write_environment_metadata(run_dir: Path, context: dict[str, object]) -> Path:
    """Persiste environment.json con metadata de reproducibilidad."""
    environment_path = run_dir / "environment.json"
    serializable = {
        key: (value if isinstance(value, (str, int, float, bool)) or value is None else str(value))
        for key, value in context.items()
    }
    environment_path.write_text(json.dumps(serializable, ensure_ascii=False, indent=2), encoding="utf-8")
    return environment_path


@contextmanager
def timed_block(name: str):
    """Mide y loggea duración de un bloque."""
    started = time.perf_counter()
    try:
        yield
    finally:
        duration = time.perf_counter() - started
        logging.getLogger(__name__).info("%s took %.3fs", name, duration)
