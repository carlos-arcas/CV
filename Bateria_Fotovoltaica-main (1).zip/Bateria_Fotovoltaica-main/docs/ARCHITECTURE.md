# Clean Architecture FV+BESS

## Diagrama de capas

```text
UI (app/ui)
   ↓
Application (app/application)
   ↓
Domain (app/domain)

Infrastructure (app/infrastructure) ──implements──> Application Ports
```

## Flujo de datos

1. UI invoca `RunSimulationUseCase` o `RunDimensioningUseCase`.
2. Application valida invariantes del dominio y orquesta el proceso.
3. Application usa `OptimizationPort`/`CachePort`/`ExportPort`.
4. Infrastructure implementa puertos (solver LP, cache, export, logging).
5. Se devuelven DTOs limpios hacia UI, sin DataFrames pesados.

## Responsabilidad por capa

- **Domain**: entidades, value objects, invariantes y excepciones de negocio. No usa pandas/numpy/scipy/PySide.
- **Application**: casos de uso y puertos. Solo depende de Domain.
- **Infrastructure**: integración técnica concreta (LP solver, cache, export, logging).
- **UI**: composición de controladores y presentación; consume DTOs sin cálculos energéticos.

## Por qué evita acoplamiento

- La capa Application depende de interfaces (`ports.py`), no de implementaciones concretas.
- Infrastructure queda reemplazable (ej. cambiar solver o cache) sin tocar reglas de negocio.
- Domain es estable y aislado, facilitando pruebas unitarias y evolución del sistema.
- UI queda desacoplada de fórmulas y detalles técnicos, reduciendo deuda técnica.
