# fv_bess_sim

Launcher profesional para herramienta interna Python con setup de entorno virtual, ejecución y build opcional a `.exe`.

## Requisitos

- Python **3.11+** (recomendado **3.12** o **3.13**).
- Windows (incluye scripts `.bat` y alternativas PowerShell).

## Estructura

- `app/main.py`: entrypoint real (`python -m app.main`).
- `app/settings.py`: constantes y rutas (`outputs/`, `logs/`).
- `scripts/setup_venv.*`: creación de `.venv` e instalación de dependencias.
- `scripts/run.*`: ejecución de la aplicación.
- `scripts/build.bat`: build de ejecutable con PyInstaller.

## Setup (una vez)

```bat
scripts\setup_venv.bat
```

Alternativa PowerShell:

```powershell
.\scripts\setup_venv.ps1
```

## Ejecutar

```bat
scripts\run.bat
```

Alternativa PowerShell:

```powershell
.\scripts\run.ps1
```

## Build EXE

```bat
scripts\build.bat
```

Salida esperada:

- `dist/fv_bess_sim.exe`

## Consejos operativos

- No abras archivos Excel destino mientras se exportan resultados.
- Los resultados se guardan en `outputs/`.
- Los logs se guardan en `logs/`.
- Si hay problemas de entorno, vuelve a ejecutar `scripts\setup_venv.bat`.
