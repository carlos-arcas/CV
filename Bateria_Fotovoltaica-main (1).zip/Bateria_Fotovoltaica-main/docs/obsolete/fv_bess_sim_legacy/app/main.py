"""Entrypoint principal de la aplicación.

Inicializa logging, prepara carpetas de trabajo y permite arrancar
una UI opcional mediante app.ui.run() si está disponible.
"""

from __future__ import annotations

import importlib
import logging
from typing import Callable

from app.settings import APP_NAME, APP_VERSION, LOGS_DIR, OUTPUTS_DIR


def _configure_logging() -> None:
    """Configura logging básico para consola y archivo."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOGS_DIR / f"{APP_NAME}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_file, encoding="utf-8")],
    )


def _run_optional_ui(logger: logging.Logger) -> None:
    """Intenta ejecutar app.ui.run() si el módulo existe."""
    try:
        ui_module = importlib.import_module("app.ui")
    except ModuleNotFoundError:
        logger.info("No se encontró app.ui. Continuando sin interfaz gráfica.")
        return

    run_func = getattr(ui_module, "run", None)
    if callable(run_func):
        logger.info("Iniciando interfaz gráfica desde app.ui.run()...")
        cast_run: Callable[[], None] = run_func
        cast_run()
    else:
        logger.info("El módulo app.ui existe, pero no define run().")


def main() -> int:
    """Punto de entrada principal de la herramienta.

    Returns:
        int: 0 si la ejecución finaliza correctamente.
    """
    _configure_logging()
    logger = logging.getLogger(APP_NAME)

    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    logger.info("%s v%s", APP_NAME, APP_VERSION)
    logger.info("Carpeta de salida: %s", OUTPUTS_DIR)

    print(f"{APP_NAME} v{APP_VERSION} - OK")

    _run_optional_ui(logger)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
