"""Configuración central de la herramienta FV BESS Sim.

Este módulo define constantes y rutas base para ejecución local,
outputs y logs sin depender de rutas absolutas.
"""

from pathlib import Path

APP_NAME = "fv_bess_sim"
APP_VERSION = "0.1.0"

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUTS_DIR = BASE_DIR / "outputs"
LOGS_DIR = BASE_DIR / "logs"
