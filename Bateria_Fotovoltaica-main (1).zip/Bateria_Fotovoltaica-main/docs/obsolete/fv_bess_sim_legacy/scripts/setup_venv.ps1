$ErrorActionPreference = "Stop"

Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "[INFO] Verificando Python..."
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error "Python no está disponible en PATH."
    exit 1
}

$venvPython = ".venv/Scripts/python.exe"
if (-not (Test-Path $venvPython)) {
    Write-Host "[INFO] Creando entorno virtual .venv..."
    python -m venv .venv
}
else {
    Write-Host "[INFO] Entorno virtual .venv ya existe."
}

& ".venv/Scripts/Activate.ps1"

Write-Host "[INFO] Actualizando pip..."
python -m pip install --upgrade pip

Write-Host "[INFO] Instalando dependencias base..."
pip install -r requirements.txt

Write-Host "[OK] Entorno listo."
exit 0
