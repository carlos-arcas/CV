$ErrorActionPreference = "Stop"

Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path ".venv/Scripts/python.exe")) {
    Write-Error "No existe .venv. Ejecuta scripts/setup_venv.ps1 primero."
    exit 1
}

& ".venv/Scripts/Activate.ps1"

python -m app.main
exit $LASTEXITCODE
