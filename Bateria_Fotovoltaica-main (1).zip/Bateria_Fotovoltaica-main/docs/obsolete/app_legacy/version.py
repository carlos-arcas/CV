"""Versionado semántico de la aplicación."""

__version__ = "1.1.0"
