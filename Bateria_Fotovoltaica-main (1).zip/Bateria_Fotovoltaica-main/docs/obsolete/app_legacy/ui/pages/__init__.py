"""Submódulo de páginas UI (presentación)."""
