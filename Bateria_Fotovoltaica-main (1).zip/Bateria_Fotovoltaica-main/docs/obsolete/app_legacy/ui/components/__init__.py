"""Submódulo de componentes UI (presentación)."""
