"""Fachada UI que consume únicamente DTOs de aplicación."""

from __future__ import annotations

from dataclasses import dataclass

from app.application.dto import DimensioningResultDTO, SimulationResultDTO
from app.application.use_cases.run_dimensioning import RunDimensioningUseCase
from app.application.use_cases.run_simulation import RunSimulationUseCase
from app.domain.entities import ScenarioConfig


@dataclass(slots=True)
class MainWindowController:
    """Controlador de UI sin lógica de negocio ni fórmulas energéticas."""

    run_simulation_use_case: RunSimulationUseCase
    run_dimensioning_use_case: RunDimensioningUseCase

    def run_simulation(self, dataset_path: str, scenario: ScenarioConfig) -> SimulationResultDTO:
        return self.run_simulation_use_case.execute(dataset_path=dataset_path, scenario=scenario)

    def run_dimensioning(
        self,
        dataset_path: str,
        scenario: ScenarioConfig,
        capacities_kwh: list[float],
        powers_kw: list[float],
    ) -> DimensioningResultDTO:
        return self.run_dimensioning_use_case.execute(
            dataset_path=dataset_path,
            base_scenario=scenario,
            capacities_kwh=capacities_kwh,
            powers_kw=powers_kw,
        )
