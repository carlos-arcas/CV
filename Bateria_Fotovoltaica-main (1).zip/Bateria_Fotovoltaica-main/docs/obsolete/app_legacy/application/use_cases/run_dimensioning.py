"""Caso de uso para barrer configuraciones y generar ranking de dimensionamiento."""

from __future__ import annotations

from dataclasses import dataclass

from app.application.dto import DimensioningCandidateDTO, DimensioningResultDTO
from app.application.ports import OptimizationPort
from app.domain.entities import Battery, ScenarioConfig
from app.domain.value_objects import SimulationMetadata


@dataclass(slots=True)
class RunDimensioningUseCase:
    """Evalúa múltiples combinaciones capacidad/potencia y devuelve ranking."""

    optimization_port: OptimizationPort

    def execute(
        self,
        dataset_path: str,
        base_scenario: ScenarioConfig,
        capacities_kwh: list[float],
        powers_kw: list[float],
        top_n: int = 5,
    ) -> DimensioningResultDTO:
        """Ejecuta simulaciones múltiples con validación previa y control de errores."""
        if not capacities_kwh or not powers_kw:
            raise ValueError("Debes indicar capacidades y potencias para dimensionar.")

        candidates: list[DimensioningCandidateDTO] = []
        metadata: SimulationMetadata | None = None
        for capacity in capacities_kwh:
            for power in powers_kw:
                scenario = ScenarioConfig(
                    battery=Battery(
                        capacity_kwh=float(capacity),
                        power_kw=float(power),
                        soc_initial_pct=base_scenario.battery.soc_initial_pct,
                        soc_min_pct=base_scenario.battery.soc_min_pct,
                        charge_efficiency=base_scenario.battery.charge_efficiency,
                        discharge_efficiency=base_scenario.battery.discharge_efficiency,
                    ),
                    tariff=base_scenario.tariff,
                    grid=base_scenario.grid,
                    timestep_minutes=base_scenario.timestep_minutes,
                )
                result = self.optimization_port.run_simulation(dataset_path, scenario)
                metadata = result.metadatos
                candidates.append(
                    DimensioningCandidateDTO(
                        capacidad_kwh=float(capacity),
                        potencia_kw=float(power),
                        ahorro_total=result.ahorro_total,
                    )
                )

        ranking = sorted(candidates, key=lambda x: x.ahorro_total, reverse=True)[:top_n]
        return DimensioningResultDTO(
            ranking=ranking,
            metadatos=metadata
            or SimulationMetadata(dataset_hash="unknown", solution_mode="lp", version="unknown"),
        )
