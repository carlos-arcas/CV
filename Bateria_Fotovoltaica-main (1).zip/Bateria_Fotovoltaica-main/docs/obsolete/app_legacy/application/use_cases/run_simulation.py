"""Caso de uso para ejecutar una simulación individual."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from app.application.dto import SimulationResultDTO
from app.application.ports import CachePort, OptimizationPort
from app.domain.entities import ScenarioConfig
from app.domain.exceptions import SimulationApplicationError
from app.domain.invariants import validate_scenario
from app.infrastructure.persistence.cache_repository import build_cache_hash

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class RunSimulationUseCase:
    """Orquesta la simulación de un escenario FV+BESS y devuelve DTO para UI."""

    optimization_port: OptimizationPort
    cache_port: CachePort | None = None

    def execute(self, dataset_path: str, scenario: ScenarioConfig) -> SimulationResultDTO:
        """Valida entrada, consulta cache opcional y ejecuta solver vía puerto."""
        if not dataset_path:
            raise SimulationApplicationError("dataset_path es obligatorio.")
        validate_scenario(scenario)

        dataset_file = Path(dataset_path)
        dataset_bytes = dataset_file.read_bytes() if dataset_file.exists() else dataset_path.encode("utf-8")
        config_payload = json.dumps(asdict(scenario), sort_keys=True)
        cache_key = build_cache_hash(dataset_bytes, config_payload)

        if self.cache_port:
            cached = self.cache_port.get(cache_key)
            if cached is not None:
                logger.info("CACHE HIT: %s", cache_key)
                return cached
            logger.info("CACHE MISS: %s", cache_key)

        start = time.perf_counter()
        logger.info("Inicio simulación")
        try:
            result = self.optimization_port.run_simulation(dataset_path=dataset_path, scenario=scenario)
        except SimulationApplicationError:
            logger.exception("Error controlado durante simulación")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("Excepción inesperada durante simulación")
            raise SimulationApplicationError(f"Error ejecutando simulación: {exc}") from exc
        finally:
            elapsed = time.perf_counter() - start
            logger.info("Fin simulación. tiempo_ejecucion_s=%.4f", elapsed)

        if self.cache_port:
            self.cache_port.set(cache_key, result)
        return result
