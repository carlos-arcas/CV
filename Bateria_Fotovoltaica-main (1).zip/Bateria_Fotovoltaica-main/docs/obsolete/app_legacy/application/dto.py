"""DTOs de salida para UI y capa externa."""

from __future__ import annotations

from dataclasses import dataclass

from app.domain.value_objects import SimulationMetadata


@dataclass(frozen=True, slots=True)
class SimulationResultDTO:
    ahorro_total: float
    ahorro_mensual: dict[str, float]
    autoconsumo: float
    curva_soc: list[float]
    metadatos: SimulationMetadata


@dataclass(frozen=True, slots=True)
class DimensioningCandidateDTO:
    capacidad_kwh: float
    potencia_kw: float
    ahorro_total: float


@dataclass(frozen=True, slots=True)
class DimensioningResultDTO:
    ranking: list[DimensioningCandidateDTO]
    metadatos: SimulationMetadata
