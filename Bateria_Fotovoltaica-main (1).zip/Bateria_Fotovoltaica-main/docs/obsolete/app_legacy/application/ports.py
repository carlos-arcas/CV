"""Puertos de aplicación para desacoplar infraestructura."""

from __future__ import annotations

from typing import Protocol

from app.application.dto import SimulationResultDTO
from app.domain.entities import ScenarioConfig


class OptimizationPort(Protocol):
    def run_simulation(self, dataset_path: str, scenario: ScenarioConfig) -> SimulationResultDTO:
        """Ejecuta optimización técnica y devuelve DTO limpio."""


class CachePort(Protocol):
    def get(self, key: str) -> SimulationResultDTO | None:
        ...

    def set(self, key: str, value: SimulationResultDTO) -> None:
        ...


class ExportPort(Protocol):
    def export(self, result: SimulationResultDTO, output_path: str) -> None:
        ...
