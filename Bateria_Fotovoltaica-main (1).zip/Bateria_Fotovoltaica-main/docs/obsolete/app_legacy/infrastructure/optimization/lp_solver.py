"""Adaptador de infraestructura que implementa OptimizationPort con motor LP."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import asdict
from datetime import timedelta

import pandas as pd

from app.application.dto import SimulationResultDTO
from app.application.ports import OptimizationPort
from app.domain.entities import ScenarioConfig
from app.domain.exceptions import SimulationError, ValidationError
from app.domain.value_objects import SimulationMetadata
from infrastructure.version import __version__
from application.engine import SimulationEngine
from application.use_cases import LoadDatasetUseCase, ValidateAndNormalizeUseCase
from domain.models import BatteryParams, GridParams, TariffParams
from domain.models import ScenarioConfig as LegacyScenarioConfig

logger = logging.getLogger(__name__)
REQUIRED_COLUMNS = {"timestamp", "load", "pv", "buy_price", "sell_price"}


class LPSolverAdapter(OptimizationPort):
    """Implementación del puerto de optimización usando el solver LP definitivo."""

    def run_simulation(self, dataset_path: str, scenario: ScenarioConfig) -> SimulationResultDTO:
        dataset_hash = hashlib.sha256(pd.read_csv(dataset_path).to_csv(index=False).encode("utf-8")).hexdigest() if dataset_path.endswith('.csv') else "unknown"
        logger.info("Carga dataset ruta=%s hash=%s", dataset_path, dataset_hash)

        loader = LoadDatasetUseCase()
        normalizer = ValidateAndNormalizeUseCase()
        input_dto = normalizer.execute(loader.execute(dataset_path))
        self._validate_dataset(input_dto.dataframe)

        legacy_scenario = LegacyScenarioConfig(
            battery=BatteryParams(**asdict(scenario.battery)),
            tariff=TariffParams(default_buy_eur_kwh=0.0, default_sell_eur_kwh=0.0, allow_sell=scenario.tariff.allow_sell),
            grid=GridParams(allow_grid_charging=True, grid_import_limit_kw=scenario.grid.grid_import_limit_kw),
            timestep_minutes=scenario.timestep_minutes,
        )

        result = SimulationEngine().simulate_year(df_norm=input_dto.dataframe, config=legacy_scenario, include_period_detail=True)
        series: pd.DataFrame = result.series
        self._validate_solution(series, scenario)

        monthly = series.assign(month=pd.to_datetime(series["timestamp"]).dt.to_period("M").astype(str)).groupby("month")["savings"].sum()
        total_load = float(series["load"].sum()) if "load" in series else 0.0
        autoconsumo = float(series["pv_used_load"].sum() / total_load) if total_load > 0 else 0.0

        metadata = SimulationMetadata(
            dataset_hash=input_dto.dataset_hash or dataset_hash,
            solution_mode=str(result.kpis.get("solver_mode", "lp_scipy")),
            version=__version__,
        )
        return SimulationResultDTO(
            ahorro_total=float(result.kpis.get("total_savings_eur", 0.0)),
            ahorro_mensual={str(k): float(v) for k, v in monthly.items()},
            autoconsumo=autoconsumo,
            curva_soc=[float(v) for v in series.get("soc_end", pd.Series(dtype=float)).tolist()],
            metadatos=metadata,
        )

    def _validate_dataset(self, df: pd.DataFrame) -> None:
        missing = REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise ValidationError(f"Columnas obligatorias faltantes: {sorted(missing)}")
        if df[list(REQUIRED_COLUMNS)].isna().any().any():
            raise ValidationError("El dataset contiene NaN en columnas obligatorias")
        if (df[["load", "pv", "buy_price", "sell_price"]] < 0).any().any():
            raise ValidationError("El dataset contiene valores negativos")

        ts = pd.to_datetime(df["timestamp"]).sort_values()
        if ts.empty:
            raise ValidationError("Dataset sin timestamps")
        deltas = ts.diff().dropna()
        if (deltas != timedelta(minutes=15)).any():
            raise ValidationError("Las fechas no son consecutivas a 15 minutos")

    def _validate_solution(self, series: pd.DataFrame, scenario: ScenarioConfig) -> None:
        soc_min = scenario.battery.soc_min_pct / 100.0 * scenario.battery.capacity_kwh
        soc_max = scenario.battery.capacity_kwh
        if "soc_end" in series:
            soc = series["soc_end"]
            if soc.isna().any() or (soc < soc_min - 1e-6).any() or (soc > soc_max + 1e-6).any():
                logger.critical("SoC fuera de límites")
                raise SimulationError("SoC fuera de límites")

        non_negative = [c for c in ["charge", "discharge", "grid_import", "grid_export"] if c in series]
        if non_negative and (series[non_negative] < -1e-9).any().any():
            logger.critical("Flujos negativos detectados")
            raise SimulationError("Flujos negativos detectados")

        numeric = series.select_dtypes(include=["number"])
        if numeric.isna().any().any():
            logger.critical("NaN en resultados numéricos")
            raise SimulationError("NaN en resultados numéricos")

        if {"load", "pv_used_load", "discharge_to_load"}.issubset(series.columns):
            served = series["pv_used_load"] + series["discharge_to_load"]
            if (served - series["load"] > 1e-4).any():
                logger.critical("Balance energético inconsistente")
                raise SimulationError("Balance energético inconsistente")
