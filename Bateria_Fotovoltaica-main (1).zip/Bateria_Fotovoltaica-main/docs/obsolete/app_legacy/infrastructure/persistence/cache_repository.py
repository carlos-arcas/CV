"""Repositorio de cache por hash SHA256 persistido en disco."""

from __future__ import annotations

import hashlib
import pickle
from pathlib import Path

from app.application.dto import SimulationResultDTO
from app.application.ports import CachePort


class HashCacheRepository(CachePort):
    def __init__(self, cache_dir: Path | str = Path("outputs/cache")) -> None:
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    def get(self, key: str) -> SimulationResultDTO | None:
        path = self._cache_dir / f"{key}.pkl"
        if not path.exists():
            return None
        with path.open("rb") as fh:
            return pickle.load(fh)  # noqa: S301 - cache local de la app

    def set(self, key: str, value: SimulationResultDTO) -> None:
        path = self._cache_dir / f"{key}.pkl"
        with path.open("wb") as fh:
            pickle.dump(value, fh)


def build_cache_hash(dataset_bytes: bytes, config_payload: str) -> str:
    digest = hashlib.sha256()
    digest.update(dataset_bytes)
    digest.update(config_payload.encode("utf-8"))
    return digest.hexdigest()
