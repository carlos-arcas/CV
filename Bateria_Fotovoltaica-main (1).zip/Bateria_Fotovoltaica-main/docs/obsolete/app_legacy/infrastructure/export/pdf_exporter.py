"""Exportador PDF mínimo de resultados."""

from __future__ import annotations

from pathlib import Path

from app.application.dto import SimulationResultDTO
from app.application.ports import ExportPort


class PdfExporter(ExportPort):
    def export(self, result: SimulationResultDTO, output_path: str) -> None:
        content = (
            "Reporte FV+BESS\n"
            f"Ahorro total: {result.ahorro_total:.2f} EUR\n"
            f"Autoconsumo: {result.autoconsumo:.4f}\n"
            f"Metadata: {result.metadatos}\n"
        )
        Path(output_path).write_text(content, encoding="utf-8")
