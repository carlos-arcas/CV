"""Exportador profesional de resultados a Excel con escritura atómica."""

from __future__ import annotations

import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path

import pandas as pd

from app.application.dto import SimulationResultDTO
from app.application.ports import ExportPort
from infrastructure.version import __version__

logger = logging.getLogger(__name__)


class ExcelExporter(ExportPort):
    def export(self, result: SimulationResultDTO, output_path: str) -> None:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        resumen = pd.DataFrame(
            {
                "campo": [
                    "version_app",
                    "fecha_simulacion",
                    "modo_solucion",
                    "hash_dataset",
                    "ahorro_total",
                    "autoconsumo",
                ],
                "valor": [
                    __version__,
                    datetime.now().isoformat(timespec="seconds"),
                    result.metadatos.solution_mode,
                    result.metadatos.dataset_hash,
                    result.ahorro_total,
                    result.autoconsumo,
                ],
            }
        )
        mensual = pd.DataFrame(list(result.ahorro_mensual.items()), columns=["mes", "ahorro_eur"])
        detalle = pd.DataFrame({"soc": result.curva_soc})

        fd, tmp_path = tempfile.mkstemp(suffix=".xlsx", dir=str(output.parent))
        os.close(fd)
        try:
            with pd.ExcelWriter(tmp_path) as writer:
                resumen.to_excel(writer, index=False, sheet_name="Resumen Ejecutivo")
                mensual.to_excel(writer, index=False, sheet_name="Resultados Mensuales")
                if not detalle.empty:
                    detalle.to_excel(writer, index=False, sheet_name="Detalle Horario")
            Path(tmp_path).replace(output)
            logger.info("Export generado en %s", output)
        except PermissionError as exc:
            try:
                from PySide6.QtWidgets import QMessageBox

                QMessageBox.warning(None, "Exportación bloqueada", "No se puede escribir el archivo. Cierre el Excel y reintente.")
            except Exception:
                logger.warning("No se pudo mostrar QMessageBox para archivo bloqueado")
            logger.exception("Error controlado al exportar: archivo abierto")
            raise exc
        finally:
            if Path(tmp_path).exists():
                Path(tmp_path).unlink(missing_ok=True)
