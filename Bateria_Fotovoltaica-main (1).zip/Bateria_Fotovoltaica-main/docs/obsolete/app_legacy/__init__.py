"""Compat package para ejecutar `python -m app.main` desde la raíz."""
