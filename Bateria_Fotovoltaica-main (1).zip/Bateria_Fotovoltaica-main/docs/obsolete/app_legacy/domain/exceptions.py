"""Excepciones del dominio y aplicación."""


class DomainError(Exception):
    """Error base de dominio."""


class ValidationError(DomainError):
    """Error de validación de invariantes."""


class SimulationError(DomainError):
    """Error de consistencia/resultado de simulación."""


class SimulationApplicationError(Exception):
    """Error controlado en capa de aplicación."""
