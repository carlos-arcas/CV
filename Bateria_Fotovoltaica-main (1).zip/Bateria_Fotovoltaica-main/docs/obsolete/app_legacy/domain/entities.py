"""Entidades de dominio puras para simulación FV+BESS."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Battery:
    capacity_kwh: float
    power_kw: float
    soc_initial_pct: float
    soc_min_pct: float
    charge_efficiency: float
    discharge_efficiency: float


@dataclass(frozen=True, slots=True)
class Tariff:
    allow_sell: bool


@dataclass(frozen=True, slots=True)
class Grid:
    grid_import_limit_kw: float | None = None


@dataclass(frozen=True, slots=True)
class ScenarioConfig:
    """Configuración de negocio requerida para ejecutar una simulación."""

    battery: Battery
    tariff: Tariff
    grid: Grid
    timestep_minutes: int = 15
