"""Reglas e invariantes del dominio FV+BESS."""

from __future__ import annotations

from app.domain.entities import ScenarioConfig
from app.domain.exceptions import ValidationError


def validate_scenario(config: ScenarioConfig) -> None:
    if config.timestep_minutes != 15:
        raise ValidationError("Solo se admite timestep de 15 minutos.")
    if config.battery.capacity_kwh <= 0:
        raise ValidationError("capacity_kwh debe ser > 0.")
    if config.battery.power_kw <= 0:
        raise ValidationError("power_kw debe ser > 0.")
    if not 0 <= config.battery.soc_min_pct <= config.battery.soc_initial_pct <= 100:
        raise ValidationError("SoC inválido: debe cumplirse 0 <= soc_min <= soc_initial <= 100.")
    if not 0 < config.battery.charge_efficiency <= 1:
        raise ValidationError("charge_efficiency fuera de rango (0,1].")
    if not 0 < config.battery.discharge_efficiency <= 1:
        raise ValidationError("discharge_efficiency fuera de rango (0,1].")
