"""Value objects del dominio."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SimulationMetadata:
    dataset_hash: str
    solution_mode: str
    version: str
