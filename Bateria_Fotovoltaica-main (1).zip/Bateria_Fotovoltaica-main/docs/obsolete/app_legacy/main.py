"""Launcher compatible con `python -m app.main`."""

from __future__ import annotations

from main import parse_args
from ui.main import run_ui

if __name__ == "__main__":
    args = parse_args()
    raise SystemExit(run_ui(debug=args.debug, export_detail=args.export_detail, no_cache=args.no_cache))
