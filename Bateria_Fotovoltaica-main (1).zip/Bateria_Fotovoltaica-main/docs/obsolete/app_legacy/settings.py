"""Configuración central de rutas y banderas de ejecución."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class AppSettings:
    outputs_dir: Path = Path("outputs")
    logs_dir: Path = Path("logs")
    cache_dir: Path = Path("cache")
    debug_mode: bool = False
    export_detail: bool = False
    use_cache: bool = True

    def ensure_dirs(self) -> None:
        self.outputs_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)


def build_settings(*, debug: bool = False, export_detail: bool = False, no_cache: bool = False) -> AppSettings:
    settings = AppSettings(debug_mode=debug, export_detail=export_detail, use_cache=not no_cache)
    settings.ensure_dirs()
    return settings
