from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PATTERNS = [
    re.compile(r"\bimport\s+app(\.|\b)"),
    re.compile(r"\bfrom\s+app(\.|\b)"),
    re.compile(r"\bfv_bess_sim\b"),
]


def iter_python_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*.py"):
        rel = path.relative_to(ROOT)
        if rel.parts[0] in {".git", ".venv", "venv", "__pycache__"}:
            continue
        if rel.parts[0] == "docs" and len(rel.parts) > 1 and rel.parts[1] == "obsolete":
            continue
        files.append(path)
    return files


def main() -> int:
    violations: list[str] = []
    for file_path in iter_python_files():
        for line_no, line in enumerate(file_path.read_text(encoding="utf-8").splitlines(), start=1):
            if any(pattern.search(line) for pattern in PATTERNS):
                violations.append(f"{file_path.relative_to(ROOT)}:{line_no}: {line.strip()}")

    if violations:
        print("Legacy imports/references detected:")
        for item in violations:
            print(f" - {item}")
        return 1

    print("OK: no legacy imports/references found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
