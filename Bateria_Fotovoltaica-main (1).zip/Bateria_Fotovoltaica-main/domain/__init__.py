"""Paquete de dominio."""
