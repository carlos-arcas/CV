"""Modelos de dominio principales para escenarios de simulación BESS/FV."""

from dataclasses import dataclass
from enum import StrEnum


class SimulationMode(StrEnum):
    """Modos de simulación disponibles para el motor."""

    OPTIMAL = "optimal"
    FAST = "fast"

@dataclass(slots=True)
class BatteryParams:
    """Parámetros técnicos y operativos de la batería.

    Entradas:
        capacity_kwh: Capacidad útil de la batería en kWh.
        power_kw: Potencia máxima de carga/descarga en kW.
        soc_initial_pct: Estado de carga inicial en porcentaje [0-100].
        soc_min_pct: Estado de carga mínimo permitido en porcentaje [0-100].
        charge_efficiency: Eficiencia de carga en rango (0, 1].
        discharge_efficiency: Eficiencia de descarga en rango (0, 1].

    Salidas:
        Instancia inmutable por convención con la configuración del BESS.

    Errores relevantes:
        ValueError: Si algún parámetro queda fuera de rango físico.
    """

    capacity_kwh: float = 10.0
    power_kw: float = 5.0
    soc_initial_pct: float = 50.0
    soc_min_pct: float = 10.0
    charge_efficiency: float = 0.95
    discharge_efficiency: float = 0.95

    def __post_init__(self) -> None:
        """Valida coherencia física básica de los parámetros de batería."""
        if self.capacity_kwh <= 0:
            raise ValueError("capacity_kwh debe ser mayor que 0.")
        if self.power_kw <= 0:
            raise ValueError("power_kw debe ser mayor que 0.")
        if not 0 <= self.soc_min_pct <= 100:
            raise ValueError("soc_min_pct debe estar entre 0 y 100.")
        if not 0 <= self.soc_initial_pct <= 100:
            raise ValueError("soc_initial_pct debe estar entre 0 y 100.")
        if self.soc_initial_pct < self.soc_min_pct:
            raise ValueError("soc_initial_pct no puede ser menor que soc_min_pct.")
        if not 0 < self.charge_efficiency <= 1:
            raise ValueError("charge_efficiency debe estar en (0, 1].")
        if not 0 < self.discharge_efficiency <= 1:
            raise ValueError("discharge_efficiency debe estar en (0, 1].")


@dataclass(slots=True)
class TariffParams:
    """Parámetros de tarifa para compra/venta de energía.

    Entradas:
        default_buy_eur_kwh: Precio por defecto de compra en EUR/kWh.
        default_sell_eur_kwh: Precio por defecto de venta en EUR/kWh.
        allow_sell: Define si se permite exportar energía a red.

    Salidas:
        Objeto de configuración de precios de mercado.

    Errores relevantes:
        ValueError: Si los precios son negativos.
    """

    default_buy_eur_kwh: float = 0.20
    default_sell_eur_kwh: float = 0.0
    allow_sell: bool = False

    def __post_init__(self) -> None:
        """Valida precios base de compra y venta."""
        if self.default_buy_eur_kwh < 0:
            raise ValueError("default_buy_eur_kwh no puede ser negativo.")
        if self.default_sell_eur_kwh < 0:
            raise ValueError("default_sell_eur_kwh no puede ser negativo.")


@dataclass(slots=True)
class GridParams:
    """Parámetros operativos relacionados con la red eléctrica.

    Entradas:
        allow_grid_charging: Permite cargar batería desde la red.
        grid_import_limit_kw: Límite de importación en kW, opcional.

    Salidas:
        Configuración de reglas de interacción con red.

    Errores relevantes:
        ValueError: Si el límite de importación informado no es positivo.
    """

    allow_grid_charging: bool = True
    grid_import_limit_kw: float | None = None

    def __post_init__(self) -> None:
        """Valida límites de importación cuando están definidos."""
        if self.grid_import_limit_kw is not None and self.grid_import_limit_kw <= 0:
            raise ValueError("grid_import_limit_kw debe ser mayor que 0 o None.")


@dataclass(slots=True)
class ScenarioConfig:
    """Configuración agregada de escenario para ejecutar simulaciones.

    Entradas:
        battery: Parámetros de batería.
        tariff: Parámetros tarifarios.
        grid: Parámetros de red.
        timestep_minutes: Resolución temporal en minutos.

    Salidas:
        Estructura única para transportar configuración de escenario.

    Errores relevantes:
        ValueError: Si el timestep es distinto de 15 min en este MVP.
    """

    battery: BatteryParams
    tariff: TariffParams
    grid: GridParams
    timestep_minutes: int = 15

    def __post_init__(self) -> None:
        """Valida reglas mínimas de consistencia para el escenario."""
        if self.timestep_minutes != 15:
            raise ValueError("El timestep interno soportado en este paso es 15 minutos.")


BatteryConfig = BatteryParams
