"""Excepciones de dominio para validación, simulación y exportación."""


class DomainError(Exception):
    """Error base de dominio con mensaje orientado a usuario técnico."""


class ValidationError(DomainError):
    """Error de validación de reglas de negocio o parámetros inválidos."""


class DataSchemaError(ValidationError):
    """Error de esquema cuando faltan columnas requeridas o tipos válidos."""


class SimulationError(DomainError):
    """Error controlado durante simulación con contexto reproducible."""


class ExportError(DomainError):
    """Error controlado en persistencia/export de resultados."""
