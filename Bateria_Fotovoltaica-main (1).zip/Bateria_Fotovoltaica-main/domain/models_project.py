"""Modelos de dominio para persistencia de proyectos y referencias ML."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ModelBundleRef:
    """Referencia a un bundle de modelos entrenados y su metadata resumida."""

    name: str
    folder: str
    trained_at: str | None = None
    metrics: dict[str, float] = field(default_factory=dict)
    app_version: str = "1.0.0"
    schema_version: int = 1


@dataclass(slots=True)
class ProjectConfig:
    """Configuración persistible de un proyecto de simulación completo."""

    name: str
    data_path: str = ""
    model_folder: str = ""
    export_folder: str = ""
    scenario: dict[str, object] = field(default_factory=dict)
    results_cache_path: str | None = None
    model_bundle: ModelBundleRef | None = None
    app_version: str = "1.0.0"
    schema_version: int = 1
