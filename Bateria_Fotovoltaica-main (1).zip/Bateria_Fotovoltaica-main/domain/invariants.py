"""Helpers de invariantes para robustez en simulación."""

from __future__ import annotations

import math
from typing import Any

from domain.errors import SimulationError


def clamp_soc(value: float, *, soc_min: float, soc_max: float) -> float:
    """Acota SoC a límites físicos configurados."""
    return max(soc_min, min(soc_max, float(value)))


def assert_finite(value: float, *, label: str, context: dict[str, Any]) -> None:
    """Valida que un valor escalar sea finito."""
    if not math.isfinite(float(value)):
        raise SimulationError(f"{label} no es finito. Contexto: {context}")


def assert_non_negative(value: float, *, label: str, context: dict[str, Any], tol: float = 1e-9) -> None:
    """Valida que un valor energético no sea negativo."""
    if float(value) < -tol:
        raise SimulationError(f"{label} negativo ({value}). Contexto: {context}")


def assert_soc_bounds(value: float, *, soc_min: float, soc_max: float, context: dict[str, Any], tol: float = 1e-6) -> None:
    """Valida que SoC permanezca dentro de los límites de batería."""
    if value < soc_min - tol or value > soc_max + tol:
        raise SimulationError(
            f"SoC fuera de rango [{soc_min}, {soc_max}] => {value}. Contexto: {context}"
        )
