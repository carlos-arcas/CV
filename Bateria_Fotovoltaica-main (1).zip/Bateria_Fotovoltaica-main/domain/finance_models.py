"""Modelos de dominio para cálculos financieros de escenarios BESS."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class CapexParams:
    """Parámetros de inversión inicial para escenario de compra (CAPEX).

    Entradas:
        battery_cost_eur_per_kwh: Coste unitario de batería en EUR/kWh.
        inverter_cost_eur_per_kw: Coste unitario de inversor en EUR/kW.
        installation_fixed_cost_eur: Coste fijo de instalación en EUR.

    Salidas:
        Estructura validada para calcular la inversión total.

    Errores relevantes:
        ValueError: Si algún coste es negativo.
    """

    battery_cost_eur_per_kwh: float = 350.0
    inverter_cost_eur_per_kw: float = 120.0
    installation_fixed_cost_eur: float = 1500.0

    def __post_init__(self) -> None:
        if self.battery_cost_eur_per_kwh < 0:
            raise ValueError("battery_cost_eur_per_kwh no puede ser negativo.")
        if self.inverter_cost_eur_per_kw < 0:
            raise ValueError("inverter_cost_eur_per_kw no puede ser negativo.")
        if self.installation_fixed_cost_eur < 0:
            raise ValueError("installation_fixed_cost_eur no puede ser negativo.")


@dataclass(slots=True)
class OpexParams:
    """Parámetros de coste operativo anual (OPEX).

    Entradas:
        annual_maintenance_eur: Coste anual de mantenimiento en EUR.

    Salidas:
        Configuración de egresos anuales recurrentes.

    Errores relevantes:
        ValueError: Si el mantenimiento anual es negativo.
    """

    annual_maintenance_eur: float = 0.0

    def __post_init__(self) -> None:
        if self.annual_maintenance_eur < 0:
            raise ValueError("annual_maintenance_eur no puede ser negativo.")


@dataclass(slots=True)
class FinancingParams:
    """Parámetros de financiación por préstamo con amortización francesa.

    Entradas:
        annual_interest_pct: Interés nominal anual en porcentaje [0, 100].
        term_months: Plazo en meses del préstamo.
        down_payment_eur: Entrada inicial en EUR aplicada al principal.

    Salidas:
        Configuración lista para calcular cuotas y tabla de amortización.

    Errores relevantes:
        ValueError: Si el plazo no es positivo o el interés es negativo.
    """

    annual_interest_pct: float = 6.0
    term_months: int = 60
    down_payment_eur: float = 0.0

    def __post_init__(self) -> None:
        if self.annual_interest_pct < 0:
            raise ValueError("annual_interest_pct no puede ser negativo.")
        if self.term_months <= 0:
            raise ValueError("term_months debe ser mayor que 0.")
        if self.down_payment_eur < 0:
            raise ValueError("down_payment_eur no puede ser negativo.")


@dataclass(slots=True)
class RentalParams:
    """Parámetros comerciales y financieros para renting/alquiler.

    Entradas:
        term_months: Plazo del contrato de renting en meses.
        annual_cost_of_capital_pct: Coste anual interno de capital en %.
        margin_pct: Margen comercial aplicado a la cuota base en %.
        minimum_monthly_fee_eur: Cuota mínima comercial opcional.
        residual_value_pct: Valor residual al final del contrato en % del CAPEX.

    Salidas:
        Configuración para construir cuota cliente y margen proveedor.

    Errores relevantes:
        ValueError: Si porcentajes están fuera de rango o plazo inválido.
    """

    term_months: int = 60
    annual_cost_of_capital_pct: float = 7.0
    margin_pct: float = 15.0
    minimum_monthly_fee_eur: float | None = None
    residual_value_pct: float = 0.0

    def __post_init__(self) -> None:
        if self.term_months <= 0:
            raise ValueError("term_months debe ser mayor que 0.")
        if self.annual_cost_of_capital_pct < 0:
            raise ValueError("annual_cost_of_capital_pct no puede ser negativo.")
        if self.margin_pct < 0:
            raise ValueError("margin_pct no puede ser negativo.")
        if self.minimum_monthly_fee_eur is not None and self.minimum_monthly_fee_eur < 0:
            raise ValueError("minimum_monthly_fee_eur no puede ser negativo.")
        if not 0 <= self.residual_value_pct <= 100:
            raise ValueError("residual_value_pct debe estar entre 0 y 100.")


@dataclass(slots=True)
class FinancialScenario:
    """Escenario financiero con multiplicador de ahorro y etiqueta descriptiva."""

    name: str
    savings_multiplier: float


@dataclass(slots=True)
class FinancialResults:
    """Resultado agregado del análisis financiero para compra, préstamo y renting."""

    annual_savings_eur: float
    monthly_savings_eur: list[float]
    capex_total_eur: float
    purchase_payback_years: float | None
    purchase_roi_annual: float | None
    npv_eur: float | None
    loan_monthly_payment_eur: float | None
    loan_payback_month: int | None
    rental_base_fee_eur: float | None
    rental_customer_fee_eur: float | None
    rental_total_margin_eur: float | None
    rental_monthly_margin_eur: float | None
    customer_monthly_benefit_eur: float | None
    scenarios: list[dict[str, float | str]] = field(default_factory=list)
    amortization_schedule: list[dict[str, float | int]] = field(default_factory=list)
