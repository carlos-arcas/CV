"""Pruebas para escenario con venta desactivada."""

from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_no_sell_forces_zero_export() -> None:
    """Garantiza que no hay exportación cuando la venta está deshabilitada.

    Entradas:
        Dataset con excedentes FV pero `allow_sell=False`.

    Salidas:
        Assert de columna grid_export a cero.

    Errores relevantes:
        AssertionError: Si se exporta energía con venta desactivada.
    """
    timestamps = pd.date_range("2025-01-01", periods=96, freq="15min")
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": 0.1,
            "pv_kwh": 1.0,
            "buy_eur_kwh": 0.3,
            "sell_eur_kwh": 0.2,
        }
    )
    scenario = ScenarioConfig(
        battery=BatteryParams(),
        tariff=TariffParams(allow_sell=False),
        grid=GridParams(allow_grid_charging=True),
    )

    result = SimulationEngine().run(InputDataDTO(dataframe=df, source_path="test", warnings=[]), scenario)
    assert (result.series["grid_export"] == 0.0).all()
