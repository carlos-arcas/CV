"""Pruebas mínimas del motor LP definitivo."""

from __future__ import annotations

import numpy as np
import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def _build_df(load: float, pv: float) -> pd.DataFrame:
    ts = pd.date_range("2025-01-01", periods=96, freq="15min")
    return pd.DataFrame(
        {
            "timestamp": ts,
            "load_kwh": load,
            "pv_kwh": pv,
            "buy_eur_kwh": [0.1 if i < 30 else 0.25 for i in range(96)],
            "sell_eur_kwh": 0.05,
        }
    )


def test_soc_bounds() -> None:
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=6.0, power_kw=3.0, soc_initial_pct=30.0, soc_min_pct=15.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=False),
    )
    result = SimulationEngine().run(InputDataDTO(dataframe=_build_df(load=0.8, pv=0.4), source_path="test", warnings=[]), scenario)
    soc_min = scenario.battery.capacity_kwh * scenario.battery.soc_min_pct / 100.0
    soc_max = scenario.battery.capacity_kwh
    assert (result.series["soc_start"] >= soc_min - 1e-6).all()
    assert (result.series["soc_end"] <= soc_max + 1e-6).all()


def test_balance_integrity() -> None:
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=False),
    )
    result = SimulationEngine().run(InputDataDTO(dataframe=_build_df(load=1.1, pv=0.9), source_path="test", warnings=[]), scenario)
    load_balance = result.series["pv_used_load"] + result.series["batt_discharge"] + result.series["grid_import"] - result.series["load"]
    pv_balance = result.series["pv_used_load"] + result.series["pv_used_batt"] + result.series["grid_export"] - result.series["pv"]
    assert float(np.abs(load_balance).max()) <= 1e-6
    assert float(np.abs(pv_balance).max()) <= 1e-6


def test_zero_pv() -> None:
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=8.0, power_kw=2.0),
        tariff=TariffParams(allow_sell=False),
        grid=GridParams(allow_grid_charging=False),
    )
    result = SimulationEngine().run(InputDataDTO(dataframe=_build_df(load=0.7, pv=0.0), source_path="test", warnings=[]), scenario)
    assert (result.series["pv_used_load"] == 0.0).all()
    assert (result.series["pv_used_batt"] == 0.0).all()
    assert (result.series["grid_export"] == 0.0).all()
