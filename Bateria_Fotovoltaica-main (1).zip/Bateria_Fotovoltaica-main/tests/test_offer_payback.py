"""Pruebas de estrategia para objetivo de payback del cliente."""

from application.finance.offer_strategy import compute_offer_by_payback


def test_offer_payback_respects_target_years() -> None:
    result = compute_offer_by_payback(
        inversion_total=15000.0,
        ahorro_mensual=250.0,
        plazo_meses=72,
        coste_capital_anual=6.0,
        target_payback_years=6.0,
    )
    assert result.payback_equivalente_cliente is not None
    assert result.payback_equivalente_cliente <= 6.0
