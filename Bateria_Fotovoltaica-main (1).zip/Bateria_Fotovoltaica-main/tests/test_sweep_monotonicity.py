"""Tests de sanity check para barrido de dimensionamiento."""

from __future__ import annotations

import numpy as np
import pandas as pd

from application.dimensioning import run_capacity_power_sweep
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def _build_test_df() -> pd.DataFrame:
    """Construye un día sintético de 96 periodos para pruebas rápidas."""
    idx = pd.date_range("2024-01-01", periods=96, freq="15min")
    load = np.full(96, 2.0)
    pv = np.zeros(96)
    pv[36:60] = 3.2
    buy = np.full(96, 0.20)
    buy[72:88] = 0.36
    sell = np.full(96, 0.02)
    return pd.DataFrame(
        {
            "timestamp": idx,
            "load_kwh": load,
            "pv_kwh": pv,
            "buy_eur_kwh": buy,
            "sell_eur_kwh": sell,
        }
    )


def test_sweep_monotonicity_sanity() -> None:
    """Verifica que el ahorro no tenga caídas bruscas al aumentar capacidad."""
    df = _build_test_df()
    config = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=5.0, power_kw=5.0),
        tariff=TariffParams(default_buy_eur_kwh=0.2, default_sell_eur_kwh=0.02, allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )

    sweep, _ = run_capacity_power_sweep(
        df_norm=df,
        config=config,
        capacities=[5.0, 10.0, 15.0, 20.0],
        powers=[5.0],
        mode="optimal",
    )
    sweep = sweep.sort_values("capacity_kwh")

    savings = sweep["annual_savings"].to_numpy()
    drops = np.diff(savings)
    assert np.all(drops >= -0.15 * np.maximum(savings[:-1], 1e-6))
