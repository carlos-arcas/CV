from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import pandas as pd

from cli.benchmark_cli import benchmark_project
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from domain.models_project import ProjectConfig
from infrastructure.persistence.project_store import save_project


def _create_project(tmp_path, rows: int = 96) -> tuple[str, pd.DataFrame]:
    project_dir = tmp_path / "benchmark_project"
    dataset_path = project_dir / "input.csv"
    timestamps = pd.date_range("2025-01-01", periods=rows, freq="15min")
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": [1.0] * len(timestamps),
            "pv_kwh": [0.2] * len(timestamps),
            "buy_eur_kwh": [0.2] * len(timestamps),
            "sell_eur_kwh": [0.05] * len(timestamps),
        }
    )
    project_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(dataset_path, index=False)

    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=5.0, power_kw=3.0),
        tariff=TariffParams(),
        grid=GridParams(),
    )
    project = ProjectConfig(
        name="bench-test",
        data_path=str(dataset_path),
        model_folder=str(project_dir / "models"),
        export_folder=str(project_dir / "outputs"),
        scenario=asdict(scenario),
        schema_version=2,
    )
    save_project(project, str(project_dir))
    return str(project_dir), df


def _latest_benchmark_payload(project_dir: str) -> dict[str, object]:
    files = sorted((Path(project_dir) / "benchmark").glob("benchmark_*.json"))
    assert files
    return json.loads(files[-1].read_text(encoding="utf-8"))


def test_benchmark_structure_output(tmp_path) -> None:
    project_dir, df = _create_project(tmp_path)

    code = benchmark_project(project_dir, runs=2, fast=True, use_grid=False, workers=1)

    assert code == 0
    payload = _latest_benchmark_payload(project_dir)
    assert "results" in payload
    assert isinstance(payload["results"], list)
    result = payload["results"][0]
    assert result["mode"] == "fast"
    assert result["dataset_rows"] == len(df)
    assert result["runs"] == 2
    assert "rows_per_sec" in result
    assert "mean_time_sec" in result


def test_speedup_positive_if_fast(tmp_path) -> None:
    project_dir, _ = _create_project(tmp_path)

    code = benchmark_project(project_dir, runs=1, fast=False, use_grid=False, workers=1)

    assert code == 0
    payload = _latest_benchmark_payload(project_dir)
    assert payload["speedup_fast_vs_detailed"] > 0


def test_json_file_created(tmp_path) -> None:
    project_dir, _ = _create_project(tmp_path)

    code = benchmark_project(project_dir, runs=1, fast=True, use_grid=False, workers=1)

    assert code == 0
    benchmark_files = list((Path(project_dir) / "benchmark").glob("benchmark_*.json"))
    assert benchmark_files
