import pandas as pd

from application.dimensioning import run_capacity_power_sweep
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_dimensioning_topk_returns_expected_count() -> None:
    df = pd.DataFrame(
        {
            "timestamp": pd.date_range("2025-01-01", periods=96, freq="15min"),
            "load_kwh": 0.8,
            "pv_kwh": 0.3,
            "buy_eur_kwh": 0.2,
            "sell_eur_kwh": 0.05,
        }
    )
    scenario = ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(allow_sell=True), grid=GridParams())
    sweep, top_periods = run_capacity_power_sweep(
        df_norm=df,
        config=scenario,
        capacities=[5, 10],
        powers=[3, 5],
        top_n=2,
        sweep_mode="completo",
    )
    assert len(sweep) == 4
    assert len(top_periods) == 2
