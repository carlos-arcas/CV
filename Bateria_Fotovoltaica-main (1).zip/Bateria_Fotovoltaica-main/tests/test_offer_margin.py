"""Pruebas de estrategia para maximizar margen con ahorro mínimo cliente."""

from application.finance.offer_strategy import compute_offer_max_margin


def test_offer_margin_keeps_minimum_customer_savings() -> None:
    result = compute_offer_max_margin(
        inversion_total=18000.0,
        ahorro_mensual=220.0,
        plazo_meses=60,
        coste_capital_anual=8.0,
        min_customer_savings_eur=20.0,
    )
    assert result.ahorro_cliente_mensual >= 20.0
    assert result.cuota_recomendada <= 200.0
