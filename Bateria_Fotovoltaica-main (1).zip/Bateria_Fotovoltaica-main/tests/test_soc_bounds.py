"""Pruebas de invariantes de SoC para la simulación diaria/anual."""

from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_soc_bounds_always_respected() -> None:
    """Comprueba que SoC nunca salga de límites físicos durante la simulación.

    Entradas:
        No aplica; se genera un dataset sintético de un día (96 periodos).

    Salidas:
        Assert sobre columnas soc_start y soc_end dentro de [soc_min, soc_max].

    Errores relevantes:
        AssertionError: Si alguna muestra de SoC viola los límites.
    """
    timestamps = pd.date_range("2025-01-01", periods=96, freq="15min")
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": 1.0,
            "pv_kwh": 0.2,
            "buy_eur_kwh": 0.2,
            "sell_eur_kwh": 0.05,
        }
    )
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0, soc_initial_pct=40.0, soc_min_pct=10.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )

    result = SimulationEngine().run(InputDataDTO(dataframe=df, source_path="test", warnings=[]), scenario)
    soc_min = scenario.battery.capacity_kwh * scenario.battery.soc_min_pct / 100.0
    soc_max = scenario.battery.capacity_kwh

    assert (result.series["soc_start"] >= soc_min - 1e-6).all()
    assert (result.series["soc_start"] <= soc_max + 1e-6).all()
    assert (result.series["soc_end"] >= soc_min - 1e-6).all()
    assert (result.series["soc_end"] <= soc_max + 1e-6).all()
