from __future__ import annotations

from application.export.executive_report import build_executive_summary


def _sample_kpis() -> dict:
    return {
        "total_savings_eur": 12345.678,
        "npv": 8910.456,
        "irr": 0.12789,
        "payback_years": 6.789,
        "roi": 0.45678,
        "energia_descargada_kwh": 4321.987,
        "autoconsumo_pct": 77.7777,
        "capex_eur": 22000.0,
        "annual_opex_eur": 250.55,
        "discount_rate": 0.05,
        "lifetime_years": 12,
    }


def test_executive_summary_structure() -> None:
    summary = build_executive_summary(
        project_name="Proyecto Demo",
        client_name="Cliente Demo",
        scenario_name="Escenario A",
        kpis=_sample_kpis(),
        annual_energy_stats={"battery_capacity_kwh": 20.0, "battery_power_kw": 10.0},
    )

    assert set(summary["sections"].keys()) == {"resumen_clave", "datos_tecnicos", "comparativa"}
    assert summary["sections"]["comparativa"] is None
    assert any(row["section"] == "RESUMEN CLAVE" for row in summary["rows"])
    assert any(row["section"] == "DATOS TÉCNICOS" for row in summary["rows"])


def test_rounding_format() -> None:
    summary = build_executive_summary(
        project_name="Proyecto Demo",
        client_name=None,
        scenario_name=None,
        kpis=_sample_kpis(),
        annual_energy_stats={"battery_capacity_kwh": 20.0, "battery_power_kw": 10.0},
    )
    key_metrics = summary["sections"]["resumen_clave"]

    assert key_metrics["Ahorro anual (€)"] == 12345.678
    rounded_rows = {row["metric"]: row["value"] for row in summary["rows"]}
    assert rounded_rows["Ahorro anual (€)"] == 12345.68
    assert rounded_rows["TIR (%)"] == 12.79
    assert rounded_rows["ROI (%)"] == 45.68


def test_comparison_calculation() -> None:
    summary = build_executive_summary(
        project_name="Proyecto Demo",
        client_name="Cliente Demo",
        scenario_name="Escenario A",
        kpis=_sample_kpis(),
        annual_energy_stats={"battery_capacity_kwh": 20.0, "battery_power_kw": 10.0},
        comparison={
            "savings_with_battery": 12000.0,
            "savings_without_battery": 8000.0,
            "autoconsumo_with_battery": 70.0,
            "autoconsumo_without_battery": 55.0,
        },
    )

    comp = summary["sections"]["comparativa"]
    assert comp is not None
    assert comp["incremental_savings"] == 4000.0
    assert comp["autoconsumo_improvement_pct"] == 15.0
