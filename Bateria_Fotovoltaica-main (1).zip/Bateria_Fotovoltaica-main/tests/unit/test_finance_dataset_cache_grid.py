from __future__ import annotations

from pathlib import Path

import pandas as pd

from application.batch_runner import build_battery_grid, patch_scenario_for_variant
from application.dataset_validator import validate_dataset
from application.dto import ResultsBundleDTO
from application.finance.financial_kpis import irr, npv, payback_discounted, payback_simple, roi_total
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from infrastructure.io.simulation_cache import build_simulation_hash, run_with_cache


def _base_scenario() -> ScenarioConfig:
    return ScenarioConfig(
        battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )


def test_finance_core_metrics_are_consistent() -> None:
    cashflows = [-1000.0, 400.0, 400.0, 400.0]
    assert abs(npv(0.1, cashflows) + 5.2592036) < 1e-6
    computed_irr = irr(cashflows)
    assert computed_irr is not None
    assert abs(computed_irr - 0.09701025) < 1e-4
    assert payback_simple(cashflows) == 2.5
    discounted = payback_discounted(0.1, [-1000.0, 500.0, 500.0, 500.0])
    assert discounted is not None
    assert abs(discounted - 2.3520) < 1e-3
    assert roi_total(cashflows) == 0.2


def test_dataset_validator_flags_duplicate_timestamps() -> None:
    df = pd.DataFrame(
        {
            "timestamp": ["2025-01-01 00:00:00", "2025-01-01 00:15:00", "2025-01-01 00:15:00"],
            "load_kwh": [1.0, 1.1, 1.2],
            "pv_kwh": [0.0, 0.0, 0.0],
            "buy_eur_kwh": [0.2, 0.2, 0.2],
        }
    )
    report = validate_dataset(df, expected_step_minutes=15)
    assert not report.ok
    assert any(item.code == "TIMESTAMP_DUPLICATED" for item in report.errors)


def test_dataset_validator_flags_nan_in_critical_column() -> None:
    df = pd.DataFrame(
        {
            "timestamp": ["2025-01-01 00:00:00", "2025-01-01 00:15:00", "2025-01-01 00:30:00"],
            "load_kwh": [1.0, float("nan"), 1.3],
            "pv_kwh": [0.0, 0.0, 0.0],
            "buy_eur_kwh": [0.2, 0.2, 0.2],
        }
    )
    report = validate_dataset(df, expected_step_minutes=15)
    assert not report.ok
    assert any(item.code == "NUMERIC_INVALID" and item.details.get("column") == "load_kwh" for item in report.errors)


def test_dataset_validator_flags_irregular_timestep() -> None:
    df = pd.DataFrame(
        {
            "timestamp": [
                "2025-01-01 00:00:00",
                "2025-01-01 00:15:00",
                "2025-01-01 00:30:00",
                "2025-01-01 01:30:00",
            ],
            "load_kwh": [1.0, 1.1, 1.2, 1.3],
            "pv_kwh": [0.0, 0.0, 0.0, 0.0],
            "buy_eur_kwh": [0.2, 0.2, 0.2, 0.2],
        }
    )
    report = validate_dataset(df, expected_step_minutes=15)
    assert not report.ok
    assert any(item.code == "TIMESTEP_IRREGULAR" for item in report.errors)


def test_simulation_hash_changes_when_scenario_changes(temp_project_dir: Path) -> None:
    dataset = temp_project_dir / "data.csv"
    dataset.write_text("timestamp,load_kwh,pv_kwh,buy_eur_kwh\n2025-01-01 00:00:00,1,0,0.2\n", encoding="utf-8")

    hash_a = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 10}},
        fast_mode=False,
        financial_params=None,
    )
    hash_b = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 12}},
        fast_mode=False,
        financial_params=None,
    )
    assert hash_a != hash_b


def test_cache_hit_returns_same_kpis(temp_project_dir: Path) -> None:
    scenario = _base_scenario()
    call_counter = {"count": 0}

    def _compute() -> ResultsBundleDTO:
        call_counter["count"] += 1
        return ResultsBundleDTO(
            scenario=scenario,
            series=pd.DataFrame(),
            kpis={"total_savings_eur": 123.45, "dataset_hash": "abc", "simulation_fast_mode": False},
            logs=["ok"],
        )

    first = run_with_cache(project_dir=temp_project_dir, simulation_hash="abc123", compute_func=_compute)
    second = run_with_cache(project_dir=temp_project_dir, simulation_hash="abc123", compute_func=_compute)

    assert call_counter["count"] == 1
    assert first.kpis == second.kpis


def test_battery_grid_cartesian_product_and_patch_does_not_mutate_base(temp_project_dir: Path) -> None:
    base = _base_scenario()
    variants = build_battery_grid(
        project_dir=temp_project_dir,
        base_scenario=base,
        use_grid=False,
        capacities_override=[8.0, 10.0],
        powers_override=[4.0, 5.0],
    )
    assert len(variants) == 4

    original_capacity = base.battery.capacity_kwh
    patched = patch_scenario_for_variant(base, variants[0])

    assert base.battery.capacity_kwh == original_capacity
    assert patched.battery.capacity_kwh == variants[0].capacity_kwh
