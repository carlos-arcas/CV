"""Pruebas de cuota de préstamo para módulo financiero."""

from application.finance.finance_calculations import compute_monthly_payment_amortization


def test_finance_payment_known_case() -> None:
    """Valida cuota mensual contra caso conocido de amortización francesa."""
    payment, schedule = compute_monthly_payment_amortization(10000.0, 12.0, 12)
    assert round(payment, 2) == 888.49
    assert len(schedule) == 12
    assert round(schedule[-1]["remaining_balance_eur"], 6) == 0.0
