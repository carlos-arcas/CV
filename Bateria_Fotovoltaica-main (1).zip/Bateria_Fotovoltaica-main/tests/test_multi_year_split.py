"""Pruebas de split temporal por años para evitar fuga de datos."""

from __future__ import annotations

import pandas as pd

from application.ml.dataset import split_by_year


def test_split_by_year_separates_train_and_test_years() -> None:
    timestamps = pd.to_datetime([
        "2024-01-01 00:00:00",
        "2024-01-01 00:15:00",
        "2025-01-01 00:00:00",
        "2025-01-01 00:15:00",
    ])
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "soc": [50.0, 52.0, 48.0, 49.0],
            "load_kwh": 1.0,
            "pv_kwh": 0.0,
            "buy_eur_kwh": 0.2,
            "sell_eur_kwh": 0.0,
            "hour": [0, 0, 0, 0],
            "month": [1, 1, 1, 1],
            "dayofweek": [0, 0, 2, 2],
            "min_price_next_4h": 0.2,
            "max_price_next_4h": 0.2,
            "mean_price_next_4h": 0.2,
            "rank_price_day": 0.5,
            "action": ["idle", "charge", "idle", "discharge"],
            "charge_kwh_opt": [0.0, 0.4, 0.0, 0.0],
            "discharge_kwh_opt": [0.0, 0.0, 0.0, 0.6],
        }
    )

    split = split_by_year(df, test_years=[2025])

    assert split.train_df["timestamp"].dt.year.nunique() == 1
    assert int(split.train_df["timestamp"].dt.year.iloc[0]) == 2024
    assert split.test_df["timestamp"].dt.year.nunique() == 1
    assert int(split.test_df["timestamp"].dt.year.iloc[0]) == 2025
