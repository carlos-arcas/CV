"""Pruebas de persistencia de proyectos y bundles ML."""

from __future__ import annotations

import json

from application.ml.model_bundle import ModelBundle
from domain.models_project import ProjectConfig
from infrastructure.persistence.model_store import load_model_bundle, save_model_bundle
from infrastructure.persistence.project_store import load_project, save_project


def test_model_bundle_roundtrip(tmp_path) -> None:
    bundle = ModelBundle(
        action_model={"kind": "classifier"},
        charge_model={"kind": "charge"},
        discharge_model={"kind": "discharge"},
        metadata={"trained_at": "2026-01-01T00:00:00", "metrics": {"acc": 0.9}},
    )
    folder = tmp_path / "models" / "bundle_a"
    save_model_bundle(bundle, str(folder))

    loaded = load_model_bundle(str(folder))
    assert loaded.metadata["trained_at"] == "2026-01-01T00:00:00"
    assert loaded.action_model["kind"] == "classifier"


def test_project_migration_schema_v1(tmp_path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    with open(project_dir / "project.json", "w", encoding="utf-8") as fh:
        json.dump({"name": "legacy", "schema_version": 1, "data_path": ""}, fh)
    with open(project_dir / "scenario.json", "w", encoding="utf-8") as fh:
        json.dump({"battery": {}, "tariff": {}, "grid": {}, "timestep_minutes": 15}, fh)

    loaded, _, warnings = load_project(str(project_dir))
    assert loaded.schema_version == 2
    assert warnings


def test_project_roundtrip_without_cache(tmp_path) -> None:
    project = ProjectConfig(name="demo", scenario={"battery": {}, "tariff": {}, "grid": {}, "timestep_minutes": 15})
    save_project(project, str(tmp_path / "demo_project"))
    loaded, cache_df, _ = load_project(str(tmp_path / "demo_project"))
    assert loaded.name == "demo"
    assert cache_df is None
