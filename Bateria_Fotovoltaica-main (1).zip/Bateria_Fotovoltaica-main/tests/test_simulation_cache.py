from __future__ import annotations

from pathlib import Path

import pandas as pd

from application.batch_runner import run_simulation_job
from application.dto import InputDataDTO, ResultsBundleDTO
from domain.models import BatteryParams, GridParams, ScenarioConfig, SimulationMode, TariffParams
from infrastructure.io.simulation_cache import build_simulation_hash, run_with_cache


def _scenario() -> ScenarioConfig:
    return ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(), grid=GridParams())


def test_hash_changes_when_scenario_changes(tmp_path: Path) -> None:
    dataset = tmp_path / "dataset.csv"
    dataset.write_text("timestamp,load_kwh,pv_kwh,buy_eur_kwh,sell_eur_kwh\n", encoding="utf-8")

    hash_a = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 10}},
        fast_mode=False,
        financial_params={"discount_rate": 0.05},
    )
    hash_b = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 20}},
        fast_mode=False,
        financial_params={"discount_rate": 0.05},
    )

    assert hash_a != hash_b


def test_hash_changes_when_dataset_changes(tmp_path: Path) -> None:
    dataset = tmp_path / "dataset.csv"
    dataset.write_text("A", encoding="utf-8")
    hash_a = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 10}},
        fast_mode=False,
        financial_params=None,
    )

    dataset.write_text("B", encoding="utf-8")
    hash_b = build_simulation_hash(
        dataset_path=dataset,
        scenario_config={"battery": {"capacity_kwh": 10}},
        fast_mode=False,
        financial_params=None,
    )

    assert hash_a != hash_b


def test_cache_hit_returns_same_kpis(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir(parents=True)
    calls = {"count": 0}

    def compute() -> ResultsBundleDTO:
        calls["count"] += 1
        return ResultsBundleDTO(
            scenario=_scenario(),
            series=pd.DataFrame({"timestamp": ["2025-01-01 00:00:00"], "value": [1.0]}),
            kpis={"total_savings_eur": 123.0},
            logs=["ok"],
        )

    first = run_with_cache(project_dir=project_dir, simulation_hash="abc", compute_func=compute)
    second = run_with_cache(project_dir=project_dir, simulation_hash="abc", compute_func=compute)

    assert calls["count"] == 1
    assert first.kpis == second.kpis


class _DummyLoader:
    def execute(self, source_path: str) -> InputDataDTO:
        return InputDataDTO(dataframe=pd.read_csv(source_path), source_path=source_path)


class _DummyNormalizer:
    def execute(self, dto: InputDataDTO) -> InputDataDTO:
        return dto


class _DummyRunner:
    def __init__(self) -> None:
        self.calls = 0

    def execute(self, _input: InputDataDTO, scenario: ScenarioConfig, **_: object) -> ResultsBundleDTO:
        self.calls += 1
        return ResultsBundleDTO(
            scenario=scenario,
            series=pd.DataFrame(),
            kpis={"total_savings_eur": float(self.calls)},
            logs=[],
        )


def test_no_cache_flag_forces_recompute(tmp_path: Path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir(parents=True)
    dataset = tmp_path / "input.csv"
    pd.DataFrame(
        {
            "timestamp": pd.date_range("2025-01-01", periods=8, freq="15min"),
            "load_kwh": [1.0] * 8,
            "pv_kwh": [0.2] * 8,
            "buy_eur_kwh": [0.1] * 8,
            "sell_eur_kwh": [0.0] * 8,
        }
    ).to_csv(dataset, index=False)

    runner = _DummyRunner()
    scenario = _scenario()

    run_simulation_job(
        input_path=dataset,
        scenario=scenario,
        strict_warnings=False,
        mode=SimulationMode.OPTIMAL,
        include_detail=False,
        run_use_case=runner,
        load_use_case=_DummyLoader(),
        normalize_use_case=_DummyNormalizer(),
        project_dir=project_dir,
        use_cache=False,
    )
    run_simulation_job(
        input_path=dataset,
        scenario=scenario,
        strict_warnings=False,
        mode=SimulationMode.OPTIMAL,
        include_detail=False,
        run_use_case=runner,
        load_use_case=_DummyLoader(),
        normalize_use_case=_DummyNormalizer(),
        project_dir=project_dir,
        use_cache=False,
    )

    assert runner.calls == 2
