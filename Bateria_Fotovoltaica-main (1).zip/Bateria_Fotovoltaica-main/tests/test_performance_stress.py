from __future__ import annotations

import gc
import os
import time
import tracemalloc
from pathlib import Path

import pandas as pd

from application.batch_simulator import simulate_batch
from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def _scenario() -> ScenarioConfig:
    return ScenarioConfig(
        battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0, soc_initial_pct=50.0, soc_min_pct=10.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=False),
    )


def _dataset(periods: int) -> pd.DataFrame:
    ts = pd.date_range("2025-01-01", periods=periods, freq="h")
    return pd.DataFrame(
        {
            "timestamp": ts,
            "load_kwh": 1.2,
            "pv_kwh": 0.8,
            "buy_eur_kwh": 0.2,
            "sell_eur_kwh": 0.08,
        }
    )


def test_year_under_one_second() -> None:
    budget = float(os.getenv("PERF_TEST_YEAR_SECONDS", "3.0"))
    df = _dataset(8760)
    t0 = time.perf_counter()
    SimulationEngine().run(InputDataDTO(dataframe=df, source_path="synthetic", warnings=[]), _scenario())
    elapsed = time.perf_counter() - t0
    assert elapsed < budget, f"Tiempo anual {elapsed:.3f}s excede presupuesto {budget:.3f}s"


def test_batch_20_clients(tmp_path: Path) -> None:
    budget = float(os.getenv("PERF_TEST_BATCH_SECONDS", "15.0"))
    datasets: list[Path] = []
    df = _dataset(24 * 30)
    for i in range(20):
        p = tmp_path / f"client_{i}.csv"
        df.to_csv(p, index=False)
        datasets.append(p)

    batteries = [
        BatteryParams(capacity_kwh=5.0, power_kw=2.5),
        BatteryParams(capacity_kwh=10.0, power_kw=5.0),
    ]
    t0 = time.perf_counter()
    result = simulate_batch(datasets, batteries)
    elapsed = time.perf_counter() - t0

    assert len(result.resultados_por_cliente) == 20
    assert result.metricas_agregadas["ahorro_total"] >= 0.0
    assert elapsed < budget, f"Batch 20 clientes {elapsed:.3f}s excede presupuesto {budget:.3f}s"


def test_memory_stable_multiple_runs() -> None:
    runs = int(os.getenv("PERF_TEST_RUNS", "10"))
    budget_mb = float(os.getenv("PERF_TEST_MEMORY_DELTA_MB", "80"))
    df = _dataset(8760)
    scenario = _scenario()

    tracemalloc.start()
    initial, _ = tracemalloc.get_traced_memory()
    for _ in range(runs):
        SimulationEngine().run(InputDataDTO(dataframe=df, source_path="synthetic", warnings=[]), scenario)
        gc.collect()
    final, _ = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    delta_mb = (final - initial) / (1024 * 1024)
    assert delta_mb < budget_mb, f"Delta memoria {delta_mb:.2f}MB excede {budget_mb:.2f}MB"
