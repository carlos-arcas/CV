import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_reproducibility_same_input_same_kpis() -> None:
    df = pd.DataFrame(
        {
            "timestamp": pd.date_range("2025-01-01", periods=96, freq="15min"),
            "load_kwh": 0.8,
            "pv_kwh": 0.2,
            "buy_eur_kwh": 0.25,
            "sell_eur_kwh": 0.1,
        }
    )
    dto = InputDataDTO(dataframe=df, source_path="repro")
    scenario = ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(allow_sell=True), grid=GridParams())
    engine = SimulationEngine()
    r1 = engine.run(dto, scenario)
    r2 = engine.run(dto, scenario)
    assert r1.kpis["total_savings_eur"] == r2.kpis["total_savings_eur"]
