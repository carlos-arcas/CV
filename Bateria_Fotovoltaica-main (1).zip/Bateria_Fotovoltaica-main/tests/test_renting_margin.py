"""Pruebas de margen para renting."""

from application.finance.finance_calculations import compute_rental_quote
from domain.finance_models import RentalParams


def test_renting_margin_positive_with_markup() -> None:
    """Verifica que el margen sea positivo cuando markup es mayor que cero."""
    params = RentalParams(term_months=48, annual_cost_of_capital_pct=7.0, margin_pct=10.0)
    quote = compute_rental_quote(capex_total_eur=20000.0, rental_params=params)
    assert quote["total_margin_eur"] > 0
    assert quote["monthly_margin_eur"] > 0
