from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO, ResultsBundleDTO
from application.use_cases import RunSimulationUseCase
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


class FakeEngine:
    def __init__(self) -> None:
        self.calls = 0

    def simulate_year(self, *, df_norm: pd.DataFrame, config: ScenarioConfig, **_: object) -> ResultsBundleDTO:
        self.calls += 1
        return ResultsBundleDTO(scenario=config, series=df_norm.copy(), kpis={"total_savings_eur": 123.0}, logs=[])


def _scenario() -> ScenarioConfig:
    return ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(), grid=GridParams())


def test_run_simulation_use_case_executes_engine() -> None:
    use_case = RunSimulationUseCase(engine=FakeEngine())
    input_dto = InputDataDTO(dataframe=pd.DataFrame({"timestamp": []}), source_path="dataset.csv")

    result = use_case.execute(input_dto, _scenario(), use_cache=False)

    assert result.kpis["total_savings_eur"] == 123.0
