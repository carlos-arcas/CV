from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import sys

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from domain.models_project import ProjectConfig


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("coverage")
    group.addoption("--cov", action="append", default=[], help="Módulos/paquetes a medir con coverage.")
    group.addoption("--cov-report", action="append", default=[], help="Reporte de coverage (term o term-missing).")


def pytest_configure(config: pytest.Config) -> None:
    cov_sources = config.getoption("--cov")
    if not cov_sources:
        return
    try:
        from coverage import Coverage
    except Exception as exc:  # noqa: BLE001
        raise pytest.UsageError("coverage no está instalado. Ejecuta: pip install coverage") from exc

    reporter = Coverage(source=cov_sources)
    reporter.start()
    setattr(config, "_cov_reporter", reporter)


def pytest_unconfigure(config: pytest.Config) -> None:
    reporter = getattr(config, "_cov_reporter", None)
    if reporter is None:
        return
    reporter.stop()
    reporter.save()

    reports = config.getoption("--cov-report") or ["term"]
    show_missing = any(item == "term-missing" for item in reports)
    if any(item in {"term", "term-missing"} for item in reports):
        reporter.report(show_missing=show_missing)


@pytest.fixture
def sample_dataset_df() -> pd.DataFrame:
    timestamps = pd.date_range("2025-01-01", periods=96, freq="15min")
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": [1.2] * len(timestamps),
            "pv_kwh": [0.4 if 9 <= item.hour <= 17 else 0.0 for item in timestamps],
            "buy_eur_kwh": [0.12 if item.hour < 8 else 0.22 for item in timestamps],
            "sell_eur_kwh": [0.05] * len(timestamps),
        }
    )


@pytest.fixture
def sample_scenario_config() -> ScenarioConfig:
    return ScenarioConfig(
        battery=BatteryParams(capacity_kwh=8.0, power_kw=4.0, soc_initial_pct=50.0, soc_min_pct=10.0),
        tariff=TariffParams(default_buy_eur_kwh=0.2, default_sell_eur_kwh=0.05, allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
        timestep_minutes=15,
    )


@pytest.fixture
def sample_project_config(sample_scenario_config: ScenarioConfig) -> ProjectConfig:
    return ProjectConfig(
        name="test_project",
        data_path="",
        model_folder="models",
        export_folder="outputs",
        scenario=asdict(sample_scenario_config),
        schema_version=2,
    )


@pytest.fixture
def temp_project_dir(tmp_path: Path) -> Path:
    project_dir = tmp_path / "fv_bess_project"
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir
