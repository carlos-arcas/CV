from __future__ import annotations

import json
from pathlib import Path

from infrastructure.logging.crash_handler import run_with_crash_report
from infrastructure.logging.logging_config import generate_run_id, setup_project_logging


def test_run_id_unique() -> None:
    first = generate_run_id("abc")
    second = generate_run_id("abc")
    assert first != second
    assert "__" in first


def test_logging_directory_created(tmp_path: Path) -> None:
    run_id = generate_run_id("dataset")
    run_dir = setup_project_logging(tmp_path, run_id)
    assert run_dir.exists()
    assert (run_dir / "run.log").exists()


def test_crash_report_generated(tmp_path: Path) -> None:
    run_id = generate_run_id("crash")

    def _boom() -> int:
        raise RuntimeError("boom")

    code = run_with_crash_report(_boom, project_dir=tmp_path, run_id=run_id, context={"client": "acme"})
    crash_path = tmp_path / "logs" / "runs" / run_id / "crash.json"

    assert code == 5
    assert crash_path.exists()
    payload = json.loads(crash_path.read_text(encoding="utf-8"))
    assert payload["exception_type"] == "RuntimeError"
    assert payload["context"]["client"] == "acme"
