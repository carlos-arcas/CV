import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_no_grid_export_when_disabled() -> None:
    df = pd.DataFrame(
        {
            "timestamp": pd.date_range("2025-01-01", periods=96, freq="15min"),
            "load_kwh": 0.1,
            "pv_kwh": 1.0,
            "buy_eur_kwh": 0.3,
            "sell_eur_kwh": 0.2,
        }
    )
    scenario = ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(allow_sell=False), grid=GridParams())
    result = SimulationEngine().run(InputDataDTO(dataframe=df, source_path="test"), scenario)
    assert float(result.series["grid_export"].sum()) == 0.0
