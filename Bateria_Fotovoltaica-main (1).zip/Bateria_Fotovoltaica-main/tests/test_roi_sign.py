"""Tests financieros para módulo de dimensionamiento."""

from __future__ import annotations

import pandas as pd

from application.dimensioning import compute_roi


def test_roi_negative_when_capex_high_and_savings_low() -> None:
    """Valida NPV negativo cuando la inversión es alta y el ahorro es insuficiente."""
    sweep_df = pd.DataFrame(
        [
            {
                "capacity_kwh": 100.0,
                "power_kw": 50.0,
                "annual_savings": 400.0,
                "annual_cycles": 10.0,
                "peak_soc": 100.0,
                "min_soc": 10.0,
                "runtime_seconds": 0.2,
            }
        ]
    )

    roi_df = compute_roi(
        sweep_df=sweep_df,
        capex_per_kwh=1000.0,
        capex_per_kw=400.0,
        lifetime_years=8,
        discount_rate=0.10,
    )

    assert float(roi_df.loc[0, "npv_eur"]) < 0.0
    assert float(roi_df.loc[0, "payback_years"]) > 100.0
