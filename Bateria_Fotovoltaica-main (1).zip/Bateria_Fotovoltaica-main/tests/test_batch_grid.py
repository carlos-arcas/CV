from __future__ import annotations

from copy import deepcopy

from application.batch_runner import (
    BatteryVariant,
    _metric_value,
    build_battery_grid,
    patch_scenario_for_variant,
    resolve_metric_key,
)
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def _base_scenario() -> ScenarioConfig:
    return ScenarioConfig(battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0), tariff=TariffParams(), grid=GridParams())


def test_grid_generation_cartesian(tmp_path) -> None:
    project_dir = tmp_path / "project"
    project_dir.mkdir(parents=True)
    (project_dir / "battery_grid.json").write_text(
        '{"capacities_kwh":[5,10],"powers_kw":[3,5],"roundtrip_efficiency":[0.9]}', encoding="utf-8"
    )

    variants = build_battery_grid(project_dir=project_dir, base_scenario=_base_scenario(), use_grid=True)

    assert len(variants) == 4
    assert {item.capacity_kwh for item in variants} == {5.0, 10.0}
    assert {item.power_kw for item in variants} == {3.0, 5.0}


def test_scenario_patching_no_mutation() -> None:
    scenario = _base_scenario()
    original = deepcopy(scenario)
    variant = BatteryVariant(variant_id="v001", capacity_kwh=15.0, power_kw=3.0, roundtrip_efficiency=0.81)

    patched = patch_scenario_for_variant(scenario, variant)

    assert scenario.battery.capacity_kwh == original.battery.capacity_kwh
    assert scenario.battery.power_kw == original.battery.power_kw
    assert patched.battery.capacity_kwh == 15.0
    assert patched.battery.power_kw == 3.0
    assert round(patched.battery.charge_efficiency * patched.battery.discharge_efficiency, 6) == 0.81


def test_ranking_sorting_metric() -> None:
    metric_key = resolve_metric_key("roi", [{"total_savings_eur": 10.0}, {"purchase_roi_annual": 0.12}])
    assert metric_key == "purchase_roi_annual"


def test_metric_payback_resolves_and_sorts_lower_as_better() -> None:
    metric_key = resolve_metric_key("payback", [{"payback_years": 8.0}, {"payback_years": 6.0}])
    assert metric_key == "payback_years"
    assert _metric_value({"payback_years": 6.0}, metric_key) > _metric_value({"payback_years": 8.0}, metric_key)
