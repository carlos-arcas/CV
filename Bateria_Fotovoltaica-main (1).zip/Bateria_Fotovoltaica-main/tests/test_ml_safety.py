"""Pruebas de safety layer para simulación rápida basada en ML."""

from __future__ import annotations

import pandas as pd

from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


class _DummyRegressor:
    def __init__(self, value: float) -> None:
        self.value = value

    def predict(self, x):  # noqa: ANN001
        return [self.value] * len(x)


def test_ml_safety_soc_bounds_under_extreme_predictions() -> None:
    timestamps = pd.date_range("2025-01-01", periods=96, freq="15min")
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": 0.8,
            "pv_kwh": 0.2,
            "buy_eur_kwh": 0.25,
            "sell_eur_kwh": 0.05,
        }
    )
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=5.0, power_kw=2.0, soc_initial_pct=50.0, soc_min_pct=20.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )

    bundle = {
        "payload": {
            "mode": "regression",
            "charge_model": _DummyRegressor(999.0),
            "discharge_model": _DummyRegressor(999.0),
            "feature_columns": [
                "soc",
                "load_kwh",
                "pv_kwh",
                "buy_eur_kwh",
                "sell_eur_kwh",
                "hour",
                "month",
                "dayofweek",
                "min_price_next_4h",
                "max_price_next_4h",
                "mean_price_next_4h",
                "rank_price_day",
            ],
        }
    }

    result = SimulationEngine().simulate_year_ml(df, scenario, bundle)
    soc_min = scenario.battery.capacity_kwh * scenario.battery.soc_min_pct / 100.0
    soc_max = scenario.battery.capacity_kwh
    assert (result.series["soc_start"] >= soc_min - 1e-6).all()
    assert (result.series["soc_start"] <= soc_max + 1e-6).all()
    assert (result.series["soc_end"] >= soc_min - 1e-6).all()
    assert (result.series["soc_end"] <= soc_max + 1e-6).all()
