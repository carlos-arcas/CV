from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from application.use_cases import RunSimulationUseCase
from domain.models import BatteryParams, GridParams, ScenarioConfig, SimulationMode, TariffParams


def _dataset() -> pd.DataFrame:
    ts = pd.date_range("2025-01-01", periods=96 * 3, freq="15min")
    buy = [0.12 if (item.hour < 8 or item.hour >= 22) else 0.28 for item in ts]
    pv = [max(0.0, 1.2 - abs(12 - item.hour) * 0.18) for item in ts]
    return pd.DataFrame(
        {
            "timestamp": ts,
            "load_kwh": [0.9] * len(ts),
            "pv_kwh": pv,
            "buy_eur_kwh": buy,
            "sell_eur_kwh": [0.04] * len(ts),
        }
    )


def _scenario() -> ScenarioConfig:
    return ScenarioConfig(
        battery=BatteryParams(capacity_kwh=10.0, power_kw=5.0, soc_initial_pct=50.0, soc_min_pct=10.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )


def test_fast_vs_detailed_close_enough() -> None:
    dto = InputDataDTO(dataframe=_dataset(), source_path="fast-test", warnings=[])
    scenario = _scenario()
    engine = SimulationEngine()

    detailed = RunSimulationUseCase(engine=engine).execute(dto, scenario, include_detail=True, use_cache=False)
    fast = RunSimulationUseCase(engine=engine).execute(
        dto,
        scenario,
        include_detail=False,
        use_cache=False,
        mode=SimulationMode.FAST,
    )

    detailed_savings = float(detailed.kpis.get("total_savings_eur", 0.0))
    fast_savings = float(fast.kpis.get("total_savings_eur", 0.0))
    diff = abs(fast_savings - detailed_savings)
    tolerance = max(0.01, abs(detailed_savings) * 0.02)
    assert diff <= tolerance


def test_fast_no_hourly_detail() -> None:
    engine = SimulationEngine()
    core = engine.simulate_core(
        dataset=_dataset(),
        scenario=_scenario(),
        aggregate_only=True,
        chain_soc_days=True,
        debug_mode=False,
        debug_dump_path="outputs/debug_dump.json",
        mode=SimulationMode.FAST,
    )
    assert core.hourly_detail is None
