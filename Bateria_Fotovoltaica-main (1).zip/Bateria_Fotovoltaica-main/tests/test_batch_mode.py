from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cli.project_cli import batch_run_project, init_project


def test_project_init_creates_batch_dirs(tmp_path: Path) -> None:
    project_dir = tmp_path / "demo"
    code = init_project(str(project_dir))
    assert code == 0
    for subdir in ["input", "output", "archive", "logs", "_runs"]:
        assert (project_dir / "batches" / subdir).exists()


def test_batch_run_without_inputs_returns_2(tmp_path: Path) -> None:
    project_dir = tmp_path / "demo_no_input"
    init_project(str(project_dir))
    code = batch_run_project(str(project_dir), pattern="*.xlsx,*.csv", overwrite=False, workers=1)
    assert code == 2


def test_batch_run_success_generates_output_manifest_and_archive(tmp_path: Path) -> None:
    project_dir = tmp_path / "demo_batch"
    init_project(str(project_dir))

    input_dir = project_dir / "batches" / "input"
    input_file = input_dir / "cliente.csv"
    df = pd.DataFrame(
        {
            "timestamp": pd.date_range("2025-01-01 00:00:00", periods=8, freq="15min"),
            "load_kwh": [1.0] * 8,
            "pv_kwh": [0.2] * 8,
            "buy_eur_kwh": [0.1] * 8,
            "sell_eur_kwh": [0.0] * 8,
        }
    )
    df.to_csv(input_file, index=False)

    code = batch_run_project(str(project_dir), pattern="*.csv", overwrite=False, workers=1)
    assert code == 0

    output_file = project_dir / "batches" / "output" / "cliente__v001_c10_p5__result.xlsx"
    assert output_file.exists()

    run_dirs = sorted((project_dir / "batches" / "_runs").iterdir())
    assert run_dirs
    manifest_file = run_dirs[-1] / "cliente" / "v001_c10_p5.manifest.json"
    assert manifest_file.exists()

    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    assert manifest["status"] == "ok"
    assert manifest["export_file"] == "batches/output/cliente__v001_c10_p5__result.xlsx"
    assert manifest["kpis"]

    archived_inputs = list((project_dir / "batches" / "archive" / run_dirs[-1].name).glob("cliente*.csv"))
    assert archived_inputs
    assert not input_file.exists()
