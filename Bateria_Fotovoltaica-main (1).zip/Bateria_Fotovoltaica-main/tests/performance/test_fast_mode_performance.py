from __future__ import annotations

import time

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from application.use_cases import RunSimulationUseCase
from domain.models import SimulationMode


def test_fast_mode_is_faster_than_optimal(sample_dataset_df, sample_scenario_config) -> None:
    dto = InputDataDTO(dataframe=sample_dataset_df, source_path="perf", warnings=[])
    use_case = RunSimulationUseCase(engine=SimulationEngine())

    t0 = time.perf_counter()
    detailed = use_case.execute(dto, sample_scenario_config, include_detail=False, use_cache=False, mode=SimulationMode.OPTIMAL)
    detailed_time = time.perf_counter() - t0

    t1 = time.perf_counter()
    fast = use_case.execute(dto, sample_scenario_config, include_detail=False, use_cache=False, mode=SimulationMode.FAST)
    fast_time = time.perf_counter() - t1

    assert "total_savings_eur" in detailed.kpis
    assert "total_savings_eur" in fast.kpis
    assert fast_time < detailed_time


def test_small_dataset_runtime_stays_under_threshold(sample_dataset_df, sample_scenario_config) -> None:
    dto = InputDataDTO(dataframe=sample_dataset_df, source_path="perf-threshold", warnings=[])
    use_case = RunSimulationUseCase(engine=SimulationEngine())

    t0 = time.perf_counter()
    use_case.execute(dto, sample_scenario_config, include_detail=False, use_cache=False, mode=SimulationMode.OPTIMAL)
    elapsed = time.perf_counter() - t0

    assert elapsed < 2.0

