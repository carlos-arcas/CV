"""Pruebas para escenario sin generación fotovoltaica."""

from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def test_no_pv_keeps_pv_columns_zero() -> None:
    """Verifica que sin FV no aparecen usos de FV en la solución.

    Entradas:
        Dataset de un día sin producción FV.

    Salidas:
        Assert de columnas pv_used_load y pv_used_batt en cero.

    Errores relevantes:
        AssertionError: Si el motor asigna energía FV inexistente.
    """
    timestamps = pd.date_range("2025-01-01", periods=96, freq="15min")
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": 0.6,
            "pv_kwh": 0.0,
            "buy_eur_kwh": 0.25,
            "sell_eur_kwh": 0.0,
        }
    )
    scenario = ScenarioConfig(
        battery=BatteryParams(),
        tariff=TariffParams(allow_sell=False),
        grid=GridParams(allow_grid_charging=True),
    )

    result = SimulationEngine().run(InputDataDTO(dataframe=df, source_path="test", warnings=[]), scenario)
    assert (result.series["pv_used_load"] == 0.0).all()
    assert (result.series["pv_used_batt"] == 0.0).all()
