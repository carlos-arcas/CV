"""Pruebas para evitar fuga temporal en features de horizonte futuro."""

from __future__ import annotations

import pandas as pd

from application.ml.dataset import build_features


def test_next_4h_features_do_not_cross_day_boundary() -> None:
    timestamps = pd.date_range("2025-01-01 22:00", periods=16, freq="15min")
    day1_prices = [0.10] * 8
    day2_prices = [0.99] * 8
    df = pd.DataFrame(
        {
            "timestamp": timestamps,
            "load_kwh": 1.0,
            "pv_kwh": 0.0,
            "buy_eur_kwh": day1_prices + day2_prices,
            "sell_eur_kwh": [0.0] * 16,
        }
    )

    features = build_features(df, horizon_periods=16, only_within_day=True)
    # último punto del primer día no debe ver precios del día siguiente (0.99)
    idx_last_day1 = 7
    assert features.loc[idx_last_day1, "max_price_next_4h"] == 0.10
