from __future__ import annotations

from pathlib import Path

import pandas as pd

from application.dto import ResultsBundleDTO
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from infrastructure.exporters import export_results_to_excel
from infrastructure.logging.crash_handler import install_global_crash_handler


def _scenario() -> ScenarioConfig:
    return ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(), grid=GridParams())


def test_export_file_created(tmp_path: Path) -> None:
    out = tmp_path / "result.xlsx"
    result = ResultsBundleDTO(
        scenario=_scenario(),
        series=pd.DataFrame(columns=["timestamp", "load", "pv"]),
        kpis={"total_savings_eur": 1.0},
        logs=[],
    )

    export_results_to_excel(result, str(out), include_executive=False)

    assert out.exists()


def test_crash_handler_writes_file(tmp_path: Path) -> None:
    crash_file = tmp_path / "crash.log"
    install_global_crash_handler(crash_file, show_error=lambda _: None)

    try:
        raise RuntimeError("boom")
    except RuntimeError as exc:
        import sys

        assert exc.__traceback__ is not None
        sys.excepthook(type(exc), exc, exc.__traceback__)

    assert "RuntimeError: boom" in crash_file.read_text(encoding="utf-8")
