from __future__ import annotations

import math

from application.finance.financial_kpis import build_cashflow, irr, npv, payback_simple


def test_npv_basic() -> None:
    cashflows = [-1000.0, 400.0, 400.0, 400.0]
    value = npv(0.10, cashflows)
    assert value < 0
    assert math.isclose(value, -5.259203606311189, rel_tol=1e-6)


def test_irr_known_case() -> None:
    rate = irr([-1000.0, 400.0, 400.0, 400.0])
    assert rate is not None
    assert math.isclose(rate, 0.0970102574, rel_tol=1e-6)


def test_payback_fractional() -> None:
    years = payback_simple([-1000.0, 300.0, 300.0, 300.0, 300.0])
    assert years is not None
    assert math.isclose(years, 3.3333333333333335, rel_tol=1e-6)


def test_cashflow_degradation() -> None:
    flow = build_cashflow(
        capex=1000.0,
        annual_savings=500.0,
        annual_opex=100.0,
        lifetime_years=3,
        degradation_rate=0.10,
    )
    assert flow == [-1000.0, 400.0, 350.0, 305.0]


def test_negative_npv_case() -> None:
    flow = [-1000.0, 100.0, 100.0, 100.0]
    assert npv(0.1, flow) < 0


def test_irr_none_without_sign_change() -> None:
    assert irr([-1000.0, -200.0, -100.0]) is None
