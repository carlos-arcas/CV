"""Pruebas de estrategia por ratio de cuota frente a ahorro."""

from application.finance.offer_strategy import compute_offer_by_savings_ratio


def test_offer_ratio_keeps_fee_under_savings_cap() -> None:
    result = compute_offer_by_savings_ratio(
        inversion_total=12000.0,
        ahorro_mensual=200.0,
        plazo_meses=60,
        coste_capital_anual=7.0,
        max_fee_ratio=0.8,
    )
    assert result.cuota_recomendada <= 160.0
    assert result.ahorro_cliente_mensual >= 40.0
