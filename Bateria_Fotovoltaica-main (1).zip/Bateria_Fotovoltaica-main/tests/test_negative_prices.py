import pandas as pd

from application.validators import normalize_dataset_15min


def test_negative_prices_are_allowed_with_warning() -> None:
    df = pd.DataFrame(
        {
            "FECHA_HORA": pd.date_range("2025-01-01", periods=2, freq="15min"),
            "CONSUMO": [0.5, 0.5],
            "FV": [0.0, 0.0],
            "POOL": [-0.1, 0.2],
        }
    )
    _, warnings = normalize_dataset_15min(df)
    assert any("precios negativos" in w.lower() for w in warnings)
