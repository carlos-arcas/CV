import pandas as pd
import pytest

from application.dataset_validator import validate_dataset
from application.errors import DatasetValidationError
from application.use_cases import ValidateAndNormalizeUseCase
from domain.errors import ValidationError


def _base_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "FECHA_HORA": pd.date_range("2025-01-01", periods=8, freq="15min"),
            "CONSUMO": [1.0] * 8,
            "FV": [0.1] * 8,
            "POOL": [0.1] * 8,
        }
    )


def test_dataset_validation_requires_non_negative_consumption() -> None:
    df = _base_df()
    df.loc[0, "CONSUMO"] = -1.0
    with pytest.raises(ValidationError):
        from application.validators import normalize_dataset_15min

        normalize_dataset_15min(df)


def test_validator_detects_duplicate_timestamps() -> None:
    df = _base_df()
    df.loc[2, "FECHA_HORA"] = df.loc[1, "FECHA_HORA"]
    report = validate_dataset(df, expected_step_minutes=15)
    assert report.ok is False
    assert any(issue.code == "TIMESTAMP_DUPLICATED" for issue in report.errors)


def test_validator_detects_irregular_timestep() -> None:
    df = _base_df()
    df = df.drop(index=3).reset_index(drop=True)
    report = validate_dataset(df, expected_step_minutes=15)
    assert any(issue.code in {"TIMESTEP_IRREGULAR", "TIMESTAMP_GAPS"} for issue in report.errors + report.warnings)


def test_validator_detects_nan_in_critical_column() -> None:
    df = _base_df()
    df["POOL"] = df["POOL"].astype(object)
    df.loc[3, "POOL"] = "foo"
    report = validate_dataset(df, expected_step_minutes=15)
    assert report.ok is False
    assert any(issue.code == "NUMERIC_INVALID" for issue in report.errors)


def test_validator_detects_negative_consumption() -> None:
    df = _base_df()
    df.loc[4, "CONSUMO"] = -0.3
    report = validate_dataset(df, expected_step_minutes=15)
    assert report.ok is False
    assert any(issue.code == "NEGATIVE_VALUES" for issue in report.errors)


def test_use_case_raises_dataset_validation_error() -> None:
    df = _base_df().drop(index=2).reset_index(drop=True)
    with pytest.raises(DatasetValidationError):
        from application.dto import InputDataDTO

        ValidateAndNormalizeUseCase(strict_warnings=True).execute(
            InputDataDTO(dataframe=df, source_path="dummy.csv", warnings=[])
        )
