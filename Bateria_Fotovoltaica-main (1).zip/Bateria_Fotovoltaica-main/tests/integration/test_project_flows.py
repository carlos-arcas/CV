from __future__ import annotations

import json
from pathlib import Path

from application.batch_runner import BatteryVariant, run_batch, run_simulation_job
from application.engine import SimulationEngine
from application.use_cases import LoadDatasetUseCase, RunSimulationUseCase, ValidateAndNormalizeUseCase
from benchmark import write_benchmark_report_json
from domain.models import SimulationMode


def _write_dataset(path: Path, df) -> None:
    df.to_csv(path, index=False)


def test_project_run_simple_returns_kpis(sample_dataset_df, sample_scenario_config, temp_project_dir: Path) -> None:
    dataset_path = temp_project_dir / "simple.csv"
    _write_dataset(dataset_path, sample_dataset_df)

    result = run_simulation_job(
        input_path=dataset_path,
        scenario=sample_scenario_config,
        strict_warnings=False,
        mode=SimulationMode.OPTIMAL,
        include_detail=False,
        run_use_case=RunSimulationUseCase(engine=SimulationEngine()),
        load_use_case=LoadDatasetUseCase(),
        normalize_use_case=ValidateAndNormalizeUseCase(),
        project_dir=temp_project_dir,
        use_cache=True,
    )

    assert result.error is None
    assert "total_savings_eur" in result.kpis


def test_project_run_fast_returns_kpis(sample_dataset_df, sample_scenario_config, temp_project_dir: Path) -> None:
    dataset_path = temp_project_dir / "fast.csv"
    _write_dataset(dataset_path, sample_dataset_df)

    result = run_simulation_job(
        input_path=dataset_path,
        scenario=sample_scenario_config,
        strict_warnings=False,
        mode=SimulationMode.FAST,
        include_detail=False,
        run_use_case=RunSimulationUseCase(engine=SimulationEngine()),
        load_use_case=LoadDatasetUseCase(),
        normalize_use_case=ValidateAndNormalizeUseCase(),
        project_dir=temp_project_dir,
        use_cache=True,
    )

    assert result.error is None
    assert "total_savings_eur" in result.kpis


def test_batch_run_with_two_variants_generates_ranking(sample_dataset_df, sample_scenario_config, temp_project_dir: Path) -> None:
    input_dir = temp_project_dir / "batches" / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    _write_dataset(input_dir / "client_a.csv", sample_dataset_df)

    battery_grid = [
        BatteryVariant(variant_id="v001", capacity_kwh=6.0, power_kw=3.0),
        BatteryVariant(variant_id="v002", capacity_kwh=10.0, power_kw=5.0),
    ]

    run_id, results = run_batch(
        project_dir=temp_project_dir,
        base_scenario=sample_scenario_config,
        battery_grid=battery_grid,
        project_schema_version=2,
        pattern="*.csv",
        overwrite=True,
        workers=1,
        ranking_metric="roi",
        fast=False,
        export_detail=False,
        include_executive=False,
        use_cache=True,
    )

    assert run_id
    assert len(results) == 2
    ranking_files = list((temp_project_dir / "batches" / "output").glob("client_a__ranking.*"))
    assert ranking_files


def test_benchmark_generates_json(sample_dataset_df, temp_project_dir: Path) -> None:
    dataset_path = temp_project_dir / "benchmark.csv"
    _write_dataset(dataset_path, sample_dataset_df)
    output_path = temp_project_dir / "benchmark" / "report.json"

    report = write_benchmark_report_json(dataset_path=dataset_path, output_path=output_path)

    assert output_path.exists()
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["periodos"] == 96
    assert payload["tiempo_total"] == report.tiempo_total

