"""Pruebas de payback para módulo financiero."""

from application.finance.finance_calculations import compute_simple_payback


def test_finance_payback_expected() -> None:
    """Comprueba payback simple esperado en caso lineal."""
    payback = compute_simple_payback(investment_eur=12000.0, annual_savings_eur=3000.0)
    assert payback == 4.0
