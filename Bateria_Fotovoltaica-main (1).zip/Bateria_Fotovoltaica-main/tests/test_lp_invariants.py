"""Pruebas de invariantes adicionales del flujo LP diario."""

from __future__ import annotations

import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


def _dataset() -> pd.DataFrame:
    idx = pd.date_range("2025-01-01", periods=96, freq="15min")
    return pd.DataFrame(
        {
            "timestamp": idx,
            "load_kwh": [1.2 if 30 <= i <= 70 else 0.6 for i in range(96)],
            "pv_kwh": [0.0 if i < 25 or i > 75 else 1.5 for i in range(96)],
            "buy_eur_kwh": [0.10 if i < 24 else 0.30 if i > 72 else 0.18 for i in range(96)],
            "sell_eur_kwh": 0.02,
        }
    )


def test_export_is_never_negative() -> None:
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=8.0, power_kw=4.0),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=True),
    )
    result = SimulationEngine().run(InputDataDTO(dataframe=_dataset(), source_path="test", warnings=[]), scenario)
    assert (result.series["grid_export"] >= -1e-9).all()


def test_optimal_cost_not_worse_than_base_without_sale_or_limits() -> None:
    scenario = ScenarioConfig(
        battery=BatteryParams(capacity_kwh=8.0, power_kw=4.0),
        tariff=TariffParams(allow_sell=False),
        grid=GridParams(allow_grid_charging=True, grid_import_limit_kw=None),
    )
    result = SimulationEngine().run(InputDataDTO(dataframe=_dataset(), source_path="test", warnings=[]), scenario)
    assert float(result.kpis["total_cost_bess_eur"]) <= float(result.kpis["total_cost_base_eur"]) + 1e-6
