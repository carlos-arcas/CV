# Arquitectura técnica — Simulador BESS/FV (PySide6 + Clean Architecture)

## 1) Objetivo y alcance del primer diseño

Este documento define la arquitectura base para una aplicación de escritorio en **Python + PySide6** orientada a Windows para:

- Cargar datos de consumo/generación y precios desde CSV/Excel.
- Simular escenario base (sin batería).
- Simular escenario con batería (**BESS**) usando optimización diaria como método principal.
- Encadenar el estado de carga (**SoC**) entre días para simulación anual.
- Mostrar KPIs y gráficas.
- Exportar resultados a Excel.

> Este paso es de diseño. No se implementa aún el solver; se deja definida la estructura para empezar desarrollo incremental.

---

## 2) Estilo arquitectónico: Clean Architecture

Se adopta separación por capas para desacoplar lógica de negocio, UI e I/O:

- **domain/**: reglas de negocio puras, entidades, value objects, contratos de repositorio (interfaces), políticas de validación, cálculo de KPIs base.
- **application/**: casos de uso (orquestación), DTOs, servicios de aplicación, mapeo de requests/responses.
- **infrastructure/**: adaptadores concretos (lectura CSV/XLSX, persistencia de proyecto, exportación Excel, optimizador, logging).
- **ui/**: PySide6 (presentación), view-models, binding de eventos, validación de formularios orientada a UX.

### Reglas de dependencia

- `ui -> application -> domain`
- `infrastructure -> domain` (implementa puertos)
- `application` puede depender de interfaces de `domain` y abstraer infraestructura mediante inyección.
- `domain` no conoce ninguna otra capa.

---

## 3) Estructura de carpetas propuesta

```text
bess_simulator/
  pyproject.toml
  README.md
  ARCHITECTURE.md

  app/
    domain/
      entities/
        time_series.py
        battery_config.py
        tariff_config.py
        simulation_request.py
        simulation_result.py
      value_objects/
        money.py
        power.py
        energy.py
        timestep.py
      services/
        kpi_service.py
        baseline_dispatch_service.py
        constraints_validator.py
      repositories/
        input_data_repository.py           # port
        results_export_repository.py       # port
        optimization_repository.py         # port
      exceptions/
        domain_errors.py

    application/
      dtos/
        input_schema_dto.py
        simulation_dto.py
        kpi_dto.py
      use_cases/
        load_input_file_use_case.py
        validate_input_data_use_case.py
        run_simulation_use_case.py
        export_results_use_case.py
        save_project_use_case.py
        load_project_use_case.py
      services/
        simulation_engine.py
        day_partition_service.py
        normalization_service.py
        scenario_builder_service.py
      mappers/
        dataframe_mapper.py

    infrastructure/
      io/
        pandas_input_data_repository.py
        excel_results_export_repository.py
        project_file_repository.py
      optimization/
        pulp_daily_optimizer.py            # solver adapter inicial
        pyomo_daily_optimizer.py           # opcional futuro
      config/
        settings.py
      logging/
        logger_factory.py
      plotting/
        chart_data_adapter.py

    ui/
      main.py
      app_bootstrap.py
      resources/
        icons/
        styles/
      widgets/
        sidebar.py
        file_drop_zone.py
        parameter_form.py
        kpi_cards.py
        charts_panel.py
        table_viewer.py
      pages/
        page_data_import.py
        page_parameters.py
        page_run.py
        page_results.py
        page_export.py
      viewmodels/
        app_view_model.py
        import_view_model.py
        parameters_view_model.py
        simulation_view_model.py
        results_view_model.py
      presenters/
        results_presenter.py

  tests/
    domain/
    application/
    infrastructure/
    ui/
```

---

## 4) Modelo de dominio (entidades y contratos)

## 4.1 Entidades principales

1. **TimeSeriesData**
   - Contiene índices temporales normalizados y arrays de señales.
   - Campos típicos:
     - `timestamps: DatetimeIndex`
     - `load_kw: np.ndarray`
     - `pv_kw: np.ndarray | None`
     - `buy_price_eur_kwh: np.ndarray`
     - `sell_price_eur_kwh: np.ndarray | None`
     - `meta: dict`

2. **BatteryConfig**
   - Parámetros técnicos y operativos:
     - `capacity_kwh`
     - `soc_min_pct`, `soc_max_pct`, `soc_initial_pct`
     - `charge_power_max_kw`, `discharge_power_max_kw`
     - `charge_efficiency`, `discharge_efficiency`
     - `allow_grid_charging: bool`
     - `allow_export: bool`
     - `grid_import_limit_kw: float | None`

3. **TariffConfig**
   - Estructura de precios:
     - `buy_price_mode: {from_file, flat, tou}`
     - `sell_price_mode: {from_file, flat, disabled}`
     - vectores o tablas auxiliares.

4. **SimulationRequest**
   - Agrega todo lo necesario para ejecutar:
     - `time_series_data`
     - `battery_config`
     - `tariff_config`
     - `simulation_horizon`
     - `optimization_options`

5. **SimulationResult / ResultsBundle**
   - Resultado integral con series, KPIs y metadata de ejecución.

## 4.2 Value Objects

- **Timestep**: duración discreta (15 min por estándar interno).
- **Energy/Power/Money**: opcionales para claridad semántica y validaciones.

## 4.3 Servicios de dominio

- **ConstraintsValidator**: valida coherencia física y de negocio.
- **BaselineDispatchService**: calcula balance energético sin batería.
- **KPIService**: computa métricas agregadas (coste anual, picos, autoconsumo, ciclos equivalentes aproximados, etc.).

## 4.4 Puertos (repositorios/interfaces)

- **InputDataRepository** (port)
  - `load(file_path, sheet_name=None) -> RawInputDataFrame`
- **OptimizationRepository** (port)
  - `solve_day(day_problem: DayOptimizationProblem) -> DayOptimizationResult`
- **ResultsExportRepository** (port)
  - `export(results_bundle, output_path, options) -> ExportMetadata`

---

## 5) Contrato de datos de entrada

## 5.1 Formatos soportados

- CSV (`.csv`) delimitado por coma o punto y coma.
- Excel (`.xlsx`, `.xls`) con selección de hoja.

## 5.2 Columnas requeridas (mínimas)

- `timestamp` (datetime parseable, timezone opcional pero consistente)
- `load_kw` (potencia demanda >= 0)
- `buy_price_eur_kwh` (>= 0)

## 5.3 Columnas opcionales

- `pv_kw` (>= 0)
- `sell_price_eur_kwh` (>= 0)
- `import_limit_kw` (si no se define globalmente)
- `site_id`, `tariff_period`, `notes` (metadata)

## 5.4 Reglas de calidad de dato

- Sin duplicados de `timestamp`.
- Orden temporal ascendente.
- Frecuencia uniforme de origen: `15min` o `60min` (otras frecuencias: rechazo con mensaje guiado).
- Manejo de faltantes configurable:
  - `strict`: error
  - `interpolate_limited`: interpolación lineal limitada
  - `forward_fill_prices`: para precios

## 5.5 Formato interno normalizado (canónico)

Internamente siempre se convierte a **paso de 15 minutos**:

- Índice continuo `DatetimeIndex` en 15min.
- Conversión si origen es horario:
  - Variables de potencia (`load_kw`, `pv_kw`): replicación por bloque horario o interpolación escalonada según configuración.
  - Precios: réplica por bloque horario.
- Arrays `float64` contiguos para cálculo vectorizado.
- Unidades:
  - Potencia: kW
  - Energía por paso: kWh = `kW * 0.25`
  - Coste: EUR

## 5.6 Esquema DTO de entrada (resumen)

```text
InputDataSchemaDTO
- timestamp_col: str = "timestamp"
- load_col: str = "load_kw"
- pv_col: str | None
- buy_price_col: str = "buy_price_eur_kwh"
- sell_price_col: str | None
- timezone: str | None
- source_resolution_minutes: int (15 o 60)
- normalization_mode: str
```

---

## 6) Diseño del motor de simulación

## 6.1 Clase clave: `SimulationEngine`

Responsabilidad: ejecutar simulación completa por escenarios y horizontes, con partición diaria y encadenado de SoC.

Métodos propuestos:

- `run(request: SimulationRequest) -> ResultsBundle`
- `_run_baseline(...) -> ScenarioResult`
- `_run_bess_daily_optimized(...) -> ScenarioResult`
- `_build_day_problem(day_slice, soc_ini_kwh, configs) -> DayOptimizationProblem`
- `_merge_day_results(...) -> TimeSeriesResult`

## 6.2 Ejecución diaria con encadenado SoC

1. Particionar series en días naturales.
2. Inicializar `soc_0` desde config.
3. Para cada día `d`:
   - Construir problema diario con límites técnicos y reglas de red.
   - Resolver (solver adapter) y obtener:
     - `charge_kw[t]`
     - `discharge_kw[t]`
     - `soc_kwh[t]`
     - `grid_import_kw[t]`, `grid_export_kw[t]`
     - `objective_cost_day`
   - Fijar `soc_ini` del día siguiente = `soc_fin` del día actual.
4. Consolidar resultados anuales.
5. Calcular KPIs comparativos vs baseline.

## 6.3 `ResultsBundle` (salida canónica)

```text
ResultsBundle
- run_metadata
  - started_at, elapsed_ms, solver_name, warnings
- baseline
  - timeseries: DataFrame/arrays
  - kpis: KpiDTO
- bess_optimized
  - timeseries: DataFrame/arrays
  - kpis: KpiDTO
- delta
  - annual_savings_eur
  - energy_import_reduction_kwh
  - peak_reduction_kw
  - self_consumption_improvement_pct
- diagnostics
  - infeasible_days: list[date]
  - clipped_constraints_count
```

---

## 7) Casos de uso (application layer)

1. **LoadInputFileUseCase**
   - Lee archivo y devuelve previsualización + metadatos + warnings.

2. **ValidateInputDataUseCase**
   - Valida esquema, frecuencia, huecos, unidades y rangos.

3. **RunSimulationUseCase**
   - Normaliza entrada, construye request, ejecuta `SimulationEngine`, retorna `ResultsBundle`.

4. **ExportResultsUseCase**
   - Exporta resultados a Excel con hojas por escenario + KPIs + resumen ejecutivo.

5. **SaveProject/LoadProjectUseCase**
   - Persistencia de configuración de proyecto para reproducibilidad.

---

## 8) UI/UX propuesta (PySide6)

## 8.1 Estructura de navegación

- Ventana principal con **Sidebar** izquierda y área de contenido.
- Páginas:
  1. **Importar datos**
  2. **Parámetros BESS y mercado**
  3. **Ejecución**
  4. **Resultados y KPIs**
  5. **Exportación**

## 8.2 Página 1 — Importar datos

- Drag & drop CSV/XLSX.
- Selector de hoja (Excel).
- Mapeo de columnas (combos automáticos + manual).
- Vista previa (100-500 filas).
- Indicadores de calidad: frecuencia detectada, faltantes, duplicados.

## 8.3 Página 2 — Parámetros

- BESS:
  - capacidad, SoC min/max/inicial, potencias máx, eficiencias.
- Operación:
  - permitir carga de red, permitir exportación, límite importación.
- Tarifas:
  - desde archivo o tarifa plana.
- Validación inmediata con mensajes accionables.

## 8.4 Página 3 — Ejecución

- Resumen del caso.
- Botón “Simular”.
- Barra de progreso por día.
- Log resumido de warnings/errores.

## 8.5 Página 4 — Resultados

- KPIs tipo tarjeta:
  - coste base, coste con BESS, ahorro anual, % ahorro.
  - energía importada/exportada, pico de potencia.
- Gráficas:
  - perfil diario representativo (load/pv/charge/discharge/soc).
  - comparativa mensual de costes.
  - histograma de SoC.
- Tabla detallada con filtro/ordenación.

## 8.6 Página 5 — Exportación

- Selección de nombre/ruta de archivo.
- Opciones: granularidad, incluir hojas diagnósticas, incluir charts embebidos.
- Resultado de exportación y acceso rápido al fichero.

## 8.7 Flujo de usuario de extremo a extremo

1. Cargar archivo.
2. Mapear columnas y validar.
3. Configurar BESS/tarifas/reglas.
4. Ejecutar simulación.
5. Revisar KPIs y gráficas.
6. Exportar Excel.
7. Guardar proyecto (opcional).

---

## 9) Recomendaciones de rendimiento

1. **Evitar `iterrows` y bucles Python por fila**.
   - Usar operaciones vectorizadas con NumPy/Pandas.

2. **Representación dual DataFrame/ndarray**.
   - DataFrame para I/O y UI.
   - ndarrays contiguos (`float64`) para cálculo intensivo.

3. **Partición por día + preasignación**.
   - Procesar en bloques diarios para solver y preasignar arrays de salida anual.

4. **Conversión de tipos temprana**.
   - `astype(np.float64, copy=False)` cuando aplique.

5. **Minimizar copias**.
   - Reusar vistas/slices por índices enteros.

6. **Exportación eficiente a Excel**.
   - `xlsxwriter`/`openpyxl` con escritura por hoja consolidada.
   - Evitar escribir celda a celda en bucles Python.

7. **Escalabilidad para años múltiples**.
   - Modo chunking por meses para cálculos auxiliares y visualización.

8. **Telemetría de performance**.
   - Medir tiempos: carga, normalización, solve total, exportación.

---

## 10) Estrategia de validación y robustez

- Validación multinivel:
  - UI (feedback inmediato)
  - Application (casos de uso)
  - Domain (reglas estrictas)
- Manejo de errores con categorías:
  - `InputSchemaError`
  - `DataQualityError`
  - `OptimizationInfeasibleError`
  - `ExportError`
- Política ante días infactibles:
  - Registrar diagnóstico.
  - Permitir continuar (modo tolerante) o abortar (modo estricto).

---

## 11) TODOs priorizados

## Prioridad P0 (fundacional)

1. Crear estructura de paquetes y configuración de proyecto (pyproject, lint/test básicos).
2. Implementar modelos de dominio (`BatteryConfig`, `SimulationRequest`, `ResultsBundle`).
3. Implementar `LoadInputFileUseCase` + `ValidateInputDataUseCase`.
4. Implementar `NormalizationService` a formato canónico 15min.
5. Implementar `SimulationEngine` esqueleto con pipeline baseline + diario optimizado (sin solver real).
6. Implementar puertos e inyección de dependencias mínima.

## Prioridad P1 (MVP funcional)

7. Implementar adapter de optimización diaria (`OptimizationRepository`) con solver inicial.
8. Implementar UI básica (sidebar + 5 páginas + formularios principales).
9. Integrar ejecución asíncrona/no bloqueante desde UI.
10. Implementar vista de KPIs y 2-3 gráficas clave.
11. Implementar exportación Excel multi-hoja.

## Prioridad P2 (calidad/escala)

12. Añadir tests unitarios de dominio y aplicación.
13. Añadir tests de integración para carga de datos y exportación.
14. Añadir persistencia de proyecto (guardar/cargar configuración).
15. Mejorar diagnósticos de infeasibilidad por día.
16. Optimizar performance en datasets anuales grandes.

## Prioridad P3 (evolutivo)

17. Múltiples estrategias de optimización (coste mínimo, peak-shaving, arbitraje híbrido).
18. Sensibilidad paramétrica (barrido automático de capacidad/potencia).
19. Reporte ejecutivo PDF adicional.
20. Internacionalización UI (ES/EN).

---

## 12) Decisiones abiertas (para siguiente iteración)

- Solver inicial exacto (PuLP/CBC vs HiGHS vs Pyomo).
- Política de degradación de batería (incluir coste por ciclo o no en MVP).
- Soporte timezone/DST en modo estricto o simplificado.
- Librería de gráficas embebidas en PySide6 (QtCharts vs matplotlib/pyqtgraph).

---

## 13) Criterios de aceptación del diseño

- Arquitectura y responsabilidades claras por capa.
- Contrato de entrada definido con requeridos/opcionales.
- Formato canónico a 15 minutos definido.
- Diseño de UI y flujo de usuario completo.
- Clases clave y `SimulationEngine` definidos sin implementación de solver.
- Backlog de TODOs priorizado para ejecución incremental.
