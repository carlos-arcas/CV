"""Workers QThread reutilizables para tareas de larga duración."""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from application.engine import SimulationEngine
from domain.models import SimulationMode
from application.use_cases import RunSimulationUseCase
from infrastructure.io.cache_store import CacheStore
from ui.viewmodels.app_state import AppState


class SimulationWorker(QObject):
    progress = Signal(int, int, str)
    finished = Signal(object)
    failed = Signal(object)

    def __init__(self, state: AppState, *, cache_store: CacheStore | None = None) -> None:
        super().__init__()
        self.state = state
        self.cache_store = cache_store
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        if self.state.input_data is None:
            self.failed.emit(RuntimeError("Debe cargar datos antes de simular."))
            return
        try:
            def on_progress(current: int, total: int, message: str) -> None:
                if self._cancelled:
                    raise RuntimeError("Simulación cancelada por el usuario.")
                self.progress.emit(current, total, message)

            runner = RunSimulationUseCase(engine=SimulationEngine(progress_callback=on_progress))
            results = runner.execute(
                self.state.input_data,
                self.state.scenario,
                include_detail=self.state.export_detail,
                use_cache=self.state.use_cache,
                cache_store=self.cache_store,
                debug_mode=self.state.debug_mode,
                mode=SimulationMode.FAST if self.state.fast_mode else SimulationMode.OPTIMAL,
            )
            self.finished.emit(results)
        except Exception as exc:
            self.failed.emit(exc)
