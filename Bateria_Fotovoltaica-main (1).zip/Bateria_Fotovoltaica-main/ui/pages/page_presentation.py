from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QGridLayout, QLabel, QMainWindow, QVBoxLayout, QWidget

from ui.components.kpi_card import KpiCard
from ui.viewmodels.app_state import AppState


class PresentationPage(QMainWindow):
    def __init__(self, state: AppState, metadata: dict) -> None:
        super().__init__()
        self.state = state
        self.metadata = metadata
        self.setWindowTitle("Modo Presentación")

        self.kpi_annual = KpiCard("Ahorro anual")
        self.kpi_reduction = KpiCard("Reducción %")
        self.kpi_auto = KpiCard("Autoconsumo %")

        self.figure = Figure(figsize=(10, 4), facecolor="#FFFFFF")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.ax = self.figure.add_subplot(111)

        container = QWidget()
        root = QVBoxLayout(container)
        title = QLabel("Resumen ejecutivo")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:34px;font-weight:800;")

        grid = QGridLayout()
        grid.addWidget(self.kpi_annual, 0, 0)
        grid.addWidget(self.kpi_reduction, 0, 1)
        grid.addWidget(self.kpi_auto, 0, 2)

        root.addWidget(title)
        root.addLayout(grid)
        root.addWidget(self.canvas)
        self.setCentralWidget(container)
        self._refresh()

    def _refresh(self) -> None:
        results = self.state.simulation_results
        if results is None:
            return

        annual = float(results.kpis.get("total_savings_eur", 0.0))
        base = float(results.kpis.get("total_cost_base_eur", 0.0))
        reduction = (annual / base * 100.0) if base > 0 else 0.0
        series = results.series
        served = float(series["load_served_by_battery_kwh"].sum()) if "load_served_by_battery_kwh" in series.columns else 0.0
        load = float(series["load_kwh"].sum()) if "load_kwh" in series.columns else 0.0
        auto = (served / load * 100.0) if load > 0 else 0.0

        self.kpi_annual.set_value(f"{annual:,.0f} €", trend=self.metadata.get("solution_mode", "Optimal LP"), color="#15803D")
        self.kpi_reduction.set_value(f"{reduction:.1f}%", color="#1D4ED8")
        self.kpi_auto.set_value(f"{auto:.1f}%", color="#0F766E")

        monthly = results.kpis.get("monthly")
        values = [float(v) for v in monthly["savings"].tolist()] if monthly is not None and "savings" in monthly else []
        self.ax.clear()
        self.ax.plot(values, color="#16A34A", linewidth=3)
        self.ax.set_title("Ahorro mensual")
        self.ax.grid(alpha=0.2)
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        if event.key() == Qt.Key_Escape:
            self.close()
            return
        super().keyPressEvent(event)
