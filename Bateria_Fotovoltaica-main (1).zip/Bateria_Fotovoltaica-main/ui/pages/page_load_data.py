from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFileDialog, QLabel, QVBoxLayout, QWidget

from application.use_cases import LoadDatasetUseCase, ValidateAndNormalizeUseCase
from ui.components.kpi_card import KpiCard
from ui.components.modern_button import PrimaryButton
from ui.error_boundary import show_error
from ui.viewmodels.app_state import AppState


class LoadDataPage(QWidget):
    validated = Signal(bool)

    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self.loader = LoadDatasetUseCase()
        self.validator = ValidateAndNormalizeUseCase()

        self.btn_select = PrimaryButton("Seleccionar Excel o CSV")
        self.file_label = QLabel("Seleccione un archivo para comenzar")
        self.summary_label = QLabel("Validación pendiente")
        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color:#B00020;")

        self.card_year = KpiCard("Año detectado")
        self.card_rows = KpiCard("Registros")
        self.card_pv = KpiCard("FV detectada")

        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.addWidget(self.btn_select)
        layout.addWidget(self.file_label)
        layout.addWidget(self.summary_label)
        layout.addWidget(self.card_year)
        layout.addWidget(self.card_rows)
        layout.addWidget(self.card_pv)
        layout.addWidget(self.error_label)
        layout.addStretch()

        self.btn_select.clicked.connect(self._select_file)

    def _select_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar dataset", "", "Excel/CSV (*.xlsx *.xls *.csv)")
        if not path:
            return
        self.file_label.setText(f"Archivo: {Path(path).name}")
        self.error_label.clear()
        try:
            loaded = self.loader.execute(path)
            normalized = self.validator.execute(loaded)
            self.state.input_data = normalized
            self.state.reset_results()
            status = self.state.dataset_status()
            self.card_year.set_value(status.get("year", "-"), trend="Validado", color="#0F766E")
            self.card_rows.set_value(status.get("rows", "0"), trend="Registros", color="#1D4ED8")
            self.card_pv.set_value(status.get("pv", "No"), trend="FV", color="#16A34A")
            self.summary_label.setText("Dataset cargado y validado correctamente.")
            self.validated.emit(True)
        except Exception as exc:
            self.validated.emit(False)
            self.summary_label.setText("No se pudo validar el archivo.")
            self.error_label.setText("Revise columnas y formato temporal de los datos.")
            show_error(self, exc)
