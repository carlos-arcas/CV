"""Página para edición básica de parámetros de escenario BESS."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from application.use_cases import GenerateDatasetUseCase, TrainImitatorUseCase
from infrastructure.persistence.model_store import load_model_bundle
from domain.finance_models import CapexParams, FinancingParams, OpexParams, RentalParams
from domain.models import BatteryParams
from ui.viewmodels.app_vm import AppViewModel


class ScenarioPage(QWidget):
    """Formulario para configurar escenario y flujo de entrenamiento ML."""

    def __init__(self, vm: AppViewModel) -> None:
        super().__init__()
        self.vm = vm
        self.status = QLabel("Configura parámetros y pulsa Guardar escenario.")
        self.model_info = QLabel("Modelos: sin bundle cargado.")
        self.capacity = self._spin(0.1, 100000.0, vm.scenario.battery.capacity_kwh)
        self.power = self._spin(0.1, 100000.0, vm.scenario.battery.power_kw)
        self.soc_initial = self._spin(0.0, 100.0, vm.scenario.battery.soc_initial_pct)
        self.soc_min = self._spin(0.0, 100.0, vm.scenario.battery.soc_min_pct)
        self.eta_c = self._spin(0.01, 1.0, vm.scenario.battery.charge_efficiency)
        self.eta_d = self._spin(0.01, 1.0, vm.scenario.battery.discharge_efficiency)
        self.allow_sell = QCheckBox("Permitir venta a red")
        self.allow_sell.setChecked(vm.scenario.tariff.allow_sell)
        self.ml_enabled = QCheckBox("Activar modo ML (rápido)")
        self.ml_enabled.setChecked(vm.ml_enabled)
        self.model_folder_label = QLabel(vm.ml_model_path)
        self.test_years_input = QLineEdit("2025")
        self.test_years_input.setPlaceholderText("Años test separados por coma, ej: 2025")
        self.capex_kwh = self._spin(0.0, 100000.0, vm.finance_capex.battery_cost_eur_per_kwh)
        self.capex_kw = self._spin(0.0, 100000.0, vm.finance_capex.inverter_cost_eur_per_kw)
        self.installation_cost = self._spin(0.0, 1_000_000.0, vm.finance_capex.installation_fixed_cost_eur)
        self.maintenance_annual = self._spin(0.0, 1_000_000.0, vm.finance_opex.annual_maintenance_eur)
        self.renting_term_months = self._spin(1.0, 360.0, float(vm.finance_rental.term_months))
        self.renting_cost_capital = self._spin(0.0, 100.0, vm.finance_rental.annual_cost_of_capital_pct)
        self.renting_margin = self._spin(0.0, 1000.0, vm.finance_rental.margin_pct)
        self.renting_min_fee = self._spin(0.0, 100000.0, vm.finance_rental.minimum_monthly_fee_eur or 0.0)
        self.renting_residual = self._spin(0.0, 100.0, vm.finance_rental.residual_value_pct)
        self.loan_interest = self._spin(0.0, 100.0, vm.finance_financing.annual_interest_pct)
        self.loan_term_months = self._spin(1.0, 360.0, float(vm.finance_financing.term_months))
        self.loan_down_payment = self._spin(0.0, 1_000_000.0, vm.finance_financing.down_payment_eur)
        self.finance_discount = self._spin(0.0, 1.0, vm.finance_discount_rate_annual)
        self.finance_horizon = self._spin(1.0, 40.0, float(vm.finance_horizon_years))
        self._setup_ui()
        self.refresh_from_vm()

    def _spin(self, minimum: float, maximum: float, value: float) -> QDoubleSpinBox:
        """Construye un spinbox decimal con rango y valor inicial."""
        widget = QDoubleSpinBox()
        widget.setRange(minimum, maximum)
        widget.setDecimals(4)
        widget.setValue(value)
        return widget

    def _setup_ui(self) -> None:
        """Configura layout y eventos del panel de escenario y modelos."""
        root = QVBoxLayout()
        form = QFormLayout()
        form.addRow("Capacidad (kWh)", self.capacity)
        form.addRow("Potencia (kW)", self.power)
        form.addRow("SoC inicial (%)", self.soc_initial)
        form.addRow("SoC mínimo (%)", self.soc_min)
        form.addRow("Eficiencia carga (ηc)", self.eta_c)
        form.addRow("Eficiencia descarga (ηd)", self.eta_d)
        form.addRow("Venta", self.allow_sell)
        form.addRow("ML", self.ml_enabled)
        form.addRow("Años de test", self.test_years_input)

        form.addRow(QLabel("Costes y financiación"))
        form.addRow("CAPEX batería (€/kWh)", self.capex_kwh)
        form.addRow("CAPEX inversor (€/kW)", self.capex_kw)
        form.addRow("Instalación fija (€)", self.installation_cost)
        form.addRow("Mantenimiento anual OPEX (€)", self.maintenance_annual)
        form.addRow("Renting plazo (meses)", self.renting_term_months)
        form.addRow("Renting coste capital anual (%)", self.renting_cost_capital)
        form.addRow("Renting margen (%)", self.renting_margin)
        form.addRow("Renting cuota mínima (€)", self.renting_min_fee)
        form.addRow("Renting residual (%)", self.renting_residual)
        form.addRow("Préstamo interés anual (%)", self.loan_interest)
        form.addRow("Préstamo plazo (meses)", self.loan_term_months)
        form.addRow("Préstamo entrada inicial (€)", self.loan_down_payment)
        form.addRow("Descuento VAN (decimal)", self.finance_discount)
        form.addRow("Horizonte VAN (años)", self.finance_horizon)

        save_btn = QPushButton("Guardar escenario")
        save_btn.clicked.connect(self._on_save)
        dataset_btn = QPushButton("Generar dataset")
        dataset_btn.clicked.connect(self._on_generate_dataset)
        train_btn = QPushButton("Entrenar")
        train_btn.clicked.connect(self._on_train)
        load_model_btn = QPushButton("Cargar modelo")
        load_model_btn.clicked.connect(self._on_load_model)
        select_model_folder_btn = QPushButton("Seleccionar carpeta de modelos")
        select_model_folder_btn.clicked.connect(self._on_select_model_folder)

        self.status.setWordWrap(True)
        self.status.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.model_info.setWordWrap(True)

        root.addLayout(form)
        root.addWidget(save_btn)
        root.addWidget(dataset_btn)
        root.addWidget(train_btn)
        root.addWidget(select_model_folder_btn)
        root.addWidget(self.model_folder_label)
        root.addWidget(load_model_btn)
        root.addWidget(self.model_info)
        root.addWidget(self.status)
        root.addStretch()
        self.setLayout(root)

    def refresh_from_vm(self) -> None:
        """Sincroniza campos visuales a partir del estado actual del ViewModel."""
        self.capacity.setValue(self.vm.scenario.battery.capacity_kwh)
        self.power.setValue(self.vm.scenario.battery.power_kw)
        self.soc_initial.setValue(self.vm.scenario.battery.soc_initial_pct)
        self.soc_min.setValue(self.vm.scenario.battery.soc_min_pct)
        self.eta_c.setValue(self.vm.scenario.battery.charge_efficiency)
        self.eta_d.setValue(self.vm.scenario.battery.discharge_efficiency)
        self.allow_sell.setChecked(self.vm.scenario.tariff.allow_sell)
        self.ml_enabled.setChecked(self.vm.ml_enabled)
        self.model_folder_label.setText(self.vm.ml_model_path)
        self.capex_kwh.setValue(self.vm.finance_capex.battery_cost_eur_per_kwh)
        self.capex_kw.setValue(self.vm.finance_capex.inverter_cost_eur_per_kw)
        self.installation_cost.setValue(self.vm.finance_capex.installation_fixed_cost_eur)
        self.maintenance_annual.setValue(self.vm.finance_opex.annual_maintenance_eur)
        self.renting_term_months.setValue(float(self.vm.finance_rental.term_months))
        self.renting_cost_capital.setValue(self.vm.finance_rental.annual_cost_of_capital_pct)
        self.renting_margin.setValue(self.vm.finance_rental.margin_pct)
        self.renting_min_fee.setValue(self.vm.finance_rental.minimum_monthly_fee_eur or 0.0)
        self.renting_residual.setValue(self.vm.finance_rental.residual_value_pct)
        self.loan_interest.setValue(self.vm.finance_financing.annual_interest_pct)
        self.loan_term_months.setValue(float(self.vm.finance_financing.term_months))
        self.loan_down_payment.setValue(self.vm.finance_financing.down_payment_eur)
        self.finance_discount.setValue(self.vm.finance_discount_rate_annual)
        self.finance_horizon.setValue(float(self.vm.finance_horizon_years))
        trained_at = self.vm.ml_model_info.get("trained_at", "N/D")
        metrics = self.vm.ml_model_info.get("metrics", {})
        self.model_info.setText(
            f"Modelos\nRuta: {self.vm.ml_model_path}\nFecha entrenamiento: {trained_at}\nMétricas: {metrics}"
        )

    def _on_save(self) -> None:
        """Valida formulario y persiste parámetros en el ViewModel."""
        try:
            battery = BatteryParams(
                capacity_kwh=self.capacity.value(),
                power_kw=self.power.value(),
                soc_initial_pct=self.soc_initial.value(),
                soc_min_pct=self.soc_min.value(),
                charge_efficiency=self.eta_c.value(),
                discharge_efficiency=self.eta_d.value(),
            )
            self.vm.update_battery(battery=battery, allow_sell=self.allow_sell.isChecked())
            self.vm.ml_enabled = self.ml_enabled.isChecked()
            self.vm.finance_capex = CapexParams(
                battery_cost_eur_per_kwh=self.capex_kwh.value(),
                inverter_cost_eur_per_kw=self.capex_kw.value(),
                installation_fixed_cost_eur=self.installation_cost.value(),
            )
            self.vm.finance_opex = OpexParams(annual_maintenance_eur=self.maintenance_annual.value())
            self.vm.finance_rental = RentalParams(
                term_months=int(self.renting_term_months.value()),
                annual_cost_of_capital_pct=self.renting_cost_capital.value(),
                margin_pct=self.renting_margin.value(),
                minimum_monthly_fee_eur=self.renting_min_fee.value() if self.renting_min_fee.value() > 0 else None,
                residual_value_pct=self.renting_residual.value(),
            )
            self.vm.finance_financing = FinancingParams(
                annual_interest_pct=self.loan_interest.value(),
                term_months=int(self.loan_term_months.value()),
                down_payment_eur=self.loan_down_payment.value(),
            )
            self.vm.finance_discount_rate_annual = self.finance_discount.value()
            self.vm.finance_horizon_years = int(self.finance_horizon.value())
            self.status.setText("Escenario y parámetros financieros guardados correctamente.")
        except Exception as exc:
            self.status.setText(f"Error de validación: {exc}")

    def _on_generate_dataset(self) -> None:
        """Genera dataset de imitación desde datos normalizados y escenario actual."""
        if self.vm.input_data is None:
            self.status.setText("Primero carga y valida un dataset.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Guardar dataset", self.vm.ml_dataset_path, "CSV (*.csv);;Parquet (*.parquet)")
        if not path:
            return
        generator = GenerateDatasetUseCase()
        if self.vm.input_collection.datasets:
            dataset = generator.execute_multi(self.vm.input_collection, self.vm.scenario, output_path=path)
        else:
            dataset = generator.execute(self.vm.input_data, self.vm.scenario, output_path=path)
        self.vm.ml_dataset_path = path
        self.vm.ml_dataset_df = dataset
        years = sorted(dataset["year"].astype(int).unique().tolist()) if "year" in dataset.columns else []
        self.status.setText(f"Dataset de imitación generado: {path} | años={years}")

    def _on_train(self) -> None:
        """Entrena un bundle ML y lo guarda en una carpeta seleccionada."""
        if self.vm.ml_dataset_df is None:
            self.status.setText("Genera o carga antes un dataset de imitación.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Guardar modelos en carpeta", self.vm.ml_model_path)
        if not folder:
            return
        try:
            test_years = [int(value.strip()) for value in self.test_years_input.text().split(",") if value.strip()]
        except ValueError:
            self.status.setText("Años de test inválidos. Usa formato: 2025 o 2024,2025")
            return
        result = TrainImitatorUseCase().execute(
            self.vm.ml_dataset_df,
            model_output_path=folder,
            mode="classification",
            test_years=test_years if test_years else None,
        )
        if result.get("status") != "ok":
            self.status.setText(result.get("message", "No se pudo entrenar."))
            return
        self.vm.ml_model_path = folder
        self.vm.ml_model_info = {
            "name": Path(folder).name,
            "trained_at": result.get("trained_at"),
            "metrics": {
                **result.get("metrics", {}),
                "metrics_by_year": result.get("metrics_by_year", {}),
                "years_used": result.get("years_used", []),
                "total_rows": result.get("total_rows", 0),
                "feature_columns": result.get("feature_columns", []),
            },
        }
        self.refresh_from_vm()
        self.status.setText(f"ModelBundle entrenado y guardado en: {folder}")

    def _on_load_model(self) -> None:
        """Carga referencia de modelo desde una carpeta con metadata persistida."""
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de modelo ML", self.vm.ml_model_path)
        if not folder:
            return
        bundle = load_model_bundle(folder)
        self.vm.ml_model_path = folder
        self.vm.ml_model_info = {
            "name": Path(folder).name,
            "trained_at": bundle.metadata.get("trained_at"),
            "metrics": bundle.metadata.get("metrics", {}),
        }
        self.status.setText(f"Modelo cargado: {folder}")
        self.refresh_from_vm()

    def _on_select_model_folder(self) -> None:
        """Permite fijar carpeta base donde se guardarán los modelos ML."""
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de modelos", self.vm.ml_model_path)
        if not folder:
            return
        self.vm.ml_model_path = folder
        self.model_folder_label.setText(folder)
