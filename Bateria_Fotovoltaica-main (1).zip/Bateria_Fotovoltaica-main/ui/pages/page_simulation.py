from __future__ import annotations

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QCheckBox, QHBoxLayout, QLabel, QProgressBar, QVBoxLayout, QWidget

from infrastructure.io.cache_store import CacheStore
from ui.components.modern_button import PrimaryButton
from ui.error_boundary import show_error
from ui.viewmodels.app_state import AppState
from ui.workers.simulation_worker import SimulationWorker


class SimulationPage(QWidget):
    simulated = Signal(bool, dict)

    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self.thread: QThread | None = None
        self.worker: SimulationWorker | None = None

        self.run_btn = PrimaryButton("Ejecutar simulación")
        self.run_btn.setMinimumHeight(60)
        self.cancel_btn = PrimaryButton("Cancelar")
        self.cancel_btn.setEnabled(False)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.status = QLabel("Listo para simular")
        self.fast_checkbox = QCheckBox("Modo rápido (FAST)")
        self.fast_checkbox.setChecked(self.state.fast_mode)
        self.fast_checkbox.toggled.connect(self._on_fast_toggled)

        row = QHBoxLayout()
        row.addWidget(self.run_btn)
        row.addWidget(self.cancel_btn)

        root = QVBoxLayout(self)
        root.addStretch()
        root.addLayout(row)
        root.addWidget(self.fast_checkbox)
        root.addWidget(self.progress)
        root.addWidget(self.status)
        root.addStretch()

        self.run_btn.clicked.connect(self._start)
        self.cancel_btn.clicked.connect(self._cancel)


    def _on_fast_toggled(self, checked: bool) -> None:
        self.state.fast_mode = checked

    def _set_running(self, running: bool) -> None:
        self.run_btn.setEnabled(not running)
        self.cancel_btn.setEnabled(running)

    def _start(self) -> None:
        self._set_running(True)
        self.status.setText("Inicializando...")
        self.progress.setValue(0)

        self.thread = QThread(self)
        self.worker = SimulationWorker(self.state, cache_store=CacheStore())
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(lambda: self._set_running(False))
        self.thread.start()

    def _cancel(self) -> None:
        if self.worker is not None:
            self.worker.cancel()

    def _on_progress(self, current: int, total: int, message: str) -> None:
        value = int((current / max(total, 1)) * 100)
        self.progress.setValue(value)
        self.status.setText(message)

    def _on_finished(self, results: object, metadata: dict) -> None:
        self.state.simulation_results = results
        self.status.setText("Simulación completada")
        self.progress.setValue(100)
        self.simulated.emit(True, metadata)

    def _on_failed(self, message: str) -> None:
        self.status.setText(message)
        self.simulated.emit(False, {})
        show_error(self, RuntimeError(message))
