"""Página para ejecutar simulación real y exportar informe Excel."""

from __future__ import annotations

import logging
import time
from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QLabel,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from application.engine import SimulationEngine
from application.use_cases import CompareSimulationsUseCase, RunSimulationFastUseCase, RunSimulationUseCase
from infrastructure.exporters import export_results_to_excel
from ui.viewmodels.app_vm import AppViewModel

logger = logging.getLogger(__name__)


class SimulationPage(QWidget):
    """Vista de ejecución con simulación óptima, ML y exportación de informe."""

    def __init__(self, vm: AppViewModel) -> None:
        super().__init__()
        self.vm = vm
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status = QLabel("Listo para simular.")
        self.elapsed = QLabel("Tiempo total: --")
        self.kpis = QLabel("KPIs: pendientes")
        self.export_detail = QCheckBox("Exportar detallado (Detalle periodos)")
        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self._total_days = 0
        self._setup_ui()

    def _setup_ui(self) -> None:
        root = QVBoxLayout()
        run_opt_btn = QPushButton("Ejecutar Óptimo (recomendado)")
        run_opt_btn.clicked.connect(self._on_run_optimal)
        run_ml_btn = QPushButton("Ejecutar ML (aceleración)")
        run_ml_btn.clicked.connect(self._on_run_ml)
        compare_btn = QPushButton("Comparar")
        compare_btn.clicked.connect(self._on_compare)
        export_btn = QPushButton("Exportar informe Excel")
        export_btn.clicked.connect(self._on_export_report)
        root.addWidget(run_opt_btn)
        root.addWidget(run_ml_btn)
        root.addWidget(compare_btn)
        root.addWidget(self.export_detail)
        root.addWidget(export_btn)
        root.addWidget(self.progress)
        root.addWidget(self.status)
        root.addWidget(self.elapsed)
        root.addWidget(self.kpis)
        root.addWidget(self.logs)
        self.setLayout(root)

    def _progress_callback(self, current: int, total: int, message: str) -> None:
        self._total_days = total
        self.progress.setValue(int((current / total) * 100) if total else 0)
        self.status.setText(f"Progreso día {current}/{total}: {message}")
        self.logs.append(message)

    def _on_run_optimal(self) -> None:
        if self.vm.input_data is None:
            self.status.setText("Primero debes cargar y validar un dataset.")
            return
        self.progress.setValue(0)
        self.logs.clear()
        engine = SimulationEngine(progress_callback=self._progress_callback)
        start = time.perf_counter()
        try:
            result = RunSimulationUseCase(engine=engine).execute(self.vm.input_data, self.vm.scenario)
            self.vm.results = result
            self.vm.results_optimal = result
            duration = time.perf_counter() - start
            self.progress.setValue(100)
            self.elapsed.setText(f"Tiempo total: {duration:.2f} s")
            self.kpis.setText(f"Óptimo ahorro={result.kpis.get('total_savings_eur', 0.0):.2f} €")
            self.status.setText("Simulación óptima finalizada.")
        except Exception as exc:
            logger.exception("Error en simulación óptima")
            self.status.setText(f"Error durante simulación óptima: {exc}")

    def _on_run_ml(self) -> None:
        if self.vm.input_data is None:
            self.status.setText("Primero debes cargar y validar un dataset.")
            return
        try:
            result = RunSimulationFastUseCase(engine=SimulationEngine()).execute(
                self.vm.input_data,
                self.vm.scenario,
                model_path=self.vm.ml_model_path,
            )
            self.vm.results = result
            self.vm.results_ml = result
            self.kpis.setText(f"ML ahorro={result.kpis.get('total_savings_eur', 0.0):.2f} €")
            self.elapsed.setText(f"Tiempo total: {result.kpis.get('execution_seconds', 0.0):.2f} s")
            self.status.setText("Simulación ML completada.")
        except Exception as exc:
            self.status.setText(f"Error simulación ML: {exc}")

    def _on_compare(self) -> None:
        if self.vm.input_data is None:
            self.status.setText("Primero debes cargar y validar un dataset.")
            return
        try:
            compare = CompareSimulationsUseCase(engine=SimulationEngine()).execute(
                self.vm.input_data,
                self.vm.scenario,
                model_path=self.vm.ml_model_path,
            )
            self.vm.results_optimal = compare["optimal"]
            self.vm.results_ml = compare["ml"]
            self.vm.results = compare["optimal"]
            self.vm.compare_metrics = compare["compare"]
            self.kpis.setText(f"Δ ahorro={compare['compare']['delta_eur']:.2f} € ({compare['compare']['delta_pct']:.2f}%)")
            self.status.setText("Comparación completada.")
        except Exception as exc:
            self.status.setText(f"Error al comparar: {exc}")

    def _on_export_report(self) -> None:
        """Exporta informe técnico-comercial en Excel con detalle opcional."""
        if self.vm.results is None:
            self.status.setText("Primero ejecuta una simulación.")
            return
        out_dir = Path(self.vm.export_folder)
        out_dir.mkdir(parents=True, exist_ok=True)
        path, _ = QFileDialog.getSaveFileName(self, "Guardar informe", str(out_dir / "informe_bess.xlsx"), "Excel (*.xlsx)")
        if not path:
            return
        export_results_to_excel(
            results=self.vm.results,
            path=path,
            compare_metrics=self.vm.compare_metrics,
            dimensioning_df=self.vm.dimensioning_results,
            dimensioning_recommendation_df=self.vm.dimensioning_recommendation,
            export_level="full" if self.export_detail.isChecked() else "kpis_only",
            finance_payload=self.vm.finance_results,
            offer_payload=self.vm.offer_optimization,
        )
        self.status.setText(f"Informe exportado en: {path}")
