"""Página de carga y resumen de dataset de entrada."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from application.dto import InputDataDTO, InputDatasetCollectionDTO
from application.use_cases import (
    LoadDatasetCollectionUseCase,
    LoadDatasetUseCase,
    ValidateAndNormalizeCollectionUseCase,
    ValidateAndNormalizeUseCase,
)
from ui.viewmodels.app_vm import AppViewModel


class DataPage(QWidget):
    """Vista para cargar archivos y mostrar resumen de datos.

    Entradas:
        vm: ViewModel compartido de la aplicación.

    Salidas:
        Página que actualiza estado global tras cargar/validar datos.

    Errores relevantes:
        Captura excepciones y las presenta en el área de resumen.
    """

    def __init__(self, vm: AppViewModel) -> None:
        """Inicializa controles visuales y casos de uso asociados."""
        super().__init__()
        self.vm = vm
        self.loader = LoadDatasetUseCase()
        self.loader_multi = LoadDatasetCollectionUseCase()
        self.validator = ValidateAndNormalizeUseCase()
        self.validator_multi = ValidateAndNormalizeCollectionUseCase()
        self.path_label = QLabel("Sin archivo cargado")
        self.summary = QTextEdit()
        self.summary.setReadOnly(True)
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Configura layout y eventos de la página de datos."""
        root = QVBoxLayout()
        row = QHBoxLayout()
        load_button = QPushButton("Cargar archivo")
        load_button.clicked.connect(self._on_load_clicked)
        load_multi_button = QPushButton("Añadir años")
        load_multi_button.clicked.connect(self._on_load_multi_clicked)
        row.addWidget(load_button)
        row.addWidget(load_multi_button)
        row.addWidget(self.path_label)
        root.addLayout(row)
        root.addWidget(self.summary)
        self.setLayout(root)

    def _on_load_clicked(self) -> None:
        """Abre selector de archivos y ejecuta pipeline de carga/normalización."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecciona archivo de datos",
            "",
            "Datos (*.csv *.xlsx *.xls)",
        )
        if not path:
            return
        self.path_label.setText(path)
        try:
            loaded = self.loader.execute(path)
            normalized = self.validator.execute(loaded)
            self.vm.input_data = normalized
            self.vm.input_collection = InputDatasetCollectionDTO(datasets=[normalized])
            self.summary.setText(self._build_multi_summary_text(self.vm.input_collection))
        except Exception as exc:
            self.summary.setText(f"Error al cargar datos:\n{exc}")

    def _on_load_multi_clicked(self) -> None:
        """Carga múltiples años, normaliza cada archivo y construye resumen consolidado."""
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Selecciona archivos de años",
            "",
            "Datos (*.csv *.xlsx *.xls)",
        )
        if not paths:
            return
        try:
            loaded_collection = self.loader_multi.execute(paths)
            normalized_collection = self.validator_multi.execute(loaded_collection)
            self.vm.input_collection = normalized_collection
            merged_df = (
                normalized_collection.datasets[0].dataframe
                if len(normalized_collection.datasets) == 1
                else pd.concat(
                    [item.dataframe for item in normalized_collection.datasets], ignore_index=True
                )
                .sort_values("timestamp")
                .reset_index(drop=True)
            )
            merged_warnings = [warning for item in normalized_collection.datasets for warning in item.warnings]
            self.vm.input_data = InputDataDTO(
                dataframe=merged_df,
                source_path=";".join(item.source_path for item in normalized_collection.datasets),
                warnings=merged_warnings,
            )
            self.path_label.setText(f"{len(paths)} archivos cargados")
            self.summary.setText(self._build_multi_summary_text(normalized_collection))
        except Exception as exc:
            self.summary.setText(f"Error al cargar años:\n{exc}")

    def _build_summary_text(self, input_data: InputDataDTO) -> str:
        """Construye un resumen legible de filas, fechas y timestep detectado."""
        df = input_data.dataframe
        ts = df["timestamp"]
        freq_info = "N/D"
        if len(df) >= 2:
            freq_info = str((ts.iloc[1] - ts.iloc[0]))
        warnings = "\n".join(f"- {w}" for w in input_data.warnings) or "Sin advertencias"
        return (
            f"Filas: {len(df)}\n"
            f"Rango: {ts.min()} -> {ts.max()}\n"
            f"Timestep detectado: {freq_info}\n"
            f"Warnings:\n{warnings}"
        )

    def _build_multi_summary_text(self, collection: InputDatasetCollectionDTO) -> str:
        """Construye resumen por archivo/año para entrenamiento multi-año."""
        lines = ["Resumen multi-año:"]
        total_rows = 0
        all_years: set[int] = set()
        for item in collection.datasets:
            df = item.dataframe
            ts = df["timestamp"]
            years = sorted(pd.to_datetime(ts).dt.year.astype(int).unique().tolist()) if not df.empty else []
            all_years.update(years)
            total_rows += len(df)
            label = Path(item.source_path).name
            lines.append(
                f"- {label}: filas={len(df)}, rango={ts.min()} -> {ts.max()}, años={years}, warnings={len(item.warnings)}"
            )
        lines.append(f"Total filas: {total_rows}")
        lines.append(f"Años cargados: {sorted(all_years)}")
        return "\n".join(lines)
