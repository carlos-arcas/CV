from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFormLayout, QLabel, QMessageBox, QProgressBar, QVBoxLayout, QWidget

from application.finance.finance_use_cases import RunFinancialAnalysisUseCase
from domain.finance_models import CapexParams, FinancingParams, OpexParams, RentalParams
from ui.components.kpi_card import KpiCard
from ui.components.modern_button import PrimaryButton
from ui.components.numeric_input import NumericInput
from ui.viewmodels.app_state import AppState


class OfferPage(QWidget):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state

        self.cost_input = NumericInput(50, 2000, 10, "€/kWh", "Coste comercial de batería")
        self.term_input = NumericInput(12, 180, 1, "meses", "Plazo del contrato")
        self.margin_input = NumericInput(0, 80, 1, "%", "Margen deseado de la empresa")

        self.block_title = QLabel("Propuesta recomendada")
        self.block_title.setObjectName("pageTitle")
        self.kpi_fee = KpiCard("Cuota sugerida")
        self.kpi_customer = KpiCard("Beneficio cliente mensual")
        self.kpi_margin = KpiCard("Margen total empresa")
        self.payback_bar = QProgressBar()
        self.payback_text = QLabel("Payback visual")
        self.payback_text.setAlignment(Qt.AlignCenter)

        self.btn_calculate = PrimaryButton("Calcular oferta")
        self.btn_export = PrimaryButton("Generar Informe PDF/Excel")
        self.status = QLabel("")

        form = QFormLayout()
        form.addRow("Coste batería", self.cost_input)
        form.addRow("Plazo", self.term_input)
        form.addRow("Margen deseado", self.margin_input)

        root = QVBoxLayout(self)
        root.addLayout(form)
        root.addWidget(self.btn_calculate)
        root.addWidget(self.block_title)
        root.addWidget(self.kpi_fee)
        root.addWidget(self.kpi_customer)
        root.addWidget(self.kpi_margin)
        root.addWidget(self.payback_text)
        root.addWidget(self.payback_bar)
        root.addWidget(self.btn_export)
        root.addWidget(self.status)

        self.btn_calculate.clicked.connect(self._calculate)
        self.btn_export.clicked.connect(self._export_report)

    def _export_report(self) -> None:
        answer = QMessageBox.question(self, "Confirmar", "¿Sobrescribir informe existente?")
        if answer == QMessageBox.Yes:
            self.status.setText("Exportación disponible en el flujo actual del proyecto.")

    def _calculate(self) -> None:
        if self.state.simulation_results is None:
            QMessageBox.information(self, "Oferta", "Primero ejecute una simulación.")
            return
        try:
            self.state.battery_cost_eur_kwh = self.cost_input.value()
            self.state.offer_term_months = int(self.term_input.value())
            self.state.desired_margin_pct = self.margin_input.value()

            finance = RunFinancialAnalysisUseCase().execute(
                results=self.state.simulation_results,
                capacity_kwh=self.state.scenario.battery.capacity_kwh,
                power_kw=self.state.scenario.battery.power_kw,
                capex_params=CapexParams(battery_cost_eur_per_kwh=self.state.battery_cost_eur_kwh),
                opex_params=OpexParams(),
                financing_params=FinancingParams(term_months=self.state.offer_term_months),
                rental_params=RentalParams(term_months=self.state.offer_term_months, margin_pct=self.state.desired_margin_pct),
            )
            self.state.financial_results = finance

            self.kpi_fee.set_value(f"{finance.rental_customer_fee_eur or 0:.2f} €/mes", trend="Oferta base", color="#1E3A8A")
            self.kpi_customer.set_value(f"{finance.customer_monthly_benefit_eur or 0:.2f} €/mes", trend="Ahorro cliente", color="#16A34A")
            self.kpi_margin.set_value(f"{finance.rental_total_margin_eur or 0:.2f} €", trend="Rentabilidad", color="#1E3A8A")
            payback = finance.loan_payback_month or 0
            years = max(payback / 12.0, 0)
            self.payback_bar.setMaximum(15)
            self.payback_bar.setValue(min(int(years), 15))
            self.payback_text.setText(f"Payback estimado: {years:.1f} años")
            self.status.setText("Oferta calculada correctamente.")
        except Exception:
            QMessageBox.warning(self, "Oferta", "No se ha podido calcular la oferta. Revise los datos.")
