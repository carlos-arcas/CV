from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFormLayout, QGroupBox, QPushButton, QVBoxLayout, QWidget

from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from ui.components.numeric_input import NumericInput
from ui.components.toggle_switch import ToggleSwitch
from ui.viewmodels.app_state import AppState


class ConfigPage(QWidget):
    validated = Signal(bool)

    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state

        self.capacity = NumericInput(1.0, 5000.0, 1.0, "kWh", "Capacidad útil")
        self.power = NumericInput(0.5, 3000.0, 0.5, "kW", "Potencia máxima")
        self.allow_sell = ToggleSwitch("Activar venta a red")

        self.advanced_toggle = QPushButton("Mostrar modo avanzado")
        self.advanced_box = QGroupBox("Modo avanzado")
        self.advanced_box.setVisible(False)
        self.eta_c = NumericInput(0.5, 1.0, 0.01, "", "Eficiencia de carga")
        self.eta_d = NumericInput(0.5, 1.0, 0.01, "", "Eficiencia de descarga")
        self.soc_min = NumericInput(0.0, 90.0, 1.0, "%", "SOC mínimo")
        self.soc_initial = NumericInput(1.0, 100.0, 1.0, "%", "SOC inicial")

        form = QFormLayout()
        form.addRow("Capacidad", self.capacity)
        form.addRow("Potencia", self.power)
        form.addRow("Venta red", self.allow_sell)

        adv_form = QFormLayout(self.advanced_box)
        adv_form.addRow("η carga", self.eta_c)
        adv_form.addRow("η descarga", self.eta_d)
        adv_form.addRow("SOC mínimo", self.soc_min)
        adv_form.addRow("SOC inicial", self.soc_initial)

        root = QVBoxLayout(self)
        root.addLayout(form)
        root.addWidget(self.advanced_toggle)
        root.addWidget(self.advanced_box)
        root.addStretch()

        self._load_values()
        self._connect()
        self._push_to_state()

    def _connect(self) -> None:
        self.advanced_toggle.clicked.connect(self._toggle_advanced)
        for widget in (self.capacity, self.power, self.eta_c, self.eta_d, self.soc_min, self.soc_initial):
            widget.valueChanged.connect(lambda _v: self._push_to_state())
        self.allow_sell.toggled.connect(lambda _v: self._push_to_state())

    def _toggle_advanced(self) -> None:
        visible = not self.advanced_box.isVisible()
        self.advanced_box.setVisible(visible)
        self.advanced_toggle.setText("Ocultar modo avanzado" if visible else "Mostrar modo avanzado")

    def _load_values(self) -> None:
        battery = self.state.scenario.battery
        tariff = self.state.scenario.tariff
        self.capacity.setValue(battery.capacity_kwh)
        self.power.setValue(battery.power_kw)
        self.eta_c.setValue(battery.charge_efficiency)
        self.eta_d.setValue(battery.discharge_efficiency)
        self.soc_min.setValue(battery.soc_min_pct)
        self.soc_initial.setValue(battery.soc_initial_pct)
        self.allow_sell.setChecked(tariff.allow_sell)

    def _push_to_state(self) -> None:
        try:
            battery = BatteryParams(
                capacity_kwh=self.capacity.value(),
                power_kw=self.power.value(),
                soc_min_pct=self.soc_min.value(),
                soc_initial_pct=self.soc_initial.value(),
                charge_efficiency=self.eta_c.value(),
                discharge_efficiency=self.eta_d.value(),
            )
            tariff = TariffParams(allow_sell=self.allow_sell.isChecked())
            self.state.scenario = ScenarioConfig(battery=battery, tariff=tariff, grid=GridParams())
            self.validated.emit(True)
        except Exception:
            self.validated.emit(False)
