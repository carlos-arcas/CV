"""Página de UI para análisis de dimensionamiento de batería."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QGridLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from application.dimensioning import compute_roi, recommend_optimal_size, run_capacity_power_sweep
from infrastructure.exporters import export_dimensioning_to_excel
from infrastructure.persistence.model_store import load_model_bundle
from infrastructure.plotting import plot_roi_vs_capacity, plot_savings_heatmap, plot_savings_vs_capacity
from ui.viewmodels.app_vm import AppViewModel


class DimensioningPage(QWidget):
    """Vista para ejecutar barrido de tamaños, ROI y recomendación automática."""

    def __init__(self, vm: AppViewModel) -> None:
        """Inicializa controles de rango, progreso y exportación."""
        super().__init__()
        self.vm = vm
        self.progress = QProgressBar()
        self.status = QLabel("Configura el barrido y ejecuta el análisis.")
        self.mode_help = QLabel("Modo recomendado: LP óptimo diario.")
        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self._build_form()
        self._setup_ui()

    def _build_form(self) -> None:
        """Construye widgets de entrada para barrido técnico y financiero."""
        self.capacity_min = QDoubleSpinBox(); self.capacity_min.setRange(1.0, 5000.0); self.capacity_min.setValue(5.0)
        self.capacity_max = QDoubleSpinBox(); self.capacity_max.setRange(1.0, 5000.0); self.capacity_max.setValue(50.0)
        self.capacity_step = QDoubleSpinBox(); self.capacity_step.setRange(1.0, 5000.0); self.capacity_step.setValue(5.0)
        self.power_min = QDoubleSpinBox(); self.power_min.setRange(1.0, 2000.0); self.power_min.setValue(5.0)
        self.power_max = QDoubleSpinBox(); self.power_max.setRange(1.0, 2000.0); self.power_max.setValue(25.0)
        self.power_step = QDoubleSpinBox(); self.power_step.setRange(1.0, 2000.0); self.power_step.setValue(5.0)
        self.capex_kwh = QDoubleSpinBox(); self.capex_kwh.setRange(0.0, 10000.0); self.capex_kwh.setValue(350.0)
        self.capex_kw = QDoubleSpinBox(); self.capex_kw.setRange(0.0, 10000.0); self.capex_kw.setValue(120.0)
        self.lifetime = QDoubleSpinBox(); self.lifetime.setRange(1.0, 50.0); self.lifetime.setValue(12.0)
        self.discount = QDoubleSpinBox(); self.discount.setRange(0.0, 1.0); self.discount.setDecimals(3); self.discount.setSingleStep(0.01); self.discount.setValue(0.08)

        self.mode = QComboBox(); self.mode.addItems(["Óptimo (recomendado)", "ML (aceleración) [experimental]"])
        self.sweep_mode = QComboBox(); self.sweep_mode.addItems(["Barrido rápido LP", "Barrido exhaustivo (top-N)"])
        self.top_n = QDoubleSpinBox(); self.top_n.setRange(1, 50); self.top_n.setDecimals(0); self.top_n.setValue(5)
        self.criterion = QComboBox(); self.criterion.addItems(["max_savings", "max_savings_per_eur", "min_payback"])

    def _setup_ui(self) -> None:
        """Monta layout principal de la página con acciones de cálculo/exportación."""
        root = QVBoxLayout()
        grid = QGridLayout()
        grid.addWidget(QLabel("Capacidad min/max/paso (kWh)"), 0, 0)
        grid.addWidget(self.capacity_min, 0, 1); grid.addWidget(self.capacity_max, 0, 2); grid.addWidget(self.capacity_step, 0, 3)
        grid.addWidget(QLabel("Potencia min/max/paso (kW)"), 1, 0)
        grid.addWidget(self.power_min, 1, 1); grid.addWidget(self.power_max, 1, 2); grid.addWidget(self.power_step, 1, 3)
        grid.addWidget(QLabel("CAPEX €/kWh, €/kW"), 2, 0)
        grid.addWidget(self.capex_kwh, 2, 1); grid.addWidget(self.capex_kw, 2, 2)
        grid.addWidget(QLabel("Vida útil (años) y descuento"), 3, 0)
        grid.addWidget(self.lifetime, 3, 1); grid.addWidget(self.discount, 3, 2)
        grid.addWidget(QLabel("Modo"), 4, 0); grid.addWidget(self.mode, 4, 1)
        grid.addWidget(QLabel("Tipo de barrido"), 5, 0); grid.addWidget(self.sweep_mode, 5, 1)
        grid.addWidget(QLabel("Top-N (solo exhaustivo)"), 5, 2); grid.addWidget(self.top_n, 5, 3)
        grid.addWidget(QLabel("Criterio recomendación"), 6, 0); grid.addWidget(self.criterion, 6, 1)

        run_btn = QPushButton("Ejecutar barrido")
        run_btn.clicked.connect(self._on_run_sweep)
        export_btn = QPushButton("Exportar dimensión + gráficas")
        export_btn.clicked.connect(self._on_export)

        root.addLayout(grid)
        root.addWidget(run_btn)
        root.addWidget(export_btn)
        root.addWidget(self.progress)
        root.addWidget(self.status)
        root.addWidget(self.mode_help)
        root.addWidget(self.logs)
        self.setLayout(root)

        self.mode.currentTextChanged.connect(self._update_mode_help)
        self._update_mode_help()

    def _update_mode_help(self) -> None:
        text = self.mode.currentText()
        if "ML" in text:
            self.mode_help.setText("ML experimental: requiere entrenamiento y puede aproximar.")
        else:
            self.mode_help.setText("Óptimo recomendado: no requiere entrenamiento.")

    def _create_range(self, min_value: float, max_value: float, step: float) -> list[float]:
        """Crea lista inclusiva para un rango numérico con paso definido."""
        values = []
        current = min_value
        while current <= max_value + 1e-9:
            values.append(round(current, 6))
            current += step
        return values

    def _progress_callback(self, current: int, total: int, message: str) -> None:
        """Actualiza barra de progreso y log textual durante el barrido."""
        percent = int((current / total) * 100) if total else 0
        self.progress.setValue(percent)
        self.status.setText(message)
        self.logs.append(message)

    def _on_run_sweep(self) -> None:
        """Ejecuta barrido técnico, cálculo ROI y recomendación según criterio."""
        if self.vm.input_data is None:
            self.status.setText("Primero carga y valida un dataset.")
            return

        capacities = self._create_range(self.capacity_min.value(), self.capacity_max.value(), self.capacity_step.value())
        powers = self._create_range(self.power_min.value(), self.power_max.value(), self.power_step.value())
        mode = "ml" if "ML" in self.mode.currentText() else "optimal"
        sweep_mode = "completo" if "exhaustivo" in self.sweep_mode.currentText().lower() else "rapido"

        model_bundle = None
        if mode == "ml":
            model_bundle = load_model_bundle(self.vm.ml_model_path).to_payload()

        self.logs.clear()
        sweep_df, top_periods = run_capacity_power_sweep(
            df_norm=self.vm.input_data.dataframe,
            config=self.vm.scenario,
            capacities=capacities,
            powers=powers,
            mode=mode,
            ml_model_bundle=model_bundle,
            progress_callback=self._progress_callback,
            sweep_mode=sweep_mode,
            top_n=int(self.top_n.value()),
        )
        roi_df = compute_roi(
            sweep_df=sweep_df,
            capex_per_kwh=self.capex_kwh.value(),
            capex_per_kw=self.capex_kw.value(),
            lifetime_years=int(self.lifetime.value()),
            discount_rate=self.discount.value(),
        )
        recommendation = recommend_optimal_size(roi_df, criterion=self.criterion.currentText())

        self.vm.dimensioning_results = roi_df
        self.vm.dimensioning_recommendation = recommendation
        self.vm.dimensioning_top_periods = top_periods
        self.status.setText(
            f"Barrido completado: {len(roi_df)} escenarios. Recomendado C={recommendation.iloc[0]['capacity_kwh']} kWh, "
            f"P={recommendation.iloc[0]['power_kw']} kW"
        )

    def _on_export(self) -> None:
        """Exporta tablas de dimensionamiento y guarda PNG de gráficas clave."""
        if self.vm.dimensioning_results is None or self.vm.dimensioning_recommendation is None:
            self.status.setText("Ejecuta primero el barrido para exportar.")
            return

        output_dir = Path("outputs")
        output_dir.mkdir(parents=True, exist_ok=True)
        fixed_power = float(self.vm.dimensioning_recommendation.iloc[0]["power_kw"])

        p1 = plot_savings_vs_capacity(self.vm.dimensioning_results, fixed_power, str(output_dir / "savings_vs_capacity.png"))
        p2 = plot_savings_heatmap(self.vm.dimensioning_results, str(output_dir / "savings_heatmap.png"))
        p3 = plot_roi_vs_capacity(self.vm.dimensioning_results, fixed_power, str(output_dir / "roi_vs_capacity.png"))

        params_df = pd.DataFrame(
            [
                {"param": "mode", "value": self.mode.currentText()},
                {"param": "sweep_mode", "value": self.sweep_mode.currentText()},
                {"param": "criterion", "value": self.criterion.currentText()},
                {"param": "capex_per_kwh", "value": self.capex_kwh.value()},
                {"param": "capex_per_kw", "value": self.capex_kw.value()},
                {"param": "lifetime_years", "value": int(self.lifetime.value())},
                {"param": "discount_rate", "value": self.discount.value()},
                {"param": "top_n", "value": int(self.top_n.value())},
                {"param": "plot_savings_vs_capacity", "value": p1},
                {"param": "plot_savings_heatmap", "value": p2},
                {"param": "plot_roi_vs_capacity", "value": p3},
            ]
        )
        export_dimensioning_to_excel(
            path=str(output_dir / "dimensioning_report.xlsx"),
            dimensioning_df=self.vm.dimensioning_results,
            recommendation_df=self.vm.dimensioning_recommendation,
            params_df=params_df,
            top_periods=self.vm.dimensioning_top_periods,
        )
        self.status.setText("Exportación completada en carpeta outputs/.")
