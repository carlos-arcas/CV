from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import Property, QEasingCurve, QPropertyAnimation, Qt
from PySide6.QtWidgets import QGridLayout, QLabel, QVBoxLayout, QWidget

from infrastructure.version import __version__
from ui.components.kpi_card import KpiCard
from ui.viewmodels.app_state import AppState


class CounterLabel(QLabel):
    def __init__(self) -> None:
        super().__init__("0 €")
        self._value = 0.0
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("font-size:52px;font-weight:800;color:#15803D;")

    def get_value(self) -> float:
        return self._value

    def set_value(self, value: float) -> None:
        self._value = value
        self.setText(f"{value:,.0f} €")

    value = Property(float, get_value, set_value)


class ResultsPage(QWidget):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state

        self.title = QLabel("Resultados de la simulación")
        self.title.setStyleSheet("font-size:24px;font-weight:700;")
        self.annual_counter = CounterLabel()
        self.badge = QLabel("Solución matemática óptima")
        self.badge.setAlignment(Qt.AlignCenter)
        self.badge.setStyleSheet("padding:8px;background:#DCFCE7;color:#166534;border-radius:8px;font-weight:700;")

        self.kpi_reduction = KpiCard("Reducción factura %")
        self.kpi_autoconsumo = KpiCard("Autoconsumo %")
        self.kpi_mode = KpiCard("Modo solución")

        self.meta = QLabel("Modo solución: - | Versión: - | Hash dataset: - | Fecha: -")
        self.meta.setStyleSheet("color:#334155;")

        self.figure = Figure(figsize=(8, 3), facecolor="#FFFFFF")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.ax = self.figure.add_subplot(111)

        cards = QGridLayout()
        cards.addWidget(self.kpi_reduction, 0, 0)
        cards.addWidget(self.kpi_autoconsumo, 0, 1)
        cards.addWidget(self.kpi_mode, 0, 2)

        root = QVBoxLayout(self)
        root.addWidget(self.title)
        root.addWidget(self.annual_counter)
        root.addWidget(self.badge)
        root.addLayout(cards)
        root.addWidget(self.canvas)
        root.addWidget(self.meta)

    def refresh(self, metadata: dict) -> None:
        results = self.state.simulation_results
        if results is None:
            return

        annual = float(results.kpis.get("total_savings_eur", 0.0))
        base = float(results.kpis.get("total_cost_base_eur", 0.0))
        reduction = (annual / base * 100.0) if base > 0 else 0.0

        series = results.series
        served = float(series["load_served_by_battery_kwh"].sum()) if "load_served_by_battery_kwh" in series.columns else 0.0
        load = float(series["load_kwh"].sum()) if "load_kwh" in series.columns else 0.0
        autoconsumo = (served / load * 100.0) if load > 0 else 0.0

        self._animate_counter(annual)
        self.kpi_reduction.set_value(f"{reduction:.1f}%", trend="vs base", color="#1D4ED8")
        self.kpi_autoconsumo.set_value(f"{autoconsumo:.1f}%", trend="energía local", color="#0F766E")
        self.kpi_mode.set_value(metadata.get("solution_mode", "Optimal LP"), trend="solver", color="#15803D")

        self.meta.setText(
            " | ".join(
                [
                    f"Modo solución: {metadata.get('solution_mode', 'Optimal LP')}",
                    f"Versión app: {__version__}",
                    f"Hash dataset: {metadata.get('dataset_hash', '-')}",
                    f"Fecha simulación: {metadata.get('simulation_date', '-')}",
                ]
            )
        )

        monthly = results.kpis.get("monthly")
        values = [float(v) for v in monthly["savings"].tolist()] if monthly is not None and "savings" in monthly else []
        self.ax.clear()
        self.ax.plot(values, color="#2563EB", linewidth=2.4)
        self.ax.set_title("Ahorro mensual")
        self.ax.grid(alpha=0.2)
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def _animate_counter(self, value: float) -> None:
        animation = QPropertyAnimation(self.annual_counter, b"value", self)
        animation.setDuration(700)
        animation.setStartValue(0.0)
        animation.setEndValue(value)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.start()
        self._animation = animation
