"""Página de resultados con tabla, KPIs y panel financiero."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from application.finance.finance_use_cases import RunFinancialAnalysisUseCase, RunOfferOptimizationUseCase
from ui.viewmodels.app_vm import AppViewModel


class ResultsPage(QWidget):
    """Vista de resultados con KPIs energéticos, financieros y tabla por periodos."""

    def __init__(self, vm: AppViewModel) -> None:
        super().__init__()
        self.vm = vm
        self.kpis_label = QLabel("KPIs: pendientes")
        self.compare_label = QLabel("Comparativa: pendiente")
        self.finance_label = QLabel("Finanzas: pendientes")
        self.offer_status = QLabel("Optimización de oferta: pendiente")
        self.table = QTableWidget(0, 0)
        self.offer_table = QTableWidget(0, 7)
        self._setup_ui()

    def _setup_ui(self) -> None:
        root = QVBoxLayout()
        refresh_btn = QPushButton("Refrescar resultados")
        refresh_btn.clicked.connect(self.refresh)
        root.addWidget(self.kpis_label)
        root.addWidget(self.compare_label)
        root.addWidget(refresh_btn)
        root.addWidget(self.finance_label)
        root.addWidget(self._build_offer_optimization_group())
        root.addWidget(self.offer_status)
        root.addWidget(self.offer_table)
        root.addWidget(self.table)
        self.setLayout(root)

    def _build_offer_optimization_group(self) -> QGroupBox:
        group = QGroupBox("Optimización de Oferta")
        layout = QVBoxLayout()
        row = QHBoxLayout()
        self.strategy_combo = QComboBox()
        self.strategy_combo.addItems(
            [
                "Cuota atractiva para cerrar",
                "Payback cliente <= N años",
                "Maximizar margen",
                "Equilibrada",
            ]
        )
        self.calculate_offer_btn = QPushButton("Calcular oferta")
        self.calculate_offer_btn.clicked.connect(self._on_calculate_offer)
        row.addWidget(QLabel("Estrategia:"))
        row.addWidget(self.strategy_combo)
        row.addWidget(self.calculate_offer_btn)
        layout.addLayout(row)

        form = QFormLayout()
        self.offer_ratio_input = QLineEdit("0.80")
        self.offer_payback_input = QLineEdit("6")
        self.offer_min_savings_eur_input = QLineEdit("10")
        self.offer_min_savings_ratio_input = QLineEdit("0.05")
        self.offer_margin_base_input = QLineEdit("0")
        form.addRow("Límite cuota/ahorro (X)", self.offer_ratio_input)
        form.addRow("Payback objetivo N (años)", self.offer_payback_input)
        form.addRow("Ahorro mínimo cliente €/mes", self.offer_min_savings_eur_input)
        form.addRow("Ahorro mínimo cliente ratio", self.offer_min_savings_ratio_input)
        form.addRow("Margen base (decimal)", self.offer_margin_base_input)
        layout.addLayout(form)
        group.setLayout(layout)

        self.offer_table.setHorizontalHeaderLabels(
            [
                "Estrategia",
                "Cuota recomendada €/mes",
                "Ahorro cliente €/mes",
                "Margen total empresa €",
                "Margen mensual empresa €",
                "Payback equivalente cliente (años)",
                "Parámetros",
            ]
        )
        return group

    def refresh(self) -> None:
        if self.vm.results is None:
            self.kpis_label.setText("KPIs: sin resultados aún.")
            self.compare_label.setText("Comparativa: sin datos.")
            self.finance_label.setText("Finanzas: sin resultados.")
            self.offer_status.setText("Optimización de oferta: sin resultados energéticos.")
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            return

        kpis = self.vm.results.kpis
        monthly = kpis.get("monthly")
        ahorro_mensual = "-"
        if monthly is not None and not getattr(monthly, "empty", True) and "savings" in monthly.columns:
            ahorro_mensual = f"{float(monthly['savings'].mean()):.2f}"

        self.kpis_label.setText(
            " | ".join(
                [
                    f"días={kpis.get('days_simulated', '-')}",
                    f"ahorro_anual={kpis.get('total_savings_eur', '-')}",
                    f"ahorro_mensual_prom={ahorro_mensual}",
                    f"import={kpis.get('total_grid_import_kwh', '-')} kWh",
                    f"export={kpis.get('total_grid_export_kwh', '-')} kWh",
                ]
            )
        )

        if self.vm.compare_metrics:
            c = self.vm.compare_metrics
            self.compare_label.setText(
                (
                    f"ahorro_optimo={c['ahorro_optimo']:.2f} € | ahorro_ml={c['ahorro_ml']:.2f} € | "
                    f"delta={c['delta_eur']:.2f} € ({c['delta_pct']:.2f}%) | "
                    f"t_opt={c['time_opt_s']:.2f}s | t_ml={c['time_ml_s']:.2f}s"
                )
            )
        else:
            self.compare_label.setText("Comparativa: ejecuta 'Comparar' para ver KPIs óptimo vs ML.")

        self._refresh_finance_panel()
        self._refresh_offer_table()

        df = self.vm.results.series.head(200)
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels([str(col) for col in df.columns])
        self.table.setRowCount(len(df))

        values = df.astype(str).to_numpy()
        for row_idx in range(values.shape[0]):
            for col_idx in range(values.shape[1]):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(values[row_idx, col_idx]))

    def _refresh_finance_panel(self) -> None:
        """Calcula y muestra resumen financiero usando ahorro del motor energético."""
        try:
            capacity = self.vm.scenario.battery.capacity_kwh
            power = self.vm.scenario.battery.power_kw
            if self.vm.dimensioning_recommendation is not None and not self.vm.dimensioning_recommendation.empty:
                capacity = float(self.vm.dimensioning_recommendation.iloc[0]["capacity_kwh"])
                power = float(self.vm.dimensioning_recommendation.iloc[0]["power_kw"])

            finance = RunFinancialAnalysisUseCase().execute(
                results=self.vm.results,
                capacity_kwh=capacity,
                power_kw=power,
                capex_params=self.vm.finance_capex,
                opex_params=self.vm.finance_opex,
                financing_params=self.vm.finance_financing,
                rental_params=self.vm.finance_rental,
                discount_rate_annual=self.vm.finance_discount_rate_annual,
                horizon_years=self.vm.finance_horizon_years,
            )
            self.vm.finance_results = {
                "summary": finance,
                "amortization": finance.amortization_schedule,
                "scenarios": finance.scenarios,
            }
            payback = f"{finance.purchase_payback_years:.2f}" if finance.purchase_payback_years is not None else "-"
            roi = f"{finance.purchase_roi_annual:.2%}" if finance.purchase_roi_annual is not None else "-"
            self.finance_label.setText(
                " | ".join(
                    [
                        f"Finanzas inversión={finance.capex_total_eur:.2f} €",
                        f"payback={payback} años",
                        f"ROI={roi}",
                        f"renting cuota={finance.rental_customer_fee_eur:.2f} €/mes",
                        f"margen={finance.rental_total_margin_eur:.2f} €",
                        f"cliente neto={finance.customer_monthly_benefit_eur:.2f} €/mes",
                    ]
                )
            )
        except Exception as exc:
            self.finance_label.setText(f"Finanzas: error de cálculo ({exc})")

    def _on_calculate_offer(self) -> None:
        if self.vm.results is None:
            self.offer_status.setText("Optimización de oferta: ejecuta primero la simulación.")
            return
        try:
            ahorro_mensual = float(self.vm.results.kpis.get("total_savings_eur", 0.0)) / 12.0
            inversion_total = float(self.vm.finance_results["summary"].capex_total_eur) if self.vm.finance_results else 0.0
            plazo = int(self.vm.finance_rental.term_months)
            coste_capital = float(self.vm.finance_rental.annual_cost_of_capital_pct)

            ratio = float(self.offer_ratio_input.text())
            payback_years = float(self.offer_payback_input.text())
            min_savings = float(self.offer_min_savings_eur_input.text())
            min_savings_ratio = float(self.offer_min_savings_ratio_input.text())
            margen_base = float(self.offer_margin_base_input.text())
            selected_strategy = self.strategy_combo.currentText()

            use_case = RunOfferOptimizationUseCase()
            strategies = [
                "Cuota atractiva para cerrar",
                "Payback cliente <= N años",
                "Maximizar margen",
                "Equilibrada",
            ]
            offers = [
                use_case.execute(
                    strategy=name,
                    inversion_total=inversion_total,
                    ahorro_mensual=ahorro_mensual,
                    plazo_meses=plazo,
                    coste_capital_anual=coste_capital,
                    max_fee_ratio=ratio,
                    target_payback_years=payback_years,
                    min_customer_savings_eur=min_savings,
                    min_customer_savings_ratio=min_savings_ratio,
                    margen_base=margen_base,
                )
                for name in strategies
            ]
            selected = next(item for item in offers if item.strategy == selected_strategy)
            self.vm.offer_optimization = {
                "selected_strategy": selected.strategy,
                "inputs": {
                    "max_fee_ratio": ratio,
                    "target_payback_years": payback_years,
                    "min_customer_savings_eur": min_savings,
                    "min_customer_savings_ratio": min_savings_ratio,
                    "margen_base": margen_base,
                    "plazo_meses": plazo,
                    "coste_capital_anual": coste_capital,
                    "inversion_total": inversion_total,
                    "ahorro_mensual": ahorro_mensual,
                },
                "results": offers,
            }
            self.offer_status.setText(
                f"Oferta recomendada ({selected.strategy}): {selected.cuota_recomendada:.2f} €/mes | "
                f"cliente={selected.ahorro_cliente_mensual:.2f} €/mes"
            )
            self._refresh_offer_table()
        except Exception as exc:
            self.offer_status.setText(f"Optimización de oferta: error ({exc})")

    def _refresh_offer_table(self) -> None:
        offers = []
        if self.vm.offer_optimization:
            offers = self.vm.offer_optimization.get("results", [])
        self.offer_table.setRowCount(len(offers))
        for row, offer in enumerate(offers):
            payback_text = "-" if offer.payback_equivalente_cliente is None else f"{offer.payback_equivalente_cliente:.2f}"
            params = ", ".join(f"{k}={v}" for k, v in offer.parameters.items())
            cells = [
                offer.strategy,
                f"{offer.cuota_recomendada:.2f}",
                f"{offer.ahorro_cliente_mensual:.2f}",
                f"{offer.margen_total_empresa:.2f}",
                f"{offer.margen_mensual_empresa:.2f}",
                payback_text,
                params,
            ]
            for col, value in enumerate(cells):
                self.offer_table.setItem(row, col, QTableWidgetItem(value))
