from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFileDialog, QLabel, QVBoxLayout, QWidget

from application.use_cases import LoadDatasetUseCase, ValidateAndNormalizeUseCase
from ui.components.kpi_card import KpiCard
from ui.error_boundary import show_error
from ui.components.modern_button import PrimaryButton
from ui.viewmodels.app_state import AppState


class DataPage(QWidget):
    validated = Signal(bool)

    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self.loader = LoadDatasetUseCase()
        self.validator = ValidateAndNormalizeUseCase()

        self.btn_select = PrimaryButton("Seleccionar archivo Excel")
        self.btn_select.setMinimumHeight(52)
        self.btn_select.clicked.connect(self._select_file)

        self.file_label = QLabel("Ningún archivo seleccionado")
        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color:#B00020;")
        self.year_card = KpiCard("Año detectado")
        self.rows_card = KpiCard("Nº registros")
        self.pv_card = KpiCard("FV detectada")

        layout = QVBoxLayout(self)
        layout.addWidget(self.btn_select)
        layout.addWidget(self.file_label)
        layout.addWidget(self.year_card)
        layout.addWidget(self.rows_card)
        layout.addWidget(self.pv_card)
        layout.addWidget(self.error_label)

    def _select_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar archivo", "", "Excel/CSV (*.xlsx *.xls *.csv)")
        if not path:
            return
        self.file_label.setText(path)
        self.error_label.setText("")

        try:
            loaded = self.loader.execute(path)
            normalized = self.validator.execute(loaded)
            self.state.input_data = normalized
            meta = self.state.dataset_status()
            self.year_card.set_value(str(meta.get("year", "-")), trend="↑ Detectado", color="#1E3A8A")
            self.rows_card.set_value(str(meta.get("rows", "0")), trend="↑ Calidad", color="#16A34A")
            self.pv_card.set_value(str(meta.get("pv", "No")), trend="✓ Sistema", color="#1E3A8A")
            self.validated.emit(True)
        except Exception as exc:
            self.validated.emit(False)
            self.error_label.setText("No se pudo validar el archivo. Revise formato y columnas requeridas.")
            show_error(self, exc)
