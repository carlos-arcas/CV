from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QListWidget, QListWidgetItem, QMainWindow, QStackedWidget, QVBoxLayout, QWidget, QHBoxLayout

from infrastructure.version import __version__
from ui.pages.page_config import ConfigPage
from ui.pages.page_load_data import LoadDataPage
from ui.pages.page_presentation import PresentationPage
from ui.pages.page_results import ResultsPage
from ui.pages.page_simulation import SimulationPage
from ui.viewmodels.app_state import AppState


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"FV+BESS Commercial v{__version__}")
        self.resize(1280, 820)

        self.state = AppState()
        self.results_metadata: dict = {}
        self.presentation_window: PresentationPage | None = None
        self.completed = {0: False, 1: True, 2: False, 3: False, 4: False}

        self.stack = QStackedWidget()
        self.page_load = LoadDataPage(self.state)
        self.page_config = ConfigPage(self.state)
        self.page_sim = SimulationPage(self.state)
        self.page_results = ResultsPage(self.state)
        self.page_presentation = QWidget()

        for page in (self.page_load, self.page_config, self.page_sim, self.page_results, self.page_presentation):
            self.stack.addWidget(page)

        self.nav = QListWidget()
        self.nav.addItems([
            "1. Cargar datos",
            "2. Configurar batería",
            "3. Ejecutar simulación",
            "4. Resultados",
            "5. Modo presentación",
        ])

        holder = QWidget()
        root = QHBoxLayout(holder)
        left = QVBoxLayout()
        left.addWidget(QLabel("Flujo comercial"))
        left.addWidget(self.nav)
        root.addLayout(left, 1)
        root.addWidget(self.stack, 4)
        self.setCentralWidget(holder)

        self.page_load.validated.connect(self._on_data_validated)
        self.page_config.validated.connect(self._on_config_validated)
        self.page_sim.simulated.connect(self._on_simulated)
        self.nav.currentRowChanged.connect(self._navigate)

        self.nav.setCurrentRow(0)
        self._lock_navigation()

    def _lock_navigation(self) -> None:
        allow_until = 0
        while allow_until < 4 and self.completed.get(allow_until, False):
            allow_until += 1
        for i in range(self.nav.count()):
            item: QListWidgetItem = self.nav.item(i)
            item.setFlags(item.flags() | Qt.ItemIsEnabled if i <= allow_until else item.flags() & ~Qt.ItemIsEnabled)

    def _navigate(self, index: int) -> None:
        if index < 0:
            return
        if index == 4:
            if self.state.simulation_results is None:
                return
            self.presentation_window = PresentationPage(self.state, self.results_metadata)
            self.presentation_window.showFullScreen()
            self.nav.setCurrentRow(3)
            return
        self.stack.setCurrentIndex(index)

    def _on_data_validated(self, ok: bool) -> None:
        self.completed[0] = ok
        self.completed[2] = False
        self.completed[3] = False
        self.completed[4] = False
        self._lock_navigation()

    def _on_config_validated(self, ok: bool) -> None:
        self.completed[1] = ok
        self._lock_navigation()

    def _on_simulated(self, ok: bool, metadata: dict) -> None:
        self.completed[2] = ok
        self.completed[3] = ok
        self.completed[4] = ok
        self.results_metadata = metadata
        if ok:
            self.page_results.refresh(metadata)
            self.nav.setCurrentRow(3)
        self._lock_navigation()
