from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PySide6.QtGui import QFont


@dataclass(frozen=True)
class Palette:
    primary: str = "#1E3A8A"
    secondary: str = "#16A34A"
    neutral: str = "#F3F4F6"
    text: str = "#111827"
    card: str = "#FFFFFF"
    border: str = "#D1D5DB"


PALETTE = Palette()


def app_font() -> QFont:
    font = QFont("Segoe UI", 11)
    font.setStyleStrategy(QFont.PreferAntialias)
    return font


def load_stylesheet() -> str:
    qss_path = Path(__file__).with_name("styles.qss")
    return qss_path.read_text(encoding="utf-8") if qss_path.exists() else ""
