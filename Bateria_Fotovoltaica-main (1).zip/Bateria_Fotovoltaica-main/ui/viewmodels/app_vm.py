"""ViewModel central para estado compartido de la aplicación."""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from application.dto import InputDataDTO, InputDatasetCollectionDTO, ResultsBundleDTO
from domain.finance_models import CapexParams, FinancingParams, OpexParams, RentalParams
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


@dataclass(slots=True)
class AppViewModel:
    """Estado compartido entre páginas de la UI."""

    app_version: str = "1.0.0"
    project_name: str = "proyecto_bess"
    project_path: str = ""
    input_data: InputDataDTO | None = None
    input_collection: InputDatasetCollectionDTO = field(default_factory=InputDatasetCollectionDTO)
    scenario: ScenarioConfig = field(
        default_factory=lambda: ScenarioConfig(
            battery=BatteryParams(),
            tariff=TariffParams(),
            grid=GridParams(),
        )
    )
    results: ResultsBundleDTO | None = None
    results_optimal: ResultsBundleDTO | None = None
    results_ml: ResultsBundleDTO | None = None
    compare_metrics: dict | None = None
    ml_enabled: bool = False
    ml_model_path: str = "models/default_model"
    ml_model_info: dict = field(default_factory=dict)
    ml_dataset_path: str = "imitation_dataset.csv"
    ml_dataset_df: pd.DataFrame | None = None
    export_folder: str = "outputs"
    finance_capex: CapexParams = field(default_factory=CapexParams)
    finance_opex: OpexParams = field(default_factory=OpexParams)
    finance_financing: FinancingParams = field(default_factory=FinancingParams)
    finance_rental: RentalParams = field(default_factory=RentalParams)
    finance_discount_rate_annual: float = 0.08
    finance_horizon_years: int = 10
    finance_results: dict | None = None
    offer_optimization: dict | None = None
    dimensioning_results: pd.DataFrame | None = None
    dimensioning_recommendation: pd.DataFrame | None = None
    dimensioning_top_periods: dict[str, pd.DataFrame] = field(default_factory=dict)

    def update_battery(self, battery: BatteryParams, allow_sell: bool) -> None:
        """Actualiza parámetros de batería y bandera de venta del escenario."""
        tariff = TariffParams(
            default_buy_eur_kwh=self.scenario.tariff.default_buy_eur_kwh,
            default_sell_eur_kwh=self.scenario.tariff.default_sell_eur_kwh,
            allow_sell=allow_sell,
        )
        self.scenario = ScenarioConfig(
            battery=battery,
            tariff=tariff,
            grid=self.scenario.grid,
            timestep_minutes=15,
        )

    def reset_project_state(self) -> None:
        """Reinicia estado de proyecto manteniendo parámetros base de aplicación."""
        self.project_name = "proyecto_bess"
        self.project_path = ""
        self.input_data = None
        self.input_collection = InputDatasetCollectionDTO()
        self.results = None
        self.results_optimal = None
        self.results_ml = None
        self.compare_metrics = None
        self.ml_model_path = "models/default_model"
        self.ml_model_info = {}
        self.ml_dataset_df = None
        self.dimensioning_results = None
        self.dimensioning_recommendation = None
        self.dimensioning_top_periods = {}
        self.finance_capex = CapexParams()
        self.finance_opex = OpexParams()
        self.finance_financing = FinancingParams()
        self.finance_rental = RentalParams()
        self.finance_discount_rate_annual = 0.08
        self.finance_horizon_years = 10
        self.finance_results = None
        self.offer_optimization = None
        self.scenario = ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(), grid=GridParams())
