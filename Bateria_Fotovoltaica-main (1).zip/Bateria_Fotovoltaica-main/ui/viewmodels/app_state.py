"""Estado de UI para modo comercial (sin lógica de negocio)."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from application.dto import InputDataDTO, ResultsBundleDTO
from domain.finance_models import CapexParams, FinancingParams, OpexParams, RentalParams
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


@dataclass(slots=True)
class AppState:
    """Estado compartido entre páginas del asistente comercial."""

    input_data: InputDataDTO | None = None
    scenario: ScenarioConfig = field(
        default_factory=lambda: ScenarioConfig(
            battery=BatteryParams(),
            tariff=TariffParams(),
            grid=GridParams(),
        )
    )
    simulation_results: ResultsBundleDTO | None = None
    financial_results: Any | None = None

    battery_cost_eur_kwh: float = 350.0
    offer_term_months: int = 60
    desired_margin_pct: float = 15.0
    debug_mode: bool = False
    export_detail: bool = False
    fast_mode: bool = False
    use_cache: bool = True

    def dataset_status(self) -> dict[str, str]:
        """Devuelve metadatos amigables para la página de carga."""
        if self.input_data is None:
            return {"year": "-", "rows": "0", "pv": "No"}

        frame = self.input_data.dataframe
        years = "-"
        if "timestamp" in frame.columns and not frame.empty:
            years = str(int(frame["timestamp"].dt.year.mode().iloc[0]))

        pv_detected = "Sí" if "pv_kwh" in frame.columns and (frame["pv_kwh"] > 0).any() else "No"
        return {"year": years, "rows": f"{len(frame)}", "pv": pv_detected, "file": Path(self.input_data.source_path).name}

    def reset_results(self) -> None:
        self.simulation_results = None
        self.financial_results = None
