from __future__ import annotations

from dataclasses import dataclass

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import QEasingCurve, Property, QPropertyAnimation, Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget

from application.dto import ResultsBundleDTO
from domain.finance_models import FinancialResults
from ui.animations import fade_in
from ui.components.presentation_kpi import PresentationKpi


@dataclass(slots=True)
class RecommendationResult:
    capacity_kwh: float
    power_kw: float
    payback_years: float | None = None
    monthly_fee_eur: float | None = None


class CounterLabel(QLabel):
    def __init__(self) -> None:
        super().__init__("0 €")
        self._value = 0.0
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("font-size:72px;font-weight:900;color:#15803D;")

    def get_value(self) -> float:
        return self._value

    def set_value(self, value: float) -> None:
        self._value = value
        self.setText(f"{value:,.0f} €")

    value = Property(float, get_value, set_value)


class PresentationChart(QWidget):
    def __init__(self, title: str) -> None:
        super().__init__()
        self.figure = Figure(figsize=(7, 3), facecolor="#FFFFFF")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.ax = self.figure.add_subplot(111)

        heading = QLabel(title)
        heading.setStyleSheet("font-size:22px;font-weight:700;color:#0f172a;")
        root = QVBoxLayout(self)
        root.setSpacing(10)
        root.addWidget(heading)
        root.addWidget(self.canvas)

        self.setStyleSheet("background:#FFFFFF;border:1px solid #E2E8F0;border-radius:18px;padding:10px;")

    def plot_line(self, values: list[float], color: str) -> None:
        self.ax.clear()
        self.ax.plot(values, color=color, linewidth=3)
        self.ax.grid(False)
        self.ax.set_facecolor("#FFFFFF")
        self.ax.spines["top"].set_visible(False)
        self.ax.spines["right"].set_visible(False)
        self.ax.tick_params(labelsize=11, colors="#475569")
        self.figure.tight_layout()
        self.canvas.draw_idle()


class PresentationWindow(QMainWindow):
    """Dashboard ejecutivo sin edición para presentar resultados al cliente."""

    def __init__(
        self,
        results: ResultsBundleDTO,
        financial_results: FinancialResults | None,
        recommendation: RecommendationResult,
    ) -> None:
        super().__init__()
        self._results = results
        self._financial = financial_results
        self._recommendation = recommendation

        self.setWindowTitle("Modo Presentación Cliente")
        self._annual_counter = CounterLabel()
        self._chart_month = PresentationChart("Ahorro mensual")
        self._chart_cash = PresentationChart("Cashflow acumulado")

        self._kpi_monthly = PresentationKpi("Ahorro mensual medio")
        self._kpi_reduction = PresentationKpi("Reducción factura %")
        self._kpi_autoconsumo = PresentationKpi("Autoconsumo %")

        self._build_ui()
        self._load_data()

    def _build_ui(self) -> None:
        container = QWidget()
        self.setCentralWidget(container)
        root = QVBoxLayout(container)
        root.setContentsMargins(48, 32, 48, 30)
        root.setSpacing(24)

        top = QHBoxLayout()
        top.addStretch()
        self.btn_back = QPushButton("Volver")
        self.btn_back.setStyleSheet("padding:8px 14px;border-radius:10px;border:1px solid #CBD5E1;background:#FFFFFF;")
        self.btn_back.clicked.connect(self.close)
        top.addWidget(self.btn_back)

        title = QLabel("Propuesta de Ahorro Energético")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:50px;font-weight:900;color:#0f172a;")

        self.subtitle = QLabel("Año analizado: -")
        self.subtitle.setAlignment(Qt.AlignCenter)
        self.subtitle.setStyleSheet("font-size:24px;color:#475569;")

        cards = QGridLayout()
        cards.setHorizontalSpacing(16)
        cards.addWidget(self._kpi_monthly, 0, 0)
        cards.addWidget(self._kpi_reduction, 0, 1)
        cards.addWidget(self._kpi_autoconsumo, 0, 2)

        battery_title = QLabel("Batería Recomendada")
        battery_title.setStyleSheet("font-size:26px;font-weight:800;color:#0f172a;")
        self.battery_data = QLabel("-")
        self.battery_data.setStyleSheet("font-size:21px;color:#1E293B;line-height:1.5;")

        battery_card = QWidget()
        battery_lay = QVBoxLayout(battery_card)
        battery_lay.setContentsMargins(24, 20, 24, 20)
        battery_lay.addWidget(battery_title)
        battery_lay.addWidget(self.battery_data)
        battery_card.setStyleSheet("background:#F8FAFC;border:1px solid #E2E8F0;border-radius:18px;")

        charts = QGridLayout()
        charts.setHorizontalSpacing(20)
        charts.addWidget(self._chart_month, 0, 0)
        charts.addWidget(self._chart_cash, 0, 1)

        self.footer = QLabel("Simulación basada en datos reales y optimización energética.")
        self.footer.setAlignment(Qt.AlignCenter)
        self.footer.setStyleSheet("font-size:15px;color:#64748B;")

        root.addLayout(top)
        root.addWidget(title)
        root.addWidget(self.subtitle)
        root.addWidget(self._annual_counter)
        root.addLayout(cards)
        root.addLayout(charts)
        root.addWidget(battery_card)
        root.addWidget(self.footer)

        container.setStyleSheet("background:#F8FAFC;")

    def _load_data(self) -> None:
        kpis = self._results.kpis
        annual = float(kpis.get("total_savings_eur", 0.0))
        monthly = annual / 12.0
        base = float(kpis.get("total_cost_base_eur", 0.0))
        reduction = (annual / base * 100.0) if base > 0 else 0.0

        series = self._results.series
        covered = float(series.get("load_served_by_battery_kwh", 0).sum()) if "load_served_by_battery_kwh" in series.columns else 0.0
        total_load = float(series.get("load_kwh", 0).sum()) if "load_kwh" in series.columns else 0.0
        autoconsumo = (covered / total_load * 100.0) if total_load > 0 else 0.0

        monthly_data = kpis.get("monthly")
        month_values = [float(v) for v in monthly_data["savings"].tolist()] if monthly_data is not None and "savings" in monthly_data else []

        cashflow: list[float] = []
        acc = 0.0
        for value in month_values:
            acc += value
            cashflow.append(acc)

        year_text = "-"
        if "timestamp" in series.columns and not series.empty:
            year_text = str(int(series["timestamp"].dt.year.mode().iloc[0]))

        self.subtitle.setText(f"Año analizado: {year_text}")
        self._kpi_monthly.set_value(f"{monthly:,.0f} €")
        self._kpi_reduction.set_value(f"{reduction:.1f}%")
        self._kpi_autoconsumo.set_value(f"{autoconsumo:.1f}%")

        payback_text = f"{self._recommendation.payback_years:.1f} años" if self._recommendation.payback_years is not None else "-"
        fee_text = f"{self._recommendation.monthly_fee_eur:.2f} €/mes" if self._recommendation.monthly_fee_eur is not None else "-"
        self.battery_data.setText(
            "\n".join(
                [
                    f"Capacidad: {self._recommendation.capacity_kwh:.1f} kWh",
                    f"Potencia: {self._recommendation.power_kw:.1f} kW",
                    f"Payback estimado: {payback_text}",
                    f"Cuota mensual: {fee_text}",
                ]
            )
        )

        self._chart_month.plot_line(month_values, "#16A34A")
        if self._financial is not None:
            financial_cash = [float(v) for v in self._financial.monthly_savings_eur]
            if financial_cash:
                acc_fin = 0.0
                cumulative = []
                for val in financial_cash:
                    acc_fin += val
                    cumulative.append(acc_fin)
                self._chart_cash.plot_line(cumulative, "#0EA5E9")
            else:
                self._chart_cash.plot_line(cashflow, "#0EA5E9")
        else:
            self._chart_cash.plot_line(cashflow, "#0EA5E9")

        self._animate_counter(annual)
        for widget in (self._annual_counter, self._kpi_monthly, self._kpi_reduction, self._kpi_autoconsumo):
            fade_in(widget)

    def _animate_counter(self, value: float) -> None:
        animation = QPropertyAnimation(self._annual_counter, b"value", self)
        animation.setDuration(750)
        animation.setStartValue(0.0)
        animation.setEndValue(value)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.start()
        self._animation = animation

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        if event.key() == Qt.Key_Escape:
            self.close()
            return
        super().keyPressEvent(event)
