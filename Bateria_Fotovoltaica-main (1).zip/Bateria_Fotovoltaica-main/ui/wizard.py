from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QPushButton, QStackedWidget, QVBoxLayout, QWidget

from ui.pages.page_config import ConfigPage
from ui.pages.page_data import DataPage
from ui.pages.page_offer import OfferPage
from ui.pages.page_results import ResultsPage
from ui.pages.page_simulation import SimulationPage
from ui.viewmodels.app_state import AppState


class CommercialWizard(QWidget):
    """Asistente guiado de 5 pasos para usuarios comerciales."""

    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state

        self.stack = QStackedWidget()
        self.page_data = DataPage(state)
        self.page_config = ConfigPage(state)
        self.page_simulation = SimulationPage(state)
        self.page_results = ResultsPage(state)
        self.page_offer = OfferPage(state)

        for page in (self.page_data, self.page_config, self.page_simulation, self.page_results, self.page_offer):
            self.stack.addWidget(page)

        self.btn_prev = QPushButton("← Anterior")
        self.btn_next = QPushButton("Continuar →")
        self.btn_next.setEnabled(False)

        nav = QHBoxLayout()
        nav.addWidget(self.btn_prev)
        nav.addWidget(self.btn_next)

        root = QVBoxLayout(self)
        root.addWidget(self.stack)
        root.addLayout(nav)

        self.btn_prev.clicked.connect(self._prev)
        self.btn_next.clicked.connect(self._next)

        self.page_data.validated.connect(self.btn_next.setEnabled)
        self.page_config.validated.connect(self.btn_next.setEnabled)
        self.page_simulation.simulated.connect(self._on_simulated)

        self._sync_buttons()

    def _on_simulated(self, ok: bool) -> None:
        self.btn_next.setEnabled(ok)
        if ok:
            self.page_results.refresh()

    def _prev(self) -> None:
        idx = max(0, self.stack.currentIndex() - 1)
        self.stack.setCurrentIndex(idx)
        self._sync_buttons()

    def _next(self) -> None:
        idx = min(self.stack.count() - 1, self.stack.currentIndex() + 1)
        self.stack.setCurrentIndex(idx)
        if idx == 3:
            self.page_results.refresh()
        self._sync_buttons()

    def _sync_buttons(self) -> None:
        idx = self.stack.currentIndex()
        self.btn_prev.setEnabled(idx > 0)
        if idx in (2, 3, 4):
            self.btn_next.setEnabled(idx != 4)
