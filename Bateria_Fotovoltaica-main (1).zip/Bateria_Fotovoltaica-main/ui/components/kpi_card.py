from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QFrame, QGraphicsDropShadowEffect, QLabel, QVBoxLayout


class KpiCard(QFrame):
    def __init__(self, title: str, value: str = "-", subtitle: str = "", trend: str = "") -> None:
        super().__init__()
        self.setStyleSheet("QFrame{background:#FFFFFF;border-radius:14px;border:1px solid #E5E7EB;}")
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 3)
        shadow.setColor(QColor(17, 24, 39, 45))
        self.setGraphicsEffect(shadow)

        self.title = QLabel(title)
        self.title.setStyleSheet("font-size:12px;color:#6B7280;font-weight:600;")
        self.value = QLabel(value)
        self.value.setAlignment(Qt.AlignCenter)
        self.value.setStyleSheet("font-size:30px;font-weight:700;color:#1E3A8A;")
        self.subtitle = QLabel(subtitle)
        self.subtitle.setAlignment(Qt.AlignCenter)
        self.subtitle.setStyleSheet("font-size:12px;color:#6B7280;")
        self.trend = QLabel(trend)
        self.trend.setAlignment(Qt.AlignCenter)

        layout = QVBoxLayout(self)
        layout.addWidget(self.title)
        layout.addWidget(self.value)
        layout.addWidget(self.subtitle)
        layout.addWidget(self.trend)

    def set_value(self, value: str, trend: str = "", color: str = "#1E3A8A") -> None:
        self.value.setText(value)
        self.value.setStyleSheet(f"font-size:30px;font-weight:700;color:{color};")
        self.trend.setText(trend)
        self.trend.setStyleSheet(f"font-size:12px;font-weight:600;color:{color};")
