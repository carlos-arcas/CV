from __future__ import annotations

from PySide6.QtCore import Property, QEasingCurve, QPropertyAnimation, Qt, Signal
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget


class _Switch(QWidget):
    toggled = Signal(bool)

    def __init__(self) -> None:
        super().__init__()
        self.setFixedSize(46, 24)
        self._checked = False
        self._offset = 3.0
        self._anim = QPropertyAnimation(self, b"offset", self)
        self._anim.setDuration(220)
        self._anim.setEasingCurve(QEasingCurve.InOutCubic)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        self.setChecked(not self._checked)
        super().mousePressEvent(event)

    def setChecked(self, checked: bool) -> None:
        self._checked = checked
        self._anim.stop()
        self._anim.setStartValue(self._offset)
        self._anim.setEndValue(25.0 if checked else 3.0)
        self._anim.start()
        self.toggled.emit(checked)
        self.update()

    def isChecked(self) -> bool:
        return self._checked

    def get_offset(self) -> float:
        return self._offset

    def set_offset(self, value: float) -> None:
        self._offset = value
        self.update()

    offset = Property(float, get_offset, set_offset)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#16A34A") if self._checked else QColor("#9CA3AF"))
        painter.drawRoundedRect(0, 0, 46, 24, 12, 12)
        painter.setBrush(QColor("white"))
        painter.drawEllipse(int(self._offset), 3, 18, 18)


class ToggleSwitch(QWidget):
    toggled = Signal(bool)

    def __init__(self, text: str) -> None:
        super().__init__()
        self._switch = _Switch()
        self._label = QLabel(text)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._label)
        lay.addStretch()
        lay.addWidget(self._switch)
        self._switch.toggled.connect(self.toggled.emit)

    def isChecked(self) -> bool:
        return self._switch.isChecked()

    def setChecked(self, checked: bool) -> None:
        self._switch.setChecked(checked)
