from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QVariantAnimation
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QPushButton


class PrimaryButton(QPushButton):
    def __init__(self, text: str) -> None:
        super().__init__(text)
        self._base = QColor("#1E3A8A")
        self._hover = QColor("#2647A8")
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(220)
        self._anim.setEasingCurve(QEasingCurve.InOutCubic)
        self._anim.valueChanged.connect(self._apply_color)
        self._apply_color(self._base)

    def _apply_color(self, value: QColor) -> None:
        self.setStyleSheet(
            f"QPushButton{{background:{value.name()};color:white;border:none;border-radius:12px;padding:10px 16px;font-weight:600;}}"
        )

    def enterEvent(self, event) -> None:  # noqa: N802
        self._anim.stop()
        self._anim.setStartValue(self._base)
        self._anim.setEndValue(self._hover)
        self._anim.start()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._anim.stop()
        self._anim.setStartValue(self._hover)
        self._anim.setEndValue(self._base)
        self._anim.start()
        super().leaveEvent(event)
