from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit, QWidget


class NumericInput(QWidget):
    valueChanged = Signal(float)

    def __init__(self, minimum: float, maximum: float, step: float, suffix: str = "", tooltip: str = "") -> None:
        super().__init__()
        self._min = minimum
        self._max = maximum
        self._suffix = suffix
        self._special_text = ""
        self._line = QLineEdit()
        self._line.setValidator(QDoubleValidator(minimum, maximum, 3, self))
        self._line.setPlaceholderText(f"{minimum} - {maximum}{suffix}")
        if tooltip:
            self._line.setToolTip(tooltip)
        self._suffix_label = QLabel(suffix)
        self._suffix_label.setStyleSheet("color:#6B7280;")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._line)
        if suffix:
            layout.addWidget(self._suffix_label)
        self._line.textChanged.connect(self._on_text_changed)

    def _on_text_changed(self) -> None:
        text = self._line.text().strip().replace(",", ".")
        try:
            value = float(text)
            valid = self._min <= value <= self._max
        except ValueError:
            valid = False
            value = self._min
        self._line.setStyleSheet(
            "QLineEdit{background:#fff;border:2px solid #16A34A;border-radius:10px;padding:8px;}" if valid else
            "QLineEdit{background:#fff;border:2px solid #DC2626;border-radius:10px;padding:8px;}"
        )
        if valid:
            self.valueChanged.emit(value)

    def value(self) -> float:
        text = self._line.text().strip().replace(",", ".")
        if text == "" and self._special_text:
            return self._min
        try:
            return float(text)
        except ValueError:
            return self._min

    def setValue(self, value: float) -> None:  # noqa: N802
        self._line.setText(f"{value:.2f}".rstrip("0").rstrip("."))

    def setSpecialValueText(self, text: str) -> None:  # noqa: N802
        self._special_text = text
        if text:
            self._line.setPlaceholderText(text)
