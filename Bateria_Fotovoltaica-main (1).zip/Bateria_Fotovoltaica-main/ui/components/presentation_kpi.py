from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget


class PresentationKpi(QWidget):
    """KPI compacto para modo presentación con tipografía grande."""

    def __init__(self, title: str, value: str = "-") -> None:
        super().__init__()
        self.title = QLabel(title)
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size:20px;font-weight:600;color:#475569;")

        self.value = QLabel(value)
        self.value.setAlignment(Qt.AlignCenter)
        self.value.setStyleSheet("font-size:34px;font-weight:800;color:#0f172a;")

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(8)
        root.addWidget(self.title)
        root.addWidget(self.value)

        self.setStyleSheet("background:#F8FAFC;border:1px solid #E2E8F0;border-radius:16px;")

    def set_value(self, text: str) -> None:
        self.value.setText(text)
