"""Entrypoint de UI PySide6 en modo comercial guiado."""

from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from infrastructure.settings import build_settings
from infrastructure.logging.crash_handler import install_global_crash_handler
from infrastructure.logging.logging_config import configure_logging
from ui.main_window import MainWindow


def run_ui(*, debug: bool = False, export_detail: bool = False, no_cache: bool = False) -> int:
    settings = build_settings(debug=debug, export_detail=export_detail, no_cache=no_cache)
    ui_logs_dir = settings.logs_dir / "ui"
    _, crash_log = configure_logging(ui_logs_dir, debug=debug)
    install_global_crash_handler(crash_log)
    app = QApplication(sys.argv)
    window = MainWindow()
    window.state.debug_mode = debug
    window.state.export_detail = export_detail
    window.state.use_cache = not no_cache
    window.show()
    return app.exec()
