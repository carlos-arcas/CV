"""Manejo centralizado de errores de dominio para la UI."""

from __future__ import annotations

from PySide6.QtWidgets import QDialog, QMessageBox, QPushButton, QTextEdit, QVBoxLayout, QWidget

from application.errors import DatasetValidationError
from domain.errors import DomainError, ExportError, SimulationError, ValidationError


def _title_for(exc: Exception) -> str:
    if isinstance(exc, (ValidationError, DatasetValidationError)):
        return "Datos inválidos"
    if isinstance(exc, SimulationError):
        return "Fallo en simulación"
    if isinstance(exc, ExportError):
        return "Error exportando"
    return "Error de aplicación"


def show_error(parent: QWidget, exc: Exception, *, log_path: str = "logs/app.log") -> None:
    """Muestra mensaje humano y permite abrir detalle técnico bajo demanda."""
    title = _title_for(exc)
    msg = QMessageBox(parent)
    msg.setIcon(QMessageBox.Warning)
    msg.setWindowTitle(title)
    msg.setText(str(exc) if isinstance(exc, (DomainError, DatasetValidationError)) else "Ocurrió un error no esperado.")
    detail_button = QPushButton("Ver detalle técnico")
    msg.addButton(detail_button, QMessageBox.ActionRole)
    msg.addButton(QMessageBox.Ok)

    def _open_detail() -> None:
        dlg = QDialog(parent)
        dlg.setWindowTitle("Detalle técnico")
        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(f"{type(exc).__name__}: {exc}\n\nConsulte logs en: {log_path}")
        lay = QVBoxLayout(dlg)
        lay.addWidget(txt)
        dlg.resize(680, 420)
        dlg.exec()

    detail_button.clicked.connect(_open_detail)
    msg.exec()
