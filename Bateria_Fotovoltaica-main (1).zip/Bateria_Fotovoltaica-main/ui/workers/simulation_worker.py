from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QObject, Signal

from application.engine import SimulationEngine
from domain.models import SimulationMode
from application.use_cases import RunSimulationUseCase
from infrastructure.io.cache_store import CacheStore
from ui.viewmodels.app_state import AppState


class SimulationWorker(QObject):
    """Worker en segundo plano para ejecutar simulación sin bloquear la UI."""

    progress = Signal(int, int, str)
    finished = Signal(object, dict)
    failed = Signal(str)

    def __init__(self, state: AppState, *, cache_store: CacheStore | None = None) -> None:
        super().__init__()
        self.state = state
        self.cache_store = cache_store
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        if self.state.input_data is None:
            self.failed.emit("Debe cargar un dataset válido antes de simular.")
            return
        try:
            def on_progress(current: int, total: int, message: str) -> None:
                if self._cancelled:
                    raise RuntimeError("Simulación cancelada por el usuario.")
                self.progress.emit(current, total, message)

            use_case = RunSimulationUseCase(engine=SimulationEngine(progress_callback=on_progress))
            results = use_case.execute(
                self.state.input_data,
                self.state.scenario,
                include_detail=self.state.export_detail,
                use_cache=self.state.use_cache,
                cache_store=self.cache_store,
                debug_mode=self.state.debug_mode,
                mode=SimulationMode.FAST if self.state.fast_mode else SimulationMode.OPTIMAL,
            )

            metadata = {
                "solution_mode": "Optimal LP",
                "dataset_hash": self.state.input_data.dataset_hash or "-",
                "simulation_date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
            self.finished.emit(results, metadata)
        except Exception:
            if self._cancelled:
                self.failed.emit("Simulación cancelada.")
                return
            self.failed.emit("No se pudo completar la simulación. Revise la configuración y vuelva a intentar.")
