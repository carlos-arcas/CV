"""Widget lateral de navegación principal."""

from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QListWidget, QListWidgetItem, QVBoxLayout, QWidget


class Sidebar(QWidget):
    """Barra lateral para seleccionar páginas de la aplicación.

    Entradas:
        pages: Lista opcional de nombres de página.

    Salidas:
        Widget con señal `page_selected` para navegar.

    Errores relevantes:
        No aplica; comportamiento de UI estándar.
    """

    page_selected = Signal(int)

    def __init__(self, pages: list[str] | None = None) -> None:
        """Inicializa la barra lateral y configura ítems de navegación."""
        super().__init__()
        self._list = QListWidget()
        self._setup_ui(pages or ["Datos", "Escenario", "Simulación", "Resultados", "Dimensionamiento"])

    def _setup_ui(self, pages: list[str]) -> None:
        """Construye el layout y registra eventos de selección."""
        layout = QVBoxLayout()
        for page_name in pages:
            QListWidgetItem(page_name, self._list)
        self._list.currentRowChanged.connect(self.page_selected.emit)
        self._list.setCurrentRow(0)
        layout.addWidget(self._list)
        self.setLayout(layout)
