"""Utilidades de exportación de aplicación."""

from .executive_report import build_executive_summary

__all__ = ["build_executive_summary"]
