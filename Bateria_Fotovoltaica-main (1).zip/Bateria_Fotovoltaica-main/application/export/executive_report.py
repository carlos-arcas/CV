"""Construcción de resúmenes ejecutivos para exportes comerciales."""

from __future__ import annotations

from typing import Any


def _pick_number(source: dict[str, Any], *keys: str) -> float | None:
    for key in keys:
        value = source.get(key)
        if isinstance(value, (int, float)):
            return float(value)
    return None


def _round_for_metric(label: str, value: float | None) -> float | None:
    if value is None:
        return None
    lowered = label.lower()
    if "€" in label or "%" in label or "ahorro" in lowered or "van" in lowered or "tir" in lowered or "roi" in lowered:
        return round(value, 2)
    return round(value, 3)


def _format_section_rows(section: str, metrics: list[tuple[str, float | int | str | None]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for metric, value in metrics:
        clean_value: object = value
        if isinstance(value, float):
            clean_value = _round_for_metric(metric, value)
        rows.append({"section": section, "metric": metric, "value": clean_value})
    return rows


def _build_comparison(kpis: dict[str, Any], comparison: dict[str, Any] | None) -> dict[str, float] | None:
    if comparison is None:
        return None
    savings_with = _pick_number(comparison, "savings_with_battery", "ahorro_con_bateria")
    savings_without = _pick_number(comparison, "savings_without_battery", "ahorro_sin_bateria")
    if savings_with is None:
        savings_with = _pick_number(kpis, "total_savings_eur", "annual_savings", "savings_annual")
    if savings_with is None or savings_without is None:
        return None

    autoconsumo_with = _pick_number(comparison, "autoconsumo_with_battery", "autoconsumo_con_bateria")
    autoconsumo_without = _pick_number(comparison, "autoconsumo_without_battery", "autoconsumo_sin_bateria")

    output: dict[str, float] = {
        "savings_with_battery": float(savings_with),
        "savings_without_battery": float(savings_without),
        "incremental_savings": float(savings_with - savings_without),
    }
    if autoconsumo_with is not None and autoconsumo_without is not None:
        output["autoconsumo_with_battery"] = float(autoconsumo_with)
        output["autoconsumo_without_battery"] = float(autoconsumo_without)
        output["autoconsumo_improvement_pct"] = float(autoconsumo_with - autoconsumo_without)
    return output


def build_executive_summary(
    *,
    project_name: str,
    client_name: str | None,
    scenario_name: str | None,
    kpis: dict,
    annual_energy_stats: dict | None = None,
    comparison: dict | None = None,
) -> dict[str, object]:
    """Construye una estructura de resumen ejecutivo con secciones comerciales limpias."""
    annual_energy_stats = annual_energy_stats or {}

    autoconsumo = _pick_number(kpis, "autoconsumo_pct")
    if autoconsumo is None:
        autoconsumo = _pick_number(annual_energy_stats, "autoconsumo_pct")

    key_metrics = {
        "Ahorro anual (€)": _pick_number(kpis, "total_savings_eur", "annual_savings", "savings_annual"),
        "VAN (€)": _pick_number(kpis, "npv", "npv_eur"),
        "TIR (%)": (_pick_number(kpis, "irr") or 0.0) * 100.0 if _pick_number(kpis, "irr") is not None else None,
        "Payback (años)": _pick_number(kpis, "payback_years", "purchase_payback_years", "payback_discounted_years"),
        "ROI (%)": (_pick_number(kpis, "roi", "purchase_roi_annual", "roi_simple_pct") or 0.0) * 100.0
        if _pick_number(kpis, "roi", "purchase_roi_annual", "roi_simple_pct") is not None
        else None,
        "Energía gestionada por batería (kWh)": _pick_number(
            kpis,
            "energia_descargada_kwh",
            "battery_managed_energy_kwh",
            "total_battery_throughput_kwh",
        ),
        "% Autoconsumo": autoconsumo,
    }

    technical_data = {
        "Capacidad batería": _pick_number(annual_energy_stats, "battery_capacity_kwh", "capacity_kwh"),
        "Potencia": _pick_number(annual_energy_stats, "battery_power_kw", "power_kw"),
        "Vida útil": _pick_number(kpis, "lifetime_years"),
        "CAPEX": _pick_number(kpis, "capex_eur"),
        "OPEX": _pick_number(kpis, "annual_opex_eur"),
        "Tasa descuento": (_pick_number(kpis, "discount_rate") or 0.0) * 100.0 if _pick_number(kpis, "discount_rate") is not None else None,
    }

    computed_comparison = _build_comparison(kpis, comparison)

    summary = {
        "project_name": project_name,
        "client_name": client_name,
        "scenario_name": scenario_name,
        "sections": {
            "resumen_clave": {key: value for key, value in key_metrics.items()},
            "datos_tecnicos": {key: value for key, value in technical_data.items()},
            "comparativa": computed_comparison,
        },
    }

    rows: list[dict[str, object]] = []
    rows.extend(_format_section_rows("RESUMEN CLAVE", list(key_metrics.items())))
    rows.extend(_format_section_rows("DATOS TÉCNICOS", list(technical_data.items())))
    if computed_comparison:
        rows.extend(
            _format_section_rows(
                "COMPARATIVA",
                [
                    ("Con batería (€)", computed_comparison.get("savings_with_battery")),
                    ("Sin batería (€)", computed_comparison.get("savings_without_battery")),
                    ("Ahorro incremental (€)", computed_comparison.get("incremental_savings")),
                    ("% mejora autoconsumo", computed_comparison.get("autoconsumo_improvement_pct")),
                ],
            )
        )
    summary["rows"] = rows
    return summary
