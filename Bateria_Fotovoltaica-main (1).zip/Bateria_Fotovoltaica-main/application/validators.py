"""Validación estricta de dataset y normalización temporal."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

import pandas as pd

from application.dataset_validator import canonicalize_columns, validate_dataset as _validate_dataset_report
from domain.errors import ValidationError


def validate_dataset(df: pd.DataFrame, *, expected_step_minutes: int | None = None, config: dict[str, Any] | None = None):
    """Devuelve un ValidationReport para el dataset recibido."""
    return _validate_dataset_report(df, expected_step_minutes=expected_step_minutes, config=config)


def validate_schema(df: pd.DataFrame) -> list[str]:
    """Compatibilidad legacy: devuelve warnings como strings y lanza ValidationError en errores."""
    report = _validate_dataset_report(df, expected_step_minutes=None)
    if not report.ok:
        raise ValidationError(report.to_text())
    return [item.message for item in report.warnings]


def normalize_dataset_15min(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    work_df = canonicalize_columns(df)
    report = _validate_dataset_report(work_df, expected_step_minutes=None)
    if not report.ok:
        raise ValidationError(report.to_text())

    mode_delta = work_df["timestamp"].diff().dropna().mode()
    warnings = [item.message for item in report.warnings]
    if mode_delta.empty:
        return work_df[["timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"]], warnings

    step = mode_delta.iloc[0]
    if step == timedelta(hours=1):
        expanded: list[dict[str, float | pd.Timestamp]] = []
        for _, row in work_df.iterrows():
            for q in range(4):
                expanded.append(
                    {
                        "timestamp": row["timestamp"] + timedelta(minutes=15 * q),
                        "load_kwh": float(row["load_kwh"]) / 4.0,
                        "pv_kwh": float(row["pv_kwh"]) / 4.0,
                        "buy_eur_kwh": float(row["buy_eur_kwh"]),
                        "sell_eur_kwh": float(row["sell_eur_kwh"]),
                    }
                )
        normalized = pd.DataFrame(expanded)
        warnings.append("Serie horaria normalizada a 15 minutos.")
    elif step == timedelta(minutes=15):
        normalized = work_df[["timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"]].copy()
    else:
        raise ValidationError(f"Periodicidad no soportada: {step}. Solo 1h o 15min.")

    expected = pd.date_range(normalized["timestamp"].iloc[0], normalized["timestamp"].iloc[-1], freq="15min")
    missing = expected.difference(pd.DatetimeIndex(normalized["timestamp"]))
    if len(missing) > 0:
        raise ValidationError(f"Se detectaron saltos imposibles en fechas. Ejemplo faltante: {missing[0]}")
    return normalized.reset_index(drop=True), warnings
