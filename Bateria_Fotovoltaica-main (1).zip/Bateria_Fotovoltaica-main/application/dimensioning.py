"""Módulo de análisis de dimensionamiento de batería mediante barrido de escenarios."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import time
from typing import Callable

import numpy as np
import pandas as pd

from application.engine import SimulationEngine
from domain.models import ScenarioConfig


ProgressFn = Callable[[int, int, str], None]


def _simulate_combo(
    df_norm: pd.DataFrame,
    config: ScenarioConfig,
    capacity_kwh: float,
    power_kw: float,
    mode: str,
    ml_model_bundle: dict | None,
    include_period_detail: bool = False,
) -> dict:
    """Ejecuta una simulación individual para una combinación de capacidad/potencia.

    Entradas:
        df_norm: DataFrame anual normalizado a 15 minutos.
        config: Escenario base desde el que se reemplaza batería.
        capacity_kwh: Capacidad candidata en kWh.
        power_kw: Potencia candidata en kW.
        mode: Modo de simulación (`optimal` o `ml`).
        ml_model_bundle: Bundle ML requerido cuando `mode="ml"`.

    Salidas:
        Diccionario con métricas clave de la combinación evaluada.

    Errores relevantes:
        ValueError: Si el modo no es válido o falta bundle ML en modo ML.
    """
    battery = replace(config.battery, capacity_kwh=float(capacity_kwh), power_kw=float(power_kw))
    combo_config = replace(config, battery=battery)

    engine = SimulationEngine()
    started = time.perf_counter()
    if mode == "optimal":
        result = engine.simulate_year(df_norm=df_norm, config=combo_config, include_period_detail=include_period_detail)
    elif mode == "ml":
        if ml_model_bundle is None:
            raise ValueError("En modo ML debes proporcionar ml_model_bundle.")
        result = engine.simulate_year_ml(df_norm=df_norm, config=combo_config, ml_model_bundle=ml_model_bundle)
    else:
        raise ValueError("mode debe ser 'optimal' o 'ml'.")
    runtime = time.perf_counter() - started

    series = result.series
    annual_savings = float(result.kpis.get("total_savings_eur", 0.0))
    annual_discharge = float(series.get("batt_discharge", pd.Series(dtype=float)).sum())
    cycles = annual_discharge / float(capacity_kwh) if capacity_kwh > 0 else 0.0
    peak_soc = float(series.get("soc_end", pd.Series([0.0])).max())
    min_soc = float(series.get("soc_end", pd.Series([0.0])).min())

    return {
        "capacity_kwh": float(capacity_kwh),
        "power_kw": float(power_kw),
        "annual_savings": annual_savings,
        "annual_cycles": cycles,
        "peak_soc": peak_soc,
        "min_soc": min_soc,
        "runtime_seconds": runtime,
        "periods": result.series if include_period_detail else pd.DataFrame(),
    }


def run_capacity_power_sweep(
    df_norm: pd.DataFrame,
    config: ScenarioConfig,
    capacities: list[float],
    powers: list[float],
    mode: str = "optimal",
    ml_model_bundle: dict | None = None,
    parallel_workers: int = 1,
    progress_callback: ProgressFn | None = None,
    sweep_mode: str = "rapido",
    top_n: int = 5,
) -> tuple[pd.DataFrame, dict[str, pd.DataFrame]]:
    """Ejecuta barrido de capacidad/potencia y devuelve tabla consolidada.

    Entradas:
        df_norm: DataFrame anual normalizado.
        config: Escenario base de simulación.
        capacities: Lista de capacidades a evaluar en kWh.
        powers: Lista de potencias a evaluar en kW.
        mode: `optimal` (solver) o `ml` (imitador).
        ml_model_bundle: Modelo requerido para modo ML.
        parallel_workers: Número de procesos para ejecución paralela.
        progress_callback: Callback opcional para reportar avance.

    Salidas:
        DataFrame con columnas:
        `capacity_kwh`, `power_kw`, `annual_savings`, `annual_cycles`,
        `peak_soc`, `min_soc`, `runtime_seconds`.

    Errores relevantes:
        ValueError: Si las listas de barrido están vacías.

    Notas:
        - `sweep_mode="rapido"` calcula solo KPIs (sin periodos).
        - `sweep_mode="completo"` conserva periodos para top-N escenarios.
    """
    if not capacities or not powers:
        raise ValueError("Debes proporcionar al menos una capacidad y una potencia.")

    combos = [(float(c), float(p)) for c in capacities for p in powers]
    total = len(combos)
    rows: list[dict] = []
    normalized_mode = sweep_mode.strip().lower()
    include_period_detail = normalized_mode in {"completo", "exhaustive_top_n"}

    if parallel_workers > 1:
        with ProcessPoolExecutor(max_workers=parallel_workers) as executor:
            futures = {
                executor.submit(
                    _simulate_combo,
                    df_norm,
                    config,
                    c,
                    p,
                    mode,
                    ml_model_bundle,
                    include_period_detail,
                ): (c, p)
                for c, p in combos
            }
            done = 0
            for fut in as_completed(futures):
                rows.append(fut.result())
                done += 1
                if progress_callback:
                    c, p = futures[fut]
                    progress_callback(done, total, f"Completado {done}/{total} (C={c:.1f}kWh, P={p:.1f}kW)")
    else:
        for idx, (c, p) in enumerate(combos, start=1):
            rows.append(_simulate_combo(df_norm, config, c, p, mode, ml_model_bundle, include_period_detail))
            if progress_callback:
                progress_callback(idx, total, f"Completado {idx}/{total} (C={c:.1f}kWh, P={p:.1f}kW)")

    top_periods: dict[str, pd.DataFrame] = {}
    if include_period_detail:
        ranking = sorted(rows, key=lambda r: r["annual_savings"], reverse=True)[: max(1, int(top_n))]
        for idx, row in enumerate(ranking, start=1):
            key = f"top_{idx}_C{row['capacity_kwh']:.1f}_P{row['power_kw']:.1f}"
            top_periods[key] = row["periods"]

    clean_rows = [{k: v for k, v in row.items() if k != "periods"} for row in rows]
    out = pd.DataFrame(clean_rows).sort_values(["capacity_kwh", "power_kw"]).reset_index(drop=True)
    return out, top_periods


def compute_roi(
    sweep_df: pd.DataFrame,
    capex_per_kwh: float,
    capex_per_kw: float,
    lifetime_years: int,
    discount_rate: float,
) -> pd.DataFrame:
    """Calcula indicadores financieros ROI/NPV/payback para cada fila del barrido.

    Entradas:
        sweep_df: Resultado del barrido con columna `annual_savings`.
        capex_per_kwh: Coste de inversión por kWh instalado.
        capex_per_kw: Coste de inversión por kW instalado.
        lifetime_years: Vida útil financiera en años.
        discount_rate: Tasa anual de descuento (ej. 0.08 = 8%).

    Salidas:
        Nuevo DataFrame con columnas `capex_eur`, `npv_eur`, `payback_years`,
        `savings_per_eur` y `roi_simple_pct`.

    Errores relevantes:
        ValueError: Si faltan columnas obligatorias o parámetros inválidos.
    """
    required = {"capacity_kwh", "power_kw", "annual_savings"}
    missing = required - set(sweep_df.columns)
    if missing:
        raise ValueError(f"Faltan columnas para ROI: {sorted(missing)}")
    if lifetime_years <= 0:
        raise ValueError("lifetime_years debe ser mayor que 0.")

    df = sweep_df.copy()
    df["capex_eur"] = df["capacity_kwh"] * capex_per_kwh + df["power_kw"] * capex_per_kw

    discount_factor = sum(1.0 / ((1.0 + discount_rate) ** year) for year in range(1, lifetime_years + 1))
    df["npv_eur"] = df["annual_savings"] * discount_factor - df["capex_eur"]

    df["payback_years"] = np.where(
        df["annual_savings"] > 0,
        df["capex_eur"] / df["annual_savings"],
        np.inf,
    )
    df["savings_per_eur"] = np.where(df["capex_eur"] > 0, df["annual_savings"] / df["capex_eur"], 0.0)
    df["roi_simple_pct"] = np.where(df["capex_eur"] > 0, (df["annual_savings"] / df["capex_eur"]) * 100.0, 0.0)
    return df


def recommend_optimal_size(sweep_df: pd.DataFrame, criterion: str = "max_savings") -> pd.DataFrame:
    """Selecciona la recomendación automática según criterio de negocio.

    Entradas:
        sweep_df: DataFrame del barrido con o sin métricas financieras.
        criterion: Criterio de recomendación:
            - `max_savings`: mayor ahorro absoluto.
            - `max_savings_per_eur`: mayor ahorro por euro invertido.
            - `min_payback`: menor payback simple.

    Salidas:
        DataFrame de una fila con la combinación recomendada.

    Errores relevantes:
        ValueError: Si el criterio es inválido o faltan columnas necesarias.
    """
    if sweep_df.empty:
        raise ValueError("El barrido está vacío; no se puede recomendar un tamaño.")

    if criterion == "max_savings":
        idx = sweep_df["annual_savings"].idxmax()
    elif criterion == "max_savings_per_eur":
        if "savings_per_eur" not in sweep_df.columns:
            raise ValueError("Para criterio max_savings_per_eur primero ejecuta compute_roi.")
        idx = sweep_df["savings_per_eur"].idxmax()
    elif criterion == "min_payback":
        if "payback_years" not in sweep_df.columns:
            raise ValueError("Para criterio min_payback primero ejecuta compute_roi.")
        valid = sweep_df[np.isfinite(sweep_df["payback_years"])].copy()
        if valid.empty:
            raise ValueError("No existe payback finito en las alternativas evaluadas.")
        idx = valid["payback_years"].idxmin()
    else:
        raise ValueError("criterion debe ser max_savings, max_savings_per_eur o min_payback.")

    return sweep_df.loc[[idx]].reset_index(drop=True)
