"""Validador profesional de datasets FV+BESS."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import timedelta
from typing import Any, Literal

import pandas as pd

COLUMN_ALIASES: dict[str, str] = {
    "FECHA": "timestamp",
    "FECHA_HORA": "timestamp",
    "timestamp": "timestamp",
    "CONSUMO": "load_kwh",
    "load_kwh": "load_kwh",
    "FV": "pv_kwh",
    "GENERACIÓN": "pv_kwh",
    "GENERACION": "pv_kwh",
    "pv_kwh": "pv_kwh",
    "POOL": "buy_eur_kwh",
    "PRECIO": "buy_eur_kwh",
    "buy_eur_kwh": "buy_eur_kwh",
    "PERIODO": "period",
    "sell_eur_kwh": "sell_eur_kwh",
}

REQUIRED_CANONICAL = {"timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh"}


@dataclass(slots=True)
class ValidationIssue:
    code: str
    level: Literal["ERROR", "WARNING"]
    message: str
    details: dict[str, Any] = field(default_factory=dict)
    rows: list[int] = field(default_factory=list)


@dataclass(slots=True)
class ValidationReport:
    ok: bool
    errors: list[ValidationIssue]
    warnings: list[ValidationIssue]
    stats: dict[str, Any]

    def to_text(self) -> str:
        lines: list[str] = [
            "=== Informe de validación del dataset ===",
            f"Estado: {'OK' if self.ok else 'CON ERRORES'}",
            f"Filas={self.stats.get('rows', 0)} | Columnas={self.stats.get('columns', 0)}",
            f"Rango temporal: {self.stats.get('start')} -> {self.stats.get('end')}",
            f"Timestep detectado: {self.stats.get('detected_step_minutes')} min",
        ]
        if self.errors:
            lines.append("\nERRORES (bloquean simulación):")
            lines.extend(f"- [{issue.code}] {issue.message}" for issue in self.errors)
        if self.warnings:
            lines.append("\nWARNINGS (revisar antes de continuar):")
            lines.extend(f"- [{issue.code}] {issue.message}" for issue in self.warnings)
        lines.append("\nSTATS:")
        lines.append(f"- %NaN por columna: {self.stats.get('nan_pct_by_column', {})}")
        lines.append(f"- Resumen columnas críticas: {self.stats.get('critical_summary', {})}")
        return "\n".join(lines)

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "errors": [asdict(item) for item in self.errors],
            "warnings": [asdict(item) for item in self.warnings],
            "stats": self.stats,
        }


def canonicalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed: dict[str, str] = {}
    for col in df.columns:
        cleaned = str(col).strip()
        renamed[col] = COLUMN_ALIASES.get(cleaned, cleaned)
    out = df.rename(columns=renamed).copy()
    if "sell_eur_kwh" not in out.columns:
        out["sell_eur_kwh"] = 0.0
    return out


def _top_rows(mask: pd.Series, limit: int = 20) -> list[int]:
    return [int(i) for i in mask[mask].index.tolist()[:limit]]


def validate_dataset(
    df: pd.DataFrame,
    *,
    expected_step_minutes: int | None = None,
    config: dict[str, Any] | None = None,
) -> ValidationReport:
    cfg = config or {}
    allow_negative = set(cfg.get("allow_negative_columns", []))
    non_negative_columns = set(cfg.get("non_negative_columns", ["load_kwh", "pv_kwh"]))

    work_df = canonicalize_columns(df)
    errors: list[ValidationIssue] = []
    warnings: list[ValidationIssue] = []

    stats: dict[str, Any] = {
        "rows": int(len(work_df)),
        "columns": int(len(work_df.columns)),
        "start": None,
        "end": None,
        "detected_step_minutes": None,
        "nan_pct_by_column": {},
        "critical_summary": {},
    }

    missing = sorted(REQUIRED_CANONICAL - set(work_df.columns))
    if missing:
        errors.append(
            ValidationIssue(
                code="MISSING_REQUIRED_COLUMNS",
                level="ERROR",
                message=f"Faltan columnas obligatorias: {missing}. Esperadas: FECHA_HORA/FECHA, CONSUMO, FV, POOL.",
                details={"missing": missing},
            )
        )
        return ValidationReport(ok=False, errors=errors, warnings=warnings, stats=stats)

    parsed_ts = pd.to_datetime(work_df["timestamp"], errors="coerce")
    invalid_ts_mask = parsed_ts.isna()
    if invalid_ts_mask.any():
        errors.append(
            ValidationIssue(
                code="TIMESTAMP_PARSE_ERROR",
                level="ERROR",
                message="Hay fechas no válidas en la columna temporal.",
                details={"invalid_count": int(invalid_ts_mask.sum())},
                rows=_top_rows(invalid_ts_mask),
            )
        )
        return ValidationReport(ok=False, errors=errors, warnings=warnings, stats=stats)

    work_df["timestamp"] = parsed_ts
    stats["start"] = str(parsed_ts.iloc[0]) if len(parsed_ts) else None
    stats["end"] = str(parsed_ts.iloc[-1]) if len(parsed_ts) else None

    if not parsed_ts.is_monotonic_increasing:
        errors.append(
            ValidationIssue(
                code="TIMESTAMP_NOT_SORTED",
                level="ERROR",
                message="Las fechas no están en orden ascendente. Ordena el dataset antes de simular.",
            )
        )

    duplicated_mask = parsed_ts.duplicated(keep=False)
    if duplicated_mask.any():
        dup_sample = parsed_ts[duplicated_mask].astype(str).head(5).tolist()
        errors.append(
            ValidationIssue(
                code="TIMESTAMP_DUPLICATED",
                level="ERROR",
                message=f"Se detectaron timestamps duplicados. Ejemplos: {dup_sample}",
                details={"duplicated_count": int(duplicated_mask.sum())},
                rows=_top_rows(duplicated_mask),
            )
        )

    deltas = parsed_ts.diff().dropna()
    if not deltas.empty:
        detected_delta = deltas.mode().iloc[0]
        detected_minutes = int(detected_delta.total_seconds() / 60)
        stats["detected_step_minutes"] = detected_minutes

        irregular_mask = deltas != detected_delta
        if irregular_mask.any():
            irregular_ratio = float(irregular_mask.mean())
            issue = ValidationIssue(
                code="TIMESTEP_IRREGULAR",
                level="ERROR" if irregular_ratio > 0.05 else "WARNING",
                message=(
                    "Se detectaron saltos temporales irregulares. "
                    f"Paso dominante={detected_minutes} min, irregularidades={irregular_ratio:.1%}."
                ),
                details={"irregular_ratio": irregular_ratio},
                rows=[int(i) for i in deltas[irregular_mask].index.tolist()[:20]],
            )
            (errors if issue.level == "ERROR" else warnings).append(issue)

        if expected_step_minutes is not None and detected_minutes != expected_step_minutes:
            mismatch = abs(detected_minutes - expected_step_minutes)
            issue = ValidationIssue(
                code="TIMESTEP_MISMATCH",
                level="ERROR" if mismatch >= max(30, expected_step_minutes) else "WARNING",
                message=(
                    f"Timestep detectado {detected_minutes} min, esperado {expected_step_minutes} min. "
                    "Revisa la granularidad del origen."
                ),
                details={"detected": detected_minutes, "expected": expected_step_minutes},
            )
            (errors if issue.level == "ERROR" else warnings).append(issue)

        if expected_step_minutes:
            large_gap = deltas > timedelta(minutes=expected_step_minutes * 4)
            if large_gap.any():
                errors.append(
                    ValidationIssue(
                        code="TIMESTAMP_LARGE_GAPS",
                        level="ERROR",
                        message="Se detectaron huecos temporales grandes (faltan intervalos).",
                        details={"gap_count": int(large_gap.sum())},
                        rows=[int(i) for i in deltas[large_gap].index.tolist()[:20]],
                    )
                )
            small_gap = (deltas > timedelta(minutes=expected_step_minutes)) & (~large_gap)
            if small_gap.any():
                warnings.append(
                    ValidationIssue(
                        code="TIMESTAMP_GAPS",
                        level="WARNING",
                        message="Se detectaron huecos temporales puntuales.",
                        details={"gap_count": int(small_gap.sum())},
                        rows=[int(i) for i in deltas[small_gap].index.tolist()[:20]],
                    )
                )

    timezone_info = getattr(parsed_ts.dt, "tz", None)
    if timezone_info is not None:
        warnings.append(
            ValidationIssue(
                code="TIMEZONE_AWARE_DATA",
                level="WARNING",
                message="El dataset incluye timezone. Verifica que no haya cambios de horario (DST) inesperados.",
                details={"timezone": str(timezone_info)},
            )
        )

    numeric_cols = [col for col in ["load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"] if col in work_df.columns]
    for col in numeric_cols:
        numeric = pd.to_numeric(work_df[col], errors="coerce")
        inf_mask = numeric.isin([float("inf"), float("-inf")])
        invalid_numeric = numeric.isna() | inf_mask
        stats["nan_pct_by_column"][col] = round(float(invalid_numeric.mean() * 100), 4)

        if invalid_numeric.any():
            errors.append(
                ValidationIssue(
                    code="NUMERIC_INVALID",
                    level="ERROR",
                    message=f"La columna '{col}' contiene NaN, infinitos o valores no numéricos.",
                    details={"invalid_count": int(invalid_numeric.sum()), "column": col},
                    rows=_top_rows(invalid_numeric),
                )
            )
            continue

        work_df[col] = numeric
        summary = {
            "min": float(numeric.min()),
            "max": float(numeric.max()),
            "median": float(numeric.median()),
        }
        stats["critical_summary"][col] = summary

        if col in non_negative_columns and col not in allow_negative and (numeric < 0).any():
            neg_mask = numeric < 0
            errors.append(
                ValidationIssue(
                    code="NEGATIVE_VALUES",
                    level="ERROR",
                    message=f"La columna '{col}' no admite valores negativos.",
                    details={"column": col, "negative_count": int(neg_mask.sum())},
                    rows=_top_rows(neg_mask),
                )
            )

        median = abs(summary["median"])
        q99 = float(numeric.quantile(0.99))
        if median > 0 and q99 > median * 100:
            warnings.append(
                ValidationIssue(
                    code="SUSPECT_OUTLIERS",
                    level="WARNING",
                    message=f"La columna '{col}' muestra outliers de orden de magnitud atípico.",
                    details={"column": col, "median": median, "q99": q99},
                )
            )

        if col in {"load_kwh", "pv_kwh"} and median > 100:
            warnings.append(
                ValidationIssue(
                    code="SUSPECT_UNIT_SCALE",
                    level="WARNING",
                    message=(
                        f"La columna '{col}' tiene mediana={median:.2f}. "
                        "Parece posible escala en W en lugar de kW/kWh. Revisa unidades."
                    ),
                    details={"column": col, "median": median},
                )
            )

    return ValidationReport(ok=len(errors) == 0, errors=errors, warnings=warnings, stats=stats)
