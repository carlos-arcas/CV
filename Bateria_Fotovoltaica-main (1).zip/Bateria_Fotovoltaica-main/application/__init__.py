"""Paquete de aplicación."""
