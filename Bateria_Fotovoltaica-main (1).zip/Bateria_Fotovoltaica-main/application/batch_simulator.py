"""Ejecución masiva de simulaciones en paralelo para múltiples clientes."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from multiprocessing import cpu_count
from pathlib import Path

import pandas as pd

from application.engine import SimulationEngine
from domain.models import BatteryConfig, GridParams, ScenarioConfig, SimulationMode, TariffParams


@dataclass(slots=True)
class ClientBatchResult:
    client: str
    battery_config: BatteryConfig
    ahorro_total: float
    roi_estimado: float


@dataclass(slots=True)
class BatchResult:
    resultados_por_cliente: list[ClientBatchResult]
    ranking_por_ahorro: list[ClientBatchResult]
    metricas_agregadas: dict[str, float]


@dataclass(slots=True)
class _TaskResult:
    client: str
    battery_config: BatteryConfig
    ahorro_total: float
    roi_estimado: float


def _simulate_task(dataset_path: str, battery_config: BatteryConfig) -> _TaskResult:
    path = Path(dataset_path)
    df = pd.read_csv(path)
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])

    scenario = ScenarioConfig(
        battery=battery_config,
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=False),
    )
    result = SimulationEngine().simulate_year(df_norm=df, config=scenario, mode=SimulationMode.FAST)
    return _TaskResult(
        client=path.stem,
        battery_config=battery_config,
        ahorro_total=float(result.kpis.get("ahorro_total", result.kpis.get("total_savings_eur", 0.0))),
        roi_estimado=float(result.kpis.get("ROI_estimado", 0.0)),
    )


def simulate_batch(datasets: list[Path], battery_configs: list[BatteryConfig]) -> BatchResult:
    """Ejecuta simulaciones masivas por cliente/configuración y agrega resultados."""
    if not datasets or not battery_configs:
        return BatchResult(resultados_por_cliente=[], ranking_por_ahorro=[], metricas_agregadas={"clientes": 0.0})

    workers = min(cpu_count(), 6)
    futures = []
    best_by_client: dict[str, ClientBatchResult] = {}

    with ProcessPoolExecutor(max_workers=workers) as pool:
        for dataset in datasets:
            for battery in battery_configs:
                futures.append(pool.submit(_simulate_task, str(dataset), battery))

        for future in as_completed(futures):
            task = future.result()
            current = best_by_client.get(task.client)
            candidate = ClientBatchResult(
                client=task.client,
                battery_config=task.battery_config,
                ahorro_total=task.ahorro_total,
                roi_estimado=task.roi_estimado,
            )
            if current is None or candidate.ahorro_total > current.ahorro_total:
                best_by_client[task.client] = candidate

    resultados = sorted(best_by_client.values(), key=lambda item: item.client)
    ranking = sorted(resultados, key=lambda item: item.ahorro_total, reverse=True)
    total_savings = float(sum(item.ahorro_total for item in resultados))

    metricas = {
        "clientes": float(len(resultados)),
        "ahorro_total": total_savings,
        "ahorro_promedio": total_savings / max(len(resultados), 1),
        "roi_promedio": float(sum(item.roi_estimado for item in resultados) / max(len(resultados), 1)),
    }

    del futures
    return BatchResult(resultados_por_cliente=resultados, ranking_por_ahorro=ranking, metricas_agregadas=metricas)
