"""DTOs de aplicación para intercambio entre casos de uso y UI."""

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from domain.models import ScenarioConfig


@dataclass(slots=True)
class InputDataDTO:
    """Contenedor de datos de entrada normalizados y metadatos asociados.

    Entradas:
        dataframe: DataFrame con contrato canónico de columnas.
        source_path: Ruta de origen del archivo cargado.
        warnings: Lista de advertencias detectadas en validación.

    Salidas:
        DTO utilizable por casos de uso y por la capa de UI.

    Errores relevantes:
        No aplica; este DTO no ejecuta validaciones por sí mismo.
    """

    dataframe: pd.DataFrame
    source_path: str
    warnings: list[str] = field(default_factory=list)
    dataset_hash: str | None = None


@dataclass(slots=True)
class InputDatasetCollectionDTO:
    """Colección de datasets normalizados para entrenamiento multi-año.

    Entradas:
        datasets: Lista de DTOs normalizados, típicamente uno por año.

    Salidas:
        Contenedor para operar en bloque (concatenación, resumen y entrenamiento).

    Errores relevantes:
        No aplica; este DTO no ejecuta validaciones por sí mismo.
    """

    datasets: list[InputDataDTO] = field(default_factory=list)

    def years(self) -> list[int]:
        """Devuelve años únicos detectados en la colección de datasets."""
        detected: set[int] = set()
        for item in self.datasets:
            if "timestamp" not in item.dataframe.columns or item.dataframe.empty:
                continue
            timestamps = pd.to_datetime(item.dataframe["timestamp"], errors="coerce").dropna()
            detected.update(timestamps.dt.year.astype(int).tolist())
        return sorted(detected)


@dataclass(slots=True)
class ResultsBundleDTO:
    """Resultado estructurado de una ejecución de simulación.

    Entradas:
        scenario: Configuración de escenario utilizada.
        series: Series temporales de salida de la simulación.
        kpis: Indicadores clave de desempeño escalares y agregados.
        logs: Mensajes operativos y diagnósticos.

    Salidas:
        Estructura consistente para mostrar y exportar resultados.

    Errores relevantes:
        No aplica en la construcción del DTO.
    """

    scenario: ScenarioConfig
    series: pd.DataFrame
    kpis: dict[str, Any]
    logs: list[str] = field(default_factory=list)
