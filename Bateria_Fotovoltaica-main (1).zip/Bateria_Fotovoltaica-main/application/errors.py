"""Errores de capa de aplicación."""

from __future__ import annotations

from application.dataset_validator import ValidationReport


class DatasetValidationError(Exception):
    """Error de validación de dataset con informe estructurado adjunto."""

    def __init__(self, message: str, report: ValidationReport) -> None:
        super().__init__(message)
        self.report = report
