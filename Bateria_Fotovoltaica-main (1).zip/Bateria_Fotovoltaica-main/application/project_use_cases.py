"""Casos de uso para persistencia y restauración de proyectos completos."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any


from application.dto import InputDataDTO, ResultsBundleDTO
from application.use_cases import LoadDatasetUseCase, ValidateAndNormalizeUseCase
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams
from domain.models_project import ModelBundleRef, ProjectConfig
from infrastructure.persistence.project_store import load_project, save_project


class SaveProjectUseCase:
    """Orquesta la construcción y persistencia de un proyecto desde estado UI."""

    def execute(
        self,
        path: str,
        project_name: str,
        input_data: InputDataDTO | None,
        scenario: ScenarioConfig,
        results: ResultsBundleDTO | None,
        export_folder: str,
        model_folder: str,
        model_info: dict[str, Any] | None,
        app_version: str,
    ) -> str:
        """Guarda un proyecto serializando escenario y referencias asociadas."""
        scenario_dict = asdict(scenario)
        model_ref = None
        if model_info and model_folder:
            model_ref = {
                "name": model_info.get("name", "model_bundle"),
                "folder": model_folder,
                "trained_at": model_info.get("trained_at"),
                "metrics": model_info.get("metrics", {}),
                "app_version": app_version,
                "schema_version": 1,
            }

        project = ProjectConfig(
            name=project_name,
            data_path=input_data.source_path if input_data else "",
            model_folder=model_folder,
            export_folder=export_folder,
            scenario=scenario_dict,
            results_cache_path=None,
            model_bundle=None if model_ref is None else ModelBundleRef(**model_ref),
            app_version=app_version,
            schema_version=2,
        )
        if results is not None and not results.series.empty:
            cache_path = f"{path}/results_cache.parquet"
            results.series.to_parquet(cache_path, index=False)
            project.results_cache_path = cache_path
        return save_project(project, path)


class LoadProjectUseCase:
    """Restaura proyecto completo aplicando validaciones y conversión de escenario."""

    def execute(self, path: str) -> dict[str, Any]:
        """Carga proyecto desde carpeta y devuelve estado para hidratar la UI."""
        project, cache_df, warnings = load_project(path)

        input_data = None
        if project.data_path:
            loaded = LoadDatasetUseCase().execute(project.data_path)
            input_data = ValidateAndNormalizeUseCase().execute(loaded)

        scenario = self.scenario_from_dict(project.scenario)
        if input_data is not None and project.model_bundle is not None:
            feature_columns = project.model_bundle.metrics.get("feature_columns", [])
            missing_features = [col for col in feature_columns if col not in input_data.dataframe.columns]
            if missing_features:
                raise ValueError(f"El dataset cargado no contiene features requeridas por el modelo: {missing_features}")

        if project.app_version != "1.0.0":
            warnings.append(
                f"Proyecto creado con app_version={project.app_version}. Se intentará compatibilidad hacia atrás."
            )

        return {
            "project": project,
            "input_data": input_data,
            "scenario": scenario,
            "results_cache": cache_df,
            "warnings": warnings,
        }

    @staticmethod
    def scenario_from_dict(data: dict[str, Any]) -> ScenarioConfig:
        """Reconstruye ScenarioConfig desde diccionario persistido."""
        battery = BatteryParams(**data.get("battery", {}))
        tariff = TariffParams(**data.get("tariff", {}))
        grid = GridParams(**data.get("grid", {}))
        return ScenarioConfig(
            battery=battery,
            tariff=tariff,
            grid=grid,
            timestep_minutes=int(data.get("timestep_minutes", 15)),
        )
