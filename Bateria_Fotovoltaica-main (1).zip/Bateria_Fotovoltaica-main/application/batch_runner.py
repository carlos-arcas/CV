"""Ejecución batch de simulaciones por proyecto (drop files & run)."""

from __future__ import annotations

import json
import logging
import shutil
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
from pathlib import Path

import pandas as pd

from application.dataset_validator import validate_dataset
from application.engine import SimulationEngine
from application.errors import DatasetValidationError
from application.use_cases import LoadDatasetUseCase, RunSimulationUseCase, ValidateAndNormalizeUseCase
from domain.models import ScenarioConfig, SimulationMode
from infrastructure.exporters import export_executive_summary_to_excel, export_results_to_excel
from infrastructure.io.cache_store import hash_file
from infrastructure.io.simulation_cache import build_simulation_hash, run_with_cache
from infrastructure.logging.logging_config import generate_run_id, timed_block

SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls", ".xlsm"}
MAX_GRID_VARIANTS = 100
METRIC_KEYS = {
    "roi": ["roi", "purchase_roi_annual", "roi_simple_pct"],
    "npv": ["npv", "npv_eur"],
    "savings": ["savings_annual", "annual_savings", "total_savings_eur"],
    "irr": ["irr"],
    "payback": ["payback_years", "purchase_payback_years"],
}
LOWER_IS_BETTER_METRICS = {"payback_years", "purchase_payback_years", "payback_discounted_years"}


@dataclass(slots=True)
class SimulationJobOutput:
    results: object | None
    kpis: dict[str, float]
    runtime_sec: float
    validation_report: dict[str, object] | None
    input_hash: str
    error: str | None
    error_type: str | None


@dataclass(slots=True)
class BatteryVariant:
    variant_id: str
    capacity_kwh: float
    power_kw: float
    roundtrip_efficiency: float | None = None
    max_c_rate: float | None = None
    constraints_profile: str | None = None


@dataclass(slots=True)
class BatchJobResult:
    input_path: Path
    client: str | None
    variant_id: str | None
    export_file: str | None
    status: str
    error: str | None
    error_type: str | None
    kpis: dict[str, float]
    battery_params: dict[str, object]
    runtime_sec: float
    results: object | None


def ensure_batch_structure(project_dir: Path) -> dict[str, Path]:
    batches_dir = project_dir / "batches"
    folders = {
        "input": batches_dir / "input",
        "output": batches_dir / "output",
        "archive": batches_dir / "archive",
        "logs": batches_dir / "logs",
        "runs": batches_dir / "_runs",
    }
    for folder in folders.values():
        folder.mkdir(parents=True, exist_ok=True)
    return folders


def build_run_id() -> str:
    return generate_run_id()


def collect_input_files(input_dir: Path, pattern: str) -> list[Path]:
    files: list[Path] = []
    seen: set[Path] = set()
    for chunk in pattern.split(","):
        token = chunk.strip() or "*"
        for candidate in sorted(input_dir.glob(token)):
            if candidate.is_file() and candidate not in seen:
                seen.add(candidate)
                files.append(candidate)
    return sorted(files)


def _scalar_kpis(raw_kpis: dict[str, object]) -> dict[str, float]:
    output: dict[str, float] = {}
    for key, value in raw_kpis.items():
        if isinstance(value, (int, float, bool)):
            output[key] = float(value)
    return output


def _archive_input_file(input_path: Path, archive_dir: Path) -> None:
    archive_dir.mkdir(parents=True, exist_ok=True)
    target = archive_dir / input_path.name
    if target.exists():
        target = archive_dir / f"{input_path.stem}_{uuid.uuid4().hex[:6]}{input_path.suffix}"
    shutil.move(str(input_path), str(target))


def scenario_to_dict(scenario: ScenarioConfig) -> dict[str, object]:
    return {
        "battery": asdict(scenario.battery),
        "tariff": asdict(scenario.tariff),
        "grid": asdict(scenario.grid),
        "timestep_minutes": scenario.timestep_minutes,
    }


def build_battery_grid(
    *,
    project_dir: Path,
    base_scenario: ScenarioConfig,
    use_grid: bool,
    capacities_override: list[float] | None = None,
    powers_override: list[float] | None = None,
) -> list[BatteryVariant]:
    base_capacity = float(base_scenario.battery.capacity_kwh)
    base_power = float(base_scenario.battery.power_kw)
    base_roundtrip = float(base_scenario.battery.charge_efficiency * base_scenario.battery.discharge_efficiency)

    capacities: list[float]
    powers: list[float]
    roundtrip_values: list[float | None] = [None]
    max_c_rates: list[float | None] = [None]
    constraints_profile = "default"

    grid_path = project_dir / "battery_grid.json"
    if use_grid and grid_path.exists():
        payload = json.loads(grid_path.read_text(encoding="utf-8"))
        capacities = [float(x) for x in payload.get("capacities_kwh", [])]
        powers = [float(x) for x in payload.get("powers_kw", [])]
        if "roundtrip_efficiency" in payload:
            roundtrip_values = [float(x) for x in payload.get("roundtrip_efficiency", [])]
        if "max_c_rate" in payload:
            max_c_rates = [float(x) for x in payload.get("max_c_rate", [])]
        constraints_profile = str(payload.get("constraints_profile", "default"))
    else:
        capacities = [base_capacity]
        powers = [base_power]

    if capacities_override:
        capacities = [float(x) for x in capacities_override]
    if powers_override:
        powers = [float(x) for x in powers_override]

    if not capacities or not powers:
        raise ValueError("El grid de batería requiere capacities_kwh y powers_kw no vacíos.")

    for value in [*capacities, *powers]:
        if value <= 0:
            raise ValueError("capacity_kwh y power_kw deben ser mayores que 0.")
    for value in [item for item in roundtrip_values if item is not None]:
        if value <= 0 or value > 1:
            raise ValueError("roundtrip_efficiency debe estar en (0,1].")
    for value in [item for item in max_c_rates if item is not None]:
        if value <= 0:
            raise ValueError("max_c_rate debe ser mayor que 0.")

    variants: list[BatteryVariant] = []
    for idx, (capacity, power, roundtrip, max_c_rate) in enumerate(product(capacities, powers, roundtrip_values, max_c_rates), start=1):
        if max_c_rate is not None and power > (capacity * max_c_rate):
            continue
        variant_id = f"v{idx:03d}_c{capacity:g}_p{power:g}"
        variants.append(
            BatteryVariant(
                variant_id=variant_id,
                capacity_kwh=capacity,
                power_kw=power,
                roundtrip_efficiency=roundtrip,
                max_c_rate=max_c_rate,
                constraints_profile=constraints_profile,
            )
        )
    if not variants:
        variants.append(
            BatteryVariant(
                variant_id="v001_base",
                capacity_kwh=base_capacity,
                power_kw=base_power,
                roundtrip_efficiency=base_roundtrip,
            )
        )
    return variants


def patch_scenario_for_variant(base_scenario: ScenarioConfig, variant: BatteryVariant) -> ScenarioConfig:
    patched = deepcopy(base_scenario)
    patched.battery.capacity_kwh = float(variant.capacity_kwh)
    patched.battery.power_kw = float(variant.power_kw)
    if variant.roundtrip_efficiency is not None:
        split_eff = float(variant.roundtrip_efficiency) ** 0.5
        patched.battery.charge_efficiency = split_eff
        patched.battery.discharge_efficiency = split_eff
    return patched


def scenario_hash(base_scenario: ScenarioConfig, variant: BatteryVariant) -> str:
    payload = {
        "base_scenario": scenario_to_dict(base_scenario),
        "patch": {
            "capacity_kwh": variant.capacity_kwh,
            "power_kw": variant.power_kw,
            "roundtrip_efficiency": variant.roundtrip_efficiency,
            "max_c_rate": variant.max_c_rate,
            "constraints_profile": variant.constraints_profile,
        },
    }
    text = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return sha256(text.encode("utf-8")).hexdigest()


def resolve_metric_key(metric: str, kpi_dicts: list[dict[str, float]]) -> str:
    candidates = METRIC_KEYS.get(metric, METRIC_KEYS["savings"])
    for key in candidates:
        if any(key in item for item in kpi_dicts):
            return key
    return "total_savings_eur"


def run_simulation_job(
    *,
    input_path: Path,
    scenario: ScenarioConfig,
    strict_warnings: bool,
    mode: SimulationMode,
    include_detail: bool,
    run_use_case: RunSimulationUseCase,
    load_use_case: LoadDatasetUseCase,
    normalize_use_case: ValidateAndNormalizeUseCase,
    project_dir: Path | None = None,
    use_cache: bool = True,
    financial_params: dict[str, object] | None = None,
) -> SimulationJobOutput:
    started = time.perf_counter()
    try:
        input_hash = hash_file(str(input_path))
        with timed_block("dataset_load"):
            loaded = load_use_case.execute(str(input_path))

        with timed_block("validation"):
            report = validate_dataset(loaded.dataframe, expected_step_minutes=scenario.timestep_minutes)
            if (not report.ok) or (strict_warnings and report.warnings):
                raise DatasetValidationError(report.to_text(), report)
            if "timestamp" in loaded.dataframe.columns:
                loaded.dataframe["timestamp"] = pd.to_datetime(loaded.dataframe["timestamp"], errors="coerce")
                if loaded.dataframe["timestamp"].isna().any():
                    raise ValueError("No se pudo parsear la columna timestamp a fecha/hora.")

        with timed_block("simulation"):
            normalized = normalize_use_case.execute(loaded)
            if project_dir is not None:
                simulation_hash = build_simulation_hash(
                    dataset_path=input_path,
                    scenario_config=scenario_to_dict(scenario),
                    fast_mode=mode == SimulationMode.FAST,
                    financial_params=financial_params,
                )
                if not use_cache:
                    shutil.rmtree(project_dir / "cache" / simulation_hash, ignore_errors=True)

                def _compute() -> object:
                    result = run_use_case.execute(normalized, scenario, include_detail=include_detail, use_cache=False, mode=mode)
                    result.kpis.setdefault("dataset_hash", input_hash)
                    result.kpis.setdefault("simulation_fast_mode", mode == SimulationMode.FAST)
                    return result

                results = run_with_cache(project_dir=project_dir, simulation_hash=simulation_hash, compute_func=_compute)
            else:
                results = run_use_case.execute(normalized, scenario, include_detail=include_detail, use_cache=False, mode=mode)

        return SimulationJobOutput(
            results=results,
            kpis=_scalar_kpis(results.kpis),
            runtime_sec=time.perf_counter() - started,
            validation_report=report.to_json_dict(),
            input_hash=input_hash,
            error=None,
            error_type=None,
        )
    except Exception as exc:  # noqa: BLE001
        error_message = str(exc) or exc.__class__.__name__
        error_type = "simulation"
        if isinstance(exc, (ValueError, DatasetValidationError)):
            if "Formato no soportado" in error_message:
                error_type = "unsupported"
            else:
                error_type = "validation"
        return SimulationJobOutput(
            results=None,
            kpis={},
            runtime_sec=time.perf_counter() - started,
            validation_report=None,
            input_hash=hash_file(str(input_path)) if input_path.exists() else "",
            error=error_message,
            error_type=error_type,
        )


def _metric_value(row: dict[str, object], metric_key: str) -> float:
    value = row.get(metric_key)
    if isinstance(value, (int, float)):
        metric_value = float(value)
        if metric_key in LOWER_IS_BETTER_METRICS:
            return -metric_value
        return metric_value
    return float("-inf")


def _write_table(df: pd.DataFrame, path_base: Path) -> str:
    xlsx_path = path_base.with_suffix(".xlsx")
    try:
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        return xlsx_path.name
    except Exception:
        csv_path = path_base.with_suffix(".csv")
        df.to_csv(csv_path, index=False)
        return csv_path.name


def _build_variant_row(result: BatchJobResult, metric_key: str) -> dict[str, object]:
    kpis = result.kpis
    return {
        "client": result.client,
        "variant_id": result.variant_id,
        "capacity_kwh": result.battery_params.get("capacity_kwh"),
        "power_kw": result.battery_params.get("power_kw"),
        "metric_value": kpis.get(metric_key),
        "savings_annual": kpis.get("total_savings_eur", kpis.get("annual_savings")),
        "roi": kpis.get("roi", kpis.get("purchase_roi_annual", kpis.get("roi_simple_pct"))),
        "npv": kpis.get("npv", kpis.get("npv_eur")),
        "irr": kpis.get("irr"),
        "payback_years": kpis.get("payback_years"),
        "runtime_sec": result.runtime_sec,
        "status": result.status,
        "error": result.error,
    }


def run_batch(
    *,
    project_dir: Path,
    base_scenario: ScenarioConfig,
    battery_grid: list[BatteryVariant],
    project_schema_version: int,
    pattern: str,
    overwrite: bool,
    workers: int,
    ranking_metric: str,
    strict_warnings: bool = False,
    fast: bool = False,
    export_detail: bool = False,
    run_id: str | None = None,
    include_executive: bool = True,
    use_cache: bool = True,
) -> tuple[str, list[BatchJobResult]]:
    folders = ensure_batch_structure(project_dir)
    input_files = collect_input_files(folders["input"], pattern)
    if not input_files:
        return "", []

    run_id = run_id or build_run_id()
    archive_run_dir = folders["archive"] / run_id
    logs_run_dir = folders["logs"] / run_id
    run_root = folders["runs"] / run_id
    run_root.mkdir(parents=True, exist_ok=True)
    logs_run_dir.mkdir(parents=True, exist_ok=True)

    run_use_case = RunSimulationUseCase(engine=SimulationEngine())
    load_use_case = LoadDatasetUseCase()
    normalize_use_case = ValidateAndNormalizeUseCase(strict_warnings=strict_warnings)
    mode = SimulationMode.FAST if fast else SimulationMode.OPTIMAL

    all_results: list[BatchJobResult] = []
    lock = threading.Lock()

    def execute_variant(input_path: Path, variant: BatteryVariant) -> BatchJobResult:
        client = input_path.stem
        variant_started = time.perf_counter()
        logging.info("[%s] [%s] starting...", client, variant.variant_id)
        rel_input = input_path.relative_to(project_dir).as_posix()
        client_run_dir = run_root / client
        client_run_dir.mkdir(parents=True, exist_ok=True)

        patched_scenario = patch_scenario_for_variant(base_scenario, variant)
        manifest_file = client_run_dir / f"{variant.variant_id}.manifest.json"
        log_file = logs_run_dir / f"{client}__{variant.variant_id}.log"
        export_name = f"{client}__{variant.variant_id}__result.xlsx"
        export_path = folders["output"] / export_name
        patch_hash = scenario_hash(base_scenario, variant)

        manifest: dict[str, object] = {
            "run_id": run_id,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "client": client,
            "variant_id": variant.variant_id,
            "input_file": rel_input,
            "input_hash": "",
            "scenario_hash": patch_hash,
            "project_schema_version": project_schema_version,
            "scenario_summary": scenario_to_dict(patched_scenario),
            "battery_params": asdict(variant),
            "kpis": {},
            "runtime_sec": 0.0,
            "export_file": None,
            "status": "error",
            "error": None,
            "validation_report": None,
        }

        try:
            if input_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                raise ValueError(f"Formato no soportado: {input_path.suffix}")
            if export_path.exists() and not overwrite:
                raise FileExistsError(f"Ya existe salida para '{input_path.name}' variante '{variant.variant_id}'.")

            sim_output = run_simulation_job(
                input_path=input_path,
                scenario=patched_scenario,
                strict_warnings=strict_warnings,
                mode=mode,
                include_detail=export_detail,
                run_use_case=run_use_case,
                load_use_case=load_use_case,
                normalize_use_case=normalize_use_case,
                project_dir=project_dir,
                use_cache=use_cache,
            )
            manifest["input_hash"] = sim_output.input_hash
            manifest["runtime_sec"] = sim_output.runtime_sec
            manifest["validation_report"] = sim_output.validation_report

            if sim_output.error is not None or sim_output.results is None:
                raise RuntimeError(sim_output.error or "Error desconocido")

            with timed_block("export"):
                export_results_to_excel(
                    sim_output.results,
                    str(export_path),
                    export_level="full" if export_detail else "kpis_only",
                    include_executive=include_executive,
                )
            manifest["kpis"] = sim_output.kpis
            manifest["export_file"] = export_path.relative_to(project_dir).as_posix()
            manifest["status"] = "ok"

            logging.info("[%s] [%s] finished in %.3f sec", client, variant.variant_id, time.perf_counter() - variant_started)
            return BatchJobResult(
                input_path=input_path,
                client=client,
                variant_id=variant.variant_id,
                export_file=manifest["export_file"],
                status="ok",
                error=None,
                error_type=None,
                kpis=sim_output.kpis,
                battery_params=asdict(variant),
                runtime_sec=sim_output.runtime_sec,
                results=sim_output.results,
            )
        except Exception as exc:  # noqa: BLE001
            error_message = str(exc) or exc.__class__.__name__
            error_type = "simulation"
            if isinstance(exc, ValueError) and "Formato no soportado" in error_message:
                error_type = "unsupported"
            elif isinstance(exc, (ValueError, DatasetValidationError)):
                error_type = "validation"
            elif isinstance(exc, FileExistsError):
                error_type = "skipped"

            manifest["status"] = "error"
            manifest["error"] = error_message
            logging.error("[%s] [%s] failed in %.3f sec: %s", client, variant.variant_id, time.perf_counter() - variant_started, error_message)
            with open(log_file, "w", encoding="utf-8") as fh:
                fh.write(traceback.format_exc())

            return BatchJobResult(
                input_path=input_path,
                client=client,
                variant_id=variant.variant_id,
                export_file=None,
                status="error",
                error=error_message,
                error_type=error_type,
                kpis={},
                battery_params=asdict(variant),
                runtime_sec=float(manifest["runtime_sec"]),
                results=None,
            )
        finally:
            manifest["finished_at"] = datetime.now(timezone.utc).isoformat()
            with open(manifest_file, "w", encoding="utf-8") as fh:
                json.dump(manifest, fh, indent=2, ensure_ascii=False)

    def execute_for_client(file_path: Path) -> None:
        client_results = [execute_variant(file_path, variant) for variant in battery_grid]
        metric_key = resolve_metric_key(ranking_metric, [item.kpis for item in client_results if item.kpis])
        rows = [_build_variant_row(item, metric_key) for item in client_results]
        ranking_df = pd.DataFrame(rows)
        ranking_df["_status_order"] = ranking_df["status"].map({"ok": 0, "error": 1}).fillna(2)
        ranking_df = ranking_df.sort_values(
            by=["_status_order", "metric_value"],
            ascending=[True, False],
            na_position="last",
        ).drop(columns=["_status_order"])
        output_name = _write_table(ranking_df, folders["output"] / f"{file_path.stem}__ranking")

        if include_executive:
            ok_variants = [item for item in client_results if item.status == "ok" and item.results is not None]
            if ok_variants:
                ranked_ok = sorted(
                    ok_variants,
                    key=lambda item: _metric_value(_build_variant_row(item, metric_key), metric_key),
                    reverse=True,
                )
                best = ranked_ok[0]
                top_configurations = [
                    {
                        "variant_id": item.variant_id,
                        "capacity_kwh": item.battery_params.get("capacity_kwh"),
                        "power_kw": item.battery_params.get("power_kw"),
                        metric_key: item.kpis.get(metric_key),
                        "savings_annual": item.kpis.get("total_savings_eur", item.kpis.get("annual_savings")),
                    }
                    for item in ranked_ok[:3]
                ]
                executive_path = folders["output"] / f"{file_path.stem}__executive_summary.xlsx"
                export_executive_summary_to_excel(
                    results=best.results,
                    path=str(executive_path),
                    top_configurations=top_configurations,
                    client_name=file_path.stem,
                    scenario_name=best.variant_id,
                )

        with lock:
            all_results.extend(client_results)
            if file_path.exists():
                _archive_input_file(file_path, archive_run_dir)
            client_manifest = {
                "client": file_path.stem,
                "run_id": run_id,
                "metric_key": metric_key,
                "variants": len(client_results),
                "ok": len([item for item in client_results if item.status == "ok"]),
                "error": len([item for item in client_results if item.status == "error"]),
                "ranking_file": f"batches/output/{output_name}",
                "status": "ok" if any(item.status == "ok" for item in client_results) else "failed",
            }
            with open(run_root / file_path.stem / "client_manifest.json", "w", encoding="utf-8") as fh:
                json.dump(client_manifest, fh, indent=2, ensure_ascii=False)

    max_workers = max(1, workers)
    if max_workers == 1:
        for file_path in input_files:
            execute_for_client(file_path)
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(execute_for_client, file_path) for file_path in input_files]
            for future in as_completed(futures):
                future.result()

    metric_key = resolve_metric_key(ranking_metric, [item.kpis for item in all_results if item.kpis])
    global_rows = [_build_variant_row(item, metric_key) for item in all_results]
    global_df = pd.DataFrame(global_rows)
    global_df["_status_order"] = global_df["status"].map({"ok": 0, "error": 1}).fillna(2)
    global_df = global_df.sort_values(
        by=["_status_order", "metric_value"],
        ascending=[True, False],
        na_position="last",
    ).drop(columns=["_status_order"])
    global_file = _write_table(global_df, folders["output"] / "__global_ranking")

    run_manifest = {
        "run_id": run_id,
        "metric_key": metric_key,
        "total_clients": len(input_files),
        "total_variants": len(all_results),
        "ok_variants": len([item for item in all_results if item.status == "ok"]),
        "error_variants": len([item for item in all_results if item.status == "error"]),
        "global_ranking_file": f"batches/output/{global_file}",
        "battery_grid": [asdict(item) for item in battery_grid],
    }
    with open(run_root / "run_manifest.json", "w", encoding="utf-8") as fh:
        json.dump(run_manifest, fh, indent=2, ensure_ascii=False)

    return run_id, sorted(all_results, key=lambda item: (item.input_path.name, item.variant_id or ""))
