"""Motor de simulación anual con optimización diaria LP/heurística."""

from __future__ import annotations

import json
import logging
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

import numpy as np
import pandas as pd

from application.dto import InputDataDTO, ResultsBundleDTO
from application.finance.financial_kpis import build_cashflow, irr, npv, payback_discounted, payback_simple, roi_total
from application.lp_solver import LPDailySolver
from domain.errors import SimulationError
from domain.invariants import assert_finite, assert_non_negative, assert_soc_bounds, clamp_soc
from domain.models import ScenarioConfig, SimulationMode

logger = logging.getLogger(__name__)


class ProgressCallback(Protocol):
    """Contrato para reportar progreso incremental de simulación."""

    def __call__(self, current: int, total: int, message: str) -> None:
        """Recibe el avance actual del proceso de simulación."""


@dataclass(slots=True)
class _DayArrays:
    """Contenedor vectorial de entradas de un día para el solver.

    Entradas:
        timestamp: Serie temporal del día (96 periodos esperados).
        load: Consumo por periodo en kWh.
        pv: Producción FV por periodo en kWh.
        buy_price: Precio de compra por periodo en EUR/kWh.
        sell_price: Precio de venta por periodo en EUR/kWh.

    Salidas:
        Estructura compacta para resolver el despacho diario.

    Errores relevantes:
        ValueError: Si los arrays no comparten dimensión.
    """

    timestamp: np.ndarray
    load: np.ndarray
    pv: np.ndarray
    buy_price: np.ndarray
    sell_price: np.ndarray

    def __post_init__(self) -> None:
        """Valida que todos los arrays del día tengan igual longitud."""
        sizes = {arr.shape[0] for arr in (self.timestamp, self.load, self.pv, self.buy_price, self.sell_price)}
        if len(sizes) != 1:
            raise ValueError("Los arrays diarios tienen longitudes inconsistentes.")


@dataclass(slots=True)
class _DailySolverAdapter:
    """Adaptador estricto que delega toda la optimización diaria al solver LP.

    Entradas:
        scenario: Configuración del escenario con límites físicos y económicos.

    Salidas:
        Flujos diarios optimizados por programación lineal.

    Errores relevantes:
        SimulationError: Si el problema no tiene solución factible u óptima.
    """

    scenario: ScenarioConfig

    def solve(self, day: _DayArrays, soc_start: float) -> tuple[dict[str, np.ndarray], str]:
        """Resuelve un día usando exclusivamente el motor LP.

        Esta función existe para aislar la capa de orquestación anual de la
        implementación concreta del solver. Garantiza que no se utilicen
        heurísticas, percentiles ni reglas manuales.

        Entradas:
            day: Arrays diarios de demanda, FV y precios.
            soc_start: Estado de carga inicial del día en kWh.

        Salidas:
            Tupla (resultado, modo_solver), donde modo_solver siempre es `lp_scipy`.

        Invariantes:
            El resultado devuelto ya fue validado por `_validate_solution` del solver LP.
        """
        solver = LPDailySolver(scenario=self.scenario)
        return solver.solve(day=day, soc_start=soc_start), "lp_scipy"


@dataclass(slots=True)
class SimulationResult:
    """Resultado interno del núcleo matemático de simulación."""

    kpis: dict[str, Any]
    hourly_detail: pd.DataFrame | None
    metadata: dict[str, Any]
    logs: list[str]


@dataclass(slots=True)
class SimulationEngine:
    """Engine de simulación anual con solver diario LP/heurístico.

    Entradas:
        progress_callback: Callback opcional para progreso por día procesado.

    Salidas:
        ResultsBundleDTO con resultados por periodo y KPIs agregados.

    Errores relevantes:
        ValueError: Si faltan columnas obligatorias o no hay días en el dataset.
    """

    progress_callback: ProgressCallback | None = None
    default_lifetime_years: int = 15
    default_discount_rate: float = 0.05
    default_annual_opex: float = 0.0
    default_degradation_rate: float = 0.0

    def run(self, input_data: InputDataDTO, scenario: ScenarioConfig) -> ResultsBundleDTO:
        """Ejecuta la simulación anual usando el dataframe normalizado del input.

        Entradas:
            input_data: DTO con series normalizadas a 15 minutos.
            scenario: Configuración técnica y tarifaria de la simulación.

        Salidas:
            ResultsBundleDTO con tabla de periodos, KPIs y logs operativos.

        Errores relevantes:
            ValueError: Si el dataframe no contiene información suficiente para simular.
        """
        return self.simulate_year(df_norm=input_data.dataframe, config=scenario)

    def simulate_year(
        self,
        df_norm: pd.DataFrame,
        config: ScenarioConfig,
        include_period_detail: bool = True,
        chain_soc_days: bool = True,
        debug_mode: bool = False,
        debug_dump_path: str = "outputs/debug_dump.json",
        mode: SimulationMode = SimulationMode.OPTIMAL,
    ) -> ResultsBundleDTO:
        """Simula un año completo resolviendo cada día y encadenando SoC final-inicio.

        Entradas:
            df_norm: DataFrame normalizado con columnas timestamp/load/pv/precios.
            config: Escenario de batería, red y tarifa.
            chain_soc_days: Si es True encadena SoC fin→inicio entre días.

        Salidas:
            ResultsBundleDTO con resultados por periodo y agregados día/mes/año.

        Restricciones:
            Requiere resolución de 15 minutos y continuidad temporal ya validada.

        Errores relevantes:
            ValueError: Si falta alguna columna crítica para operar el solver.
        """
        aggregate_only = mode == SimulationMode.FAST and not include_period_detail
        core = self.simulate_core(
            dataset=df_norm,
            scenario=config,
            aggregate_only=aggregate_only,
            chain_soc_days=chain_soc_days,
            debug_mode=debug_mode,
            debug_dump_path=debug_dump_path,
            mode=mode,
        )
        detail = core.hourly_detail
        if detail is None:
            detail = pd.DataFrame(
                columns=[
                    "timestamp",
                    "load",
                    "pv",
                    "buy_price",
                    "sell_price",
                    "soc_start",
                    "soc_end",
                    "grid_import",
                    "grid_export",
                    "batt_charge",
                    "batt_discharge",
                    "pv_used_load",
                    "pv_used_batt",
                    "cost_base",
                    "cost_bess",
                    "savings",
                ]
            )
        return ResultsBundleDTO(scenario=config, series=detail, kpis=core.kpis, logs=core.logs)

    def simulate_core(
        self,
        dataset: pd.DataFrame,
        scenario: ScenarioConfig,
        *,
        aggregate_only: bool,
        chain_soc_days: bool,
        debug_mode: bool,
        debug_dump_path: str,
        mode: SimulationMode,
    ) -> SimulationResult:
        """Ejecuta el núcleo matemático, con opción de salida agregada o detallada."""
        required_columns = {"timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"}
        missing = required_columns - set(dataset.columns)
        if missing:
            raise ValueError(f"Faltan columnas para simular: {sorted(missing)}")
        if dataset.empty:
            raise ValueError("No hay datos para simular.")

        started = time.perf_counter()
        df = dataset.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df = df.sort_values("timestamp").reset_index(drop=True)
        io_seconds = time.perf_counter() - started

        t_norm0 = time.perf_counter()
        ts_arr = df["timestamp"].to_numpy(dtype="datetime64[ns]")
        load_arr = df["load_kwh"].to_numpy(dtype=float)
        pv_arr = df["pv_kwh"].to_numpy(dtype=float)
        buy_arr = df["buy_eur_kwh"].to_numpy(dtype=float)
        sell_arr = df["sell_eur_kwh"].to_numpy(dtype=float)
        day_keys = ts_arr.astype("datetime64[D]")
        day_start_idx = np.r_[0, np.flatnonzero(day_keys[1:] != day_keys[:-1]) + 1]
        day_end_idx = np.r_[day_start_idx[1:], len(day_keys)]
        unique_days = [pd.Timestamp(day_keys[idx]).date() for idx in day_start_idx]
        normalization_seconds = time.perf_counter() - t_norm0
        if not unique_days:
            raise ValueError("No se detectaron días válidos en el dataset.")

        solver = _DailySolverAdapter(scenario=scenario)
        soc_kwh = scenario.battery.capacity_kwh * scenario.battery.soc_initial_pct / 100.0
        period_results: list[pd.DataFrame] = []
        logs: list[str] = []
        solver_modes: dict[str, int] = {"lp_scipy": 0}
        annual_acc = {
            "cost_base": 0.0,
            "cost_bess": 0.0,
            "savings": 0.0,
            "grid_import": 0.0,
            "grid_export": 0.0,
            "batt_charge": 0.0,
            "batt_discharge": 0.0,
            "load": 0.0,
            "pv": 0.0,
            "pv_direct": 0.0,
            "pv_to_batt": 0.0,
        }
        debug_steps: deque[dict[str, Any]] = deque(maxlen=50)
        t_solver0 = time.perf_counter()
        try:
            for idx_day, (day, idx0, idx1) in enumerate(zip(unique_days, day_start_idx, day_end_idx, strict=True), start=1):
                day_arrays = _DayArrays(
                    timestamp=ts_arr[idx0:idx1],
                    load=load_arr[idx0:idx1],
                    pv=pv_arr[idx0:idx1],
                    buy_price=buy_arr[idx0:idx1],
                    sell_price=sell_arr[idx0:idx1],
                )
                day_result, solver_mode = self.optimize_day(day_arrays=day_arrays, soc_start=soc_kwh, config=scenario, solver=solver)
                solver_modes[solver_mode] = solver_modes.get(solver_mode, 0) + 1

                soc = day_result["soc"]
                soc_min = scenario.battery.capacity_kwh * scenario.battery.soc_min_pct / 100.0
                soc_max = scenario.battery.capacity_kwh
                grid_to_batt = day_result.get("grid_to_batt", np.zeros_like(day_result["grid_to_load"]))
                batt_to_grid = day_result.get("batt_to_grid", np.zeros_like(day_result["grid_to_load"]))
                grid_import = day_result["grid_to_load"] + grid_to_batt
                grid_export = day_result["pv_to_grid"] + batt_to_grid
                batt_charge = day_result["pv_to_batt"] + grid_to_batt
                batt_discharge = day_result["batt_to_load"] + batt_to_grid

                net_base = day_arrays.load - day_arrays.pv
                base_import = np.clip(net_base, 0.0, None)
                base_export = np.clip(-net_base, 0.0, None) if scenario.tariff.allow_sell else np.zeros_like(net_base)
                cost_base = day_arrays.buy_price * base_import - day_arrays.sell_price * base_export
                cost_bess = day_arrays.buy_price * grid_import - day_arrays.sell_price * grid_export
                savings = cost_base - cost_bess

                annual_acc["cost_base"] += float(cost_base.sum())
                annual_acc["cost_bess"] += float(cost_bess.sum())
                annual_acc["savings"] += float(savings.sum())
                annual_acc["grid_import"] += float(grid_import.sum())
                annual_acc["grid_export"] += float(grid_export.sum())
                annual_acc["batt_charge"] += float(batt_charge.sum())
                annual_acc["batt_discharge"] += float(batt_discharge.sum())
                annual_acc["load"] += float(day_arrays.load.sum())
                annual_acc["pv"] += float(day_arrays.pv.sum())
                annual_acc["pv_direct"] += float(day_result["pv_to_load"].sum())
                annual_acc["pv_to_batt"] += float(day_result["pv_to_batt"].sum())

                if not aggregate_only:
                    period_results.append(
                        pd.DataFrame(
                            {
                                "timestamp": day_arrays.timestamp,
                                "load": day_arrays.load,
                                "pv": day_arrays.pv,
                                "buy_price": day_arrays.buy_price,
                                "sell_price": day_arrays.sell_price,
                                "soc_start": soc[:-1],
                                "soc_end": soc[1:],
                                "grid_import": grid_import,
                                "grid_export": grid_export,
                                "batt_charge": batt_charge,
                                "batt_discharge": batt_discharge,
                                "pv_used_load": day_result["pv_to_load"],
                                "pv_used_batt": day_result["pv_to_batt"],
                                "cost_base": cost_base,
                                "cost_bess": cost_bess,
                                "savings": savings,
                            }
                        )
                    )

                if mode != SimulationMode.FAST:
                    for step_i in range(len(day_arrays.load)):
                        context = {"day": str(day), "index": int(idx0 + step_i), "timestamp": str(day_arrays.timestamp[step_i])}
                        soc[step_i + 1] = clamp_soc(float(soc[step_i + 1]), soc_min=soc_min, soc_max=soc_max)
                        assert_finite(float(soc[step_i + 1]), label="soc", context=context)
                        assert_soc_bounds(float(soc[step_i + 1]), soc_min=soc_min, soc_max=soc_max, context=context)
                        assert_non_negative(float(grid_import[step_i]), label="grid_import", context=context)
                        assert_non_negative(float(grid_export[step_i]), label="grid_export", context=context)
                        debug_steps.append({**context, "soc": float(soc[step_i + 1]), "grid_import": float(grid_import[step_i]), "grid_export": float(grid_export[step_i])})

                soc_kwh = float(soc[-1]) if chain_soc_days else scenario.battery.capacity_kwh * scenario.battery.soc_initial_pct / 100.0
                msg = f"Día {day} procesado con {solver_mode} ({idx_day}/{len(unique_days)})."
                logs.append(msg)
                if self.progress_callback:
                    self.progress_callback(idx_day, len(unique_days), msg)
        except SimulationError:
            if debug_mode:
                dump_path = Path(debug_dump_path)
                dump_path.parent.mkdir(parents=True, exist_ok=True)
                dump_payload = json.dumps({"last_steps": list(debug_steps), "config": str(scenario)}, ensure_ascii=False, indent=2)
                dump_path.write_text(dump_payload, encoding="utf-8")
            raise

        solver_seconds = time.perf_counter() - t_solver0
        export_started = time.perf_counter()
        hourly_detail = None if aggregate_only else pd.concat(period_results, ignore_index=True)
        if mode == SimulationMode.FAST:
            kpis = self._build_fast_kpis(annual_acc=annual_acc, periods=len(ts_arr), days=len(unique_days), config=scenario)
        else:
            detail_for_kpi = hourly_detail if hourly_detail is not None else pd.DataFrame({"timestamp": ts_arr, "grid_import": np.zeros_like(load_arr), "grid_export": np.zeros_like(load_arr), "cost_base": np.nan, "cost_bess": np.nan, "savings": np.nan})
            kpis = self._build_kpis(results_df=detail_for_kpi, solver_modes=solver_modes, config=scenario)
        kpis["timings_seconds"] = {
            "io": float(io_seconds),
            "normalization": float(normalization_seconds),
            "solver": float(solver_seconds),
            "export": float(time.perf_counter() - export_started),
            "total": float(time.perf_counter() - started),
        }
        kpis["mode"] = str(mode)

        metadata = {
            "rows_processed": int(len(ts_arr)),
            "days_simulated": int(len(unique_days)),
            "solver_seconds": float(solver_seconds),
            "total_seconds": float(time.perf_counter() - started),
            "aggregate_only": bool(aggregate_only),
        }
        logger.info(
            "Simulación completada mode=%s aggregate_only=%s rows=%s solver_s=%.3f total_s=%.3f",
            mode,
            aggregate_only,
            metadata["rows_processed"],
            metadata["solver_seconds"],
            metadata["total_seconds"],
        )
        return SimulationResult(kpis=kpis, hourly_detail=hourly_detail, metadata=metadata, logs=logs)

    def _build_fast_kpis(self, annual_acc: dict[str, float], periods: int, days: int, config: ScenarioConfig) -> dict[str, Any]:
        """Construye KPIs compactos para simulación rápida sin detalle horario."""
        total_savings = float(annual_acc["savings"])
        rough_capex = max(config.battery.capacity_kwh * 350.0, 1.0)
        total_pv = float(annual_acc["pv"])
        pv_self = float(annual_acc["pv_direct"] + annual_acc["pv_to_batt"])
        autoconsumo_pct = 0.0 if total_pv <= 1e-9 else (pv_self / total_pv) * 100.0
        cycles_est = float(annual_acc["batt_discharge"]) / max(config.battery.capacity_kwh, 1e-9)
        roi = total_savings / rough_capex
        kpis = {
            "status": "ok",
            "rows_processed": int(periods),
            "days_simulated": int(days),
            "ahorro_total": total_savings,
            "ROI_estimado": float(roi),
            "energia_cargada_kwh": float(annual_acc["batt_charge"]),
            "energia_descargada_kwh": float(annual_acc["batt_discharge"]),
            "autoconsumo_pct": float(autoconsumo_pct),
            "ciclos_estimados": float(cycles_est),
            "total_cost_base_eur": float(annual_acc["cost_base"]),
            "total_cost_bess_eur": float(annual_acc["cost_bess"]),
            "total_savings_eur": total_savings,
            "total_grid_import_kwh": float(annual_acc["grid_import"]),
            "total_grid_export_kwh": float(annual_acc["grid_export"]),
            "solver_lp_days": int(days),
        }
        self._attach_financial_kpis(kpis=kpis, annual_savings=total_savings, config=config)
        return kpis

    def _safe_float(self, value: float) -> float:
        return float(value) if np.isfinite(value) else 0.0

    def optimize_day(
        self,
        day_arrays: _DayArrays,
        soc_start: float,
        config: ScenarioConfig,
        solver: _DailySolverAdapter | None = None,
    ) -> tuple[dict[str, np.ndarray], str]:
        """Optimiza un día específico y valida clamps de SoC tras resolver.

        Entradas:
            day_arrays: Vectores diarios de consumo/FV/precios.
            soc_start: SoC inicial en kWh para el primer periodo del día.
            config: Escenario de simulación utilizado para límites físicos.
            solver: Adaptador opcional para reutilizar instancia del solver.

        Salidas:
            Tupla (resultado_día, modo_solver) con arrays energéticos por periodo.

        Restricciones:
            Aplica clamp final de seguridad para asegurar SoC en límites.

        Errores relevantes:
            AssertionError: Si tras clamps persiste una violación de límites.
        """
        day_solver = solver or _DailySolverAdapter(scenario=config)
        result, mode = day_solver.solve(day=day_arrays, soc_start=soc_start)
        soc_min = config.battery.capacity_kwh * config.battery.soc_min_pct / 100.0
        soc_max = config.battery.capacity_kwh
        result["soc"] = np.clip(result["soc"], soc_min, soc_max)
        if not np.all(result["soc"] >= soc_min - 1e-6):
            raise SimulationError("SoC por debajo del mínimo tras optimización diaria.")
        if not np.all(result["soc"] <= soc_max + 1e-6):
            raise SimulationError("SoC por encima del máximo tras optimización diaria.")
        return result, mode

    def simulate_year_ml(self, df_norm: pd.DataFrame, config: ScenarioConfig, ml_model_bundle: dict[str, Any]) -> ResultsBundleDTO:
        """Simula el año usando un imitador ML y capa explícita de seguridad física.

        Entradas:
            df_norm: DataFrame de entrada normalizado a 15 minutos.
            config: Configuración de batería/tarifa/red usada por el safety layer.
            ml_model_bundle: Bundle con modelos entrenados y metadata de features.

        Salidas:
            ResultsBundleDTO comparable con el modo óptimo tradicional.

        Errores relevantes:
            ValueError: Si faltan columnas requeridas o el bundle de modelo es inválido.
        """
        required_columns = {"timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"}
        missing = required_columns - set(df_norm.columns)
        if missing:
            raise ValueError(f"Faltan columnas para simular ML: {sorted(missing)}")

        payload = ml_model_bundle.get("payload", ml_model_bundle)
        feature_columns = payload.get("feature_columns")
        if not feature_columns:
            raise ValueError("El modelo ML no incluye feature_columns.")

        classifier = payload.get("classifier")
        charge_model = payload.get("charge_model")
        discharge_model = payload.get("discharge_model")
        mode = payload.get("mode", "classification")

        df = df_norm.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df = df.sort_values("timestamp").reset_index(drop=True)
        df["day"] = df["timestamp"].dt.date
        day_prices = df.groupby("day")["buy_eur_kwh"].apply(list).to_dict()

        eta_c = config.battery.charge_efficiency
        eta_d = config.battery.discharge_efficiency
        soc_min = config.battery.capacity_kwh * config.battery.soc_min_pct / 100.0
        soc_max = config.battery.capacity_kwh
        e_step_max = config.battery.power_kw * (config.timestep_minutes / 60.0)

        soc = config.battery.capacity_kwh * config.battery.soc_initial_pct / 100.0
        rows = []
        start = time.perf_counter()

        for idx, row in df.iterrows():
            ts = row["timestamp"]
            current_day = row["day"]
            prices_day = day_prices.get(current_day, [float(row["buy_eur_kwh"])])
            day_index = int((ts.hour * 60 + ts.minute) / config.timestep_minutes)
            future_prices = prices_day[day_index + 1 : day_index + 17]
            if not future_prices:
                future_prices = [float(row["buy_eur_kwh"])]

            feature_row = pd.DataFrame(
                [
                    {
                        "soc": float(soc),
                        "load_kwh": float(row["load_kwh"]),
                        "pv_kwh": float(row["pv_kwh"]),
                        "buy_eur_kwh": float(row["buy_eur_kwh"]),
                        "sell_eur_kwh": float(row["sell_eur_kwh"]),
                        "hour": int(ts.hour),
                        "month": int(ts.month),
                        "dayofweek": int(ts.dayofweek),
                        "min_price_next_4h": float(np.min(future_prices)),
                        "max_price_next_4h": float(np.max(future_prices)),
                        "mean_price_next_4h": float(np.mean(future_prices)),
                        "rank_price_day": float(pd.Series(prices_day).rank(pct=True).iloc[min(day_index, len(prices_day) - 1)]),
                    }
                ]
            )
            x = feature_row[feature_columns]

            pred_charge = 0.0
            pred_discharge = 0.0
            pred_action = "idle"

            if mode == "regression" and charge_model is not None and discharge_model is not None:
                pred_charge = float(max(0.0, charge_model.predict(x)[0]))
                pred_discharge = float(max(0.0, discharge_model.predict(x)[0]))
            elif classifier is not None:
                pred_action = str(classifier.predict(x)[0])
                if pred_action == "charge":
                    pred_charge = e_step_max
                elif pred_action == "discharge":
                    pred_discharge = e_step_max
            elif charge_model is not None and discharge_model is not None:
                pred_charge = float(max(0.0, charge_model.predict(x)[0]))
                pred_discharge = float(max(0.0, discharge_model.predict(x)[0]))

            if pred_charge > 0 and pred_discharge > 0:
                if float(row["buy_eur_kwh"]) >= float(np.mean(future_prices)):
                    pred_charge = 0.0
                else:
                    pred_discharge = 0.0

            pv_to_load = min(float(row["pv_kwh"]), float(row["load_kwh"]))
            pv_left = max(0.0, float(row["pv_kwh"]) - pv_to_load)
            load_left = max(0.0, float(row["load_kwh"]) - pv_to_load)

            safe_charge = min(pred_charge, e_step_max, max(0.0, (soc_max - soc) / eta_c))
            pv_to_batt = min(pv_left, safe_charge)
            pv_left -= pv_to_batt
            grid_to_batt = safe_charge - pv_to_batt
            if not config.grid.allow_grid_charging:
                grid_to_batt = 0.0

            safe_discharge = min(pred_discharge, e_step_max, max(0.0, (soc - soc_min) * eta_d))
            batt_to_load = min(load_left, safe_discharge)
            batt_to_grid = safe_discharge - batt_to_load if config.tariff.allow_sell else 0.0
            load_left -= batt_to_load

            grid_to_load = max(0.0, load_left)
            if config.grid.grid_import_limit_kw is not None:
                grid_limit = config.grid.grid_import_limit_kw * (config.timestep_minutes / 60.0)
                grid_to_batt = min(grid_to_batt, max(0.0, grid_limit - grid_to_load))
                grid_to_load = min(grid_to_load, grid_limit)

            pv_to_grid = pv_left if config.tariff.allow_sell else 0.0
            soc_next = soc + eta_c * (pv_to_batt + grid_to_batt) - (batt_to_load + batt_to_grid) / eta_d
            soc_next = float(np.clip(soc_next, soc_min, soc_max))

            net_base = float(row["load_kwh"]) - float(row["pv_kwh"])
            base_import = max(0.0, net_base)
            base_export = max(0.0, -net_base) if config.tariff.allow_sell else 0.0
            grid_import = grid_to_load + grid_to_batt
            grid_export = pv_to_grid + batt_to_grid

            rows.append(
                {
                    "timestamp": ts,
                    "load": float(row["load_kwh"]),
                    "pv": float(row["pv_kwh"]),
                    "buy_price": float(row["buy_eur_kwh"]),
                    "sell_price": float(row["sell_eur_kwh"]),
                    "soc_start": float(soc),
                    "soc_end": soc_next,
                    "grid_import": grid_import,
                    "grid_export": grid_export,
                    "batt_charge": pv_to_batt + grid_to_batt,
                    "batt_discharge": batt_to_load + batt_to_grid,
                    "pv_used_load": pv_to_load,
                    "pv_used_batt": pv_to_batt,
                    "cost_base": float(row["buy_eur_kwh"]) * base_import - float(row["sell_eur_kwh"]) * base_export,
                    "cost_bess": float(row["buy_eur_kwh"]) * grid_import - float(row["sell_eur_kwh"]) * grid_export,
                    "savings": (float(row["buy_eur_kwh"]) * base_import - float(row["sell_eur_kwh"]) * base_export)
                    - (float(row["buy_eur_kwh"]) * grid_import - float(row["sell_eur_kwh"]) * grid_export),
                }
            )
            soc = soc_next

        results_df = pd.DataFrame(rows)
        kpis = self._build_kpis(results_df=results_df, solver_modes={"ml_fast": int(df["day"].nunique())}, config=config)
        kpis["mode"] = "ml_fast"
        kpis["execution_seconds"] = float(time.perf_counter() - start)
        return ResultsBundleDTO(scenario=config, series=results_df, kpis=kpis, logs=["Simulación ML completada."])

    def _build_kpis(self, results_df: pd.DataFrame, solver_modes: dict[str, int], config: ScenarioConfig) -> dict[str, Any]:
        """Construye KPIs globales y agregados diarios/mensuales/anuales.

        Entradas:
            results_df: DataFrame por periodo generado por la simulación.
            solver_modes: Conteo de días resueltos por tipo de solver.

        Salidas:
            Diccionario con KPIs escalares y DataFrames agregados.

        Errores relevantes:
            No aplica; opera sobre dataframe ya consistente.
        """
        work = results_df.copy()
        work["date"] = pd.to_datetime(work["timestamp"]).dt.date
        work["month"] = pd.to_datetime(work["timestamp"]).dt.to_period("M").astype(str)
        work["year"] = pd.to_datetime(work["timestamp"]).dt.year

        totals = {
            "status": "ok",
            "rows_processed": int(len(work)),
            "days_simulated": int(work["date"].nunique()),
            "total_cost_base_eur": float(work["cost_base"].sum()),
            "total_cost_bess_eur": float(work["cost_bess"].sum()),
            "total_savings_eur": float(work["savings"].sum()),
            "total_grid_import_kwh": float(work["grid_import"].sum()),
            "total_grid_export_kwh": float(work["grid_export"].sum()),
            "solver_lp_days": int(solver_modes.get("lp_scipy", 0)),
        }

        daily = (
            work.groupby("date", as_index=False)
            .agg(
                cost_base=("cost_base", "sum"),
                cost_bess=("cost_bess", "sum"),
                savings=("savings", "sum"),
                grid_import=("grid_import", "sum"),
                grid_export=("grid_export", "sum"),
            )
            .sort_values("date")
        )
        monthly = (
            work.groupby("month", as_index=False)
            .agg(
                cost_base=("cost_base", "sum"),
                cost_bess=("cost_bess", "sum"),
                savings=("savings", "sum"),
                grid_import=("grid_import", "sum"),
                grid_export=("grid_export", "sum"),
            )
            .sort_values("month")
        )
        annual = (
            work.groupby("year", as_index=False)
            .agg(
                cost_base=("cost_base", "sum"),
                cost_bess=("cost_bess", "sum"),
                savings=("savings", "sum"),
                grid_import=("grid_import", "sum"),
                grid_export=("grid_export", "sum"),
            )
            .sort_values("year")
        )

        kpis = {
            **totals,
            "daily": daily,
            "monthly": monthly,
            "annual": annual,
        }
        self._attach_financial_kpis(kpis=kpis, annual_savings=float(totals["total_savings_eur"]), config=config)
        return kpis

    def _attach_financial_kpis(self, *, kpis: dict[str, Any], annual_savings: float, config: ScenarioConfig) -> None:
        capex = float(kpis.get("capex_eur", max(config.battery.capacity_kwh * 350.0, 1e-9)))
        lifetime_years = int(kpis.get("lifetime_years", self.default_lifetime_years))
        annual_opex = float(kpis.get("annual_opex_eur", self.default_annual_opex))
        discount_rate = float(kpis.get("discount_rate", self.default_discount_rate))
        degradation_rate = float(kpis.get("degradation_rate", self.default_degradation_rate))

        if capex <= 0:
            raise ValueError("capex debe ser mayor que 0 para calcular KPIs financieros.")
        if lifetime_years < 1:
            raise ValueError("lifetime_years debe ser mayor o igual que 1.")
        if discount_rate <= -0.9:
            raise ValueError("discount_rate debe ser mayor que -0.9.")

        cashflow = build_cashflow(
            capex=capex,
            annual_savings=annual_savings,
            annual_opex=annual_opex,
            lifetime_years=lifetime_years,
            degradation_rate=degradation_rate,
        )
        kpis.update(
            {
                "capex_eur": float(capex),
                "annual_opex_eur": float(annual_opex),
                "discount_rate": float(discount_rate),
                "lifetime_years": int(lifetime_years),
                "degradation_rate": float(degradation_rate),
                "annual_cashflow": [float(item) for item in cashflow],
                "npv": float(npv(discount_rate, cashflow)),
                "irr": irr(cashflow),
                "payback_years": payback_simple(cashflow),
                "payback_discounted_years": payback_discounted(discount_rate, cashflow),
                "roi": float(roi_total(cashflow)),
            }
        )
