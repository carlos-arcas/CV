"""Utilidades de dataset para aprendizaje por imitación del despacho óptimo."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from application.dto import InputDataDTO
from application.engine import SimulationEngine
from domain.models import ScenarioConfig


@dataclass(slots=True)
class TimewiseSplit:
    """Partición temporal de entrenamiento/prueba sin mezcla aleatoria."""

    train_df: pd.DataFrame
    test_df: pd.DataFrame
    feature_columns: list[str]
    label_columns: list[str]


def build_features(df_periodos: pd.DataFrame, horizon_periods: int = 16, only_within_day: bool = True) -> pd.DataFrame:
    """Construye variables explicativas para aprender la política óptima.

    Entradas:
        df_periodos: DataFrame temporal con columnas canónicas de simulación.
        horizon_periods: Número de periodos de futuro a considerar (16=4h a 15 min).
        only_within_day: Si True, las estadísticas futuras no cruzan al día siguiente.

    Salidas:
        DataFrame con columnas de features por periodo.

    Errores relevantes:
        ValueError: Si faltan columnas obligatorias para construir features.
    """
    required = {"timestamp", "load_kwh", "pv_kwh", "buy_eur_kwh", "sell_eur_kwh"}
    missing = required - set(df_periodos.columns)
    if missing:
        raise ValueError(f"Faltan columnas para features: {sorted(missing)}")

    df = df_periodos.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)
    df["day"] = df["timestamp"].dt.date

    prices = df["buy_eur_kwh"].to_numpy(dtype=float)
    days = df["day"].to_numpy()
    mins = np.zeros(len(df), dtype=float)
    maxs = np.zeros(len(df), dtype=float)
    means = np.zeros(len(df), dtype=float)

    for idx in range(len(df)):
        end = min(len(df), idx + horizon_periods + 1)
        window = prices[idx + 1 : end]
        if only_within_day:
            same_day_mask = days[idx + 1 : end] == days[idx]
            window = window[same_day_mask]
        if window.size == 0:
            window = np.array([prices[idx]], dtype=float)
        mins[idx] = float(np.min(window))
        maxs[idx] = float(np.max(window))
        means[idx] = float(np.mean(window))

    rank_price_day = df.groupby("day")["buy_eur_kwh"].rank(pct=True)

    return pd.DataFrame(
        {
            "timestamp": df["timestamp"],
            "load_kwh": df["load_kwh"].astype(float),
            "pv_kwh": df["pv_kwh"].astype(float),
            "buy_eur_kwh": df["buy_eur_kwh"].astype(float),
            "sell_eur_kwh": df["sell_eur_kwh"].astype(float),
            "hour": df["timestamp"].dt.hour.astype(int),
            "month": df["timestamp"].dt.month.astype(int),
            "dayofweek": df["timestamp"].dt.dayofweek.astype(int),
            "min_price_next_4h": mins,
            "max_price_next_4h": maxs,
            "mean_price_next_4h": means,
            "rank_price_day": rank_price_day.astype(float),
        }
    )


def build_labels_from_optimal(results_df: pd.DataFrame, eps: float = 1e-3) -> pd.DataFrame:
    """Deriva etiquetas supervisadas a partir de la simulación del profesor óptimo.

    Entradas:
        results_df: DataFrame de resultados por periodo del motor óptimo.
        eps: Umbral mínimo para considerar carga/descarga distinta de cero.

    Salidas:
        DataFrame con etiquetas de clasificación y regresión.

    Errores relevantes:
        ValueError: Si faltan columnas de energía de batería en resultados.
    """
    required = {"batt_charge", "batt_discharge", "timestamp"}
    missing = required - set(results_df.columns)
    if missing:
        raise ValueError(f"Faltan columnas para labels: {sorted(missing)}")

    charge = results_df["batt_charge"].astype(float).to_numpy()
    discharge = results_df["batt_discharge"].astype(float).to_numpy()

    actions = np.full(len(results_df), "idle", dtype=object)
    actions[charge > eps] = "charge"
    actions[discharge > eps] = "discharge"
    # si ambos activos, prioriza mayor energía
    both = (charge > eps) & (discharge > eps)
    actions[both] = np.where(charge[both] >= discharge[both], "charge", "discharge")

    return pd.DataFrame(
        {
            "timestamp": pd.to_datetime(results_df["timestamp"]),
            "action": actions,
            "charge_kwh_opt": charge,
            "discharge_kwh_opt": discharge,
        }
    )


def create_imitation_dataset(
    df_norm: pd.DataFrame,
    config: ScenarioConfig,
    teacher_mode: str = "optimal",
    horizon_periods: int = 16,
) -> pd.DataFrame:
    """Genera dataset de imitación ejecutando el profesor y uniendo X + y.

    Entradas:
        df_norm: DataFrame normalizado de entrada (15 minutos).
        config: Escenario para ejecutar el motor profesor.
        teacher_mode: Modo de profesor; por ahora admite `optimal`.
        horizon_periods: Ventana futura para estadísticas de precio.

    Salidas:
        DataFrame temporal con features y etiquetas óptimas.

    Errores relevantes:
        ValueError: Si se indica un teacher_mode no soportado.
    """
    if teacher_mode != "optimal":
        raise ValueError("teacher_mode no soportado. Usa 'optimal'.")

    feature_df = build_features(df_norm, horizon_periods=horizon_periods, only_within_day=True)
    teacher_result = SimulationEngine().run(InputDataDTO(dataframe=df_norm, source_path="teacher", warnings=[]), config)
    labels_df = build_labels_from_optimal(teacher_result.series)

    feature_soc = teacher_result.series[["timestamp", "soc_start"]].rename(columns={"soc_start": "soc"})
    merged = feature_df.merge(feature_soc, on="timestamp", how="left").merge(labels_df, on="timestamp", how="left")
    merged["year"] = pd.to_datetime(merged["timestamp"]).dt.year.astype(int)
    return merged


def create_imitation_dataset_multi(inputs: list[InputDataDTO], config: ScenarioConfig) -> pd.DataFrame:
    """Genera y concatena datasets de imitación para múltiples años.

    Entradas:
        inputs: Lista de datasets normalizados (cada elemento puede representar un año).
        config: Escenario base usado para ejecutar el profesor óptimo.

    Salidas:
        DataFrame único con todas las filas de todos los años, incluyendo columna `year`.

    Errores relevantes:
        ValueError: Si la lista está vacía o algún dataset no contiene filas.
    """
    if not inputs:
        raise ValueError("Debe existir al menos un dataset para generar el dataset multi-año.")

    frames: list[pd.DataFrame] = []
    for input_dto in inputs:
        if input_dto.dataframe.empty:
            raise ValueError(f"El dataset '{input_dto.source_path}' no contiene filas.")
        yearly = create_imitation_dataset(input_dto.dataframe, config=config, teacher_mode="optimal")
        yearly["source_path"] = input_dto.source_path
        frames.append(yearly)

    dataset = pd.concat(frames, ignore_index=True)
    return dataset.sort_values("timestamp").reset_index(drop=True)


def split_by_year(dataset_df: pd.DataFrame, test_years: list[int]) -> TimewiseSplit:
    """Divide dataset en train/test sin fuga temporal usando años de test.

    Entradas:
        dataset_df: Dataset completo con columna `timestamp` y etiquetas.
        test_years: Años reservados para evaluación (ej. [2025]).

    Salidas:
        TimewiseSplit con train/test separados por año.

    Errores relevantes:
        ValueError: Si el dataset está vacío, no contiene años de test o train.
    """
    if dataset_df.empty:
        raise ValueError("No se puede dividir un dataset vacío.")
    if not test_years:
        raise ValueError("Debes indicar al menos un año de test.")

    ordered = dataset_df.sort_values("timestamp").reset_index(drop=True).copy()
    if "year" not in ordered.columns:
        ordered["year"] = pd.to_datetime(ordered["timestamp"]).dt.year.astype(int)

    test_mask = ordered["year"].isin(test_years)
    train_df = ordered.loc[~test_mask].copy()
    test_df = ordered.loc[test_mask].copy()
    if train_df.empty:
        raise ValueError("El split por años dejó train vacío.")
    if test_df.empty:
        raise ValueError("El split por años dejó test vacío; revisa test_years.")

    label_columns = ["action", "charge_kwh_opt", "discharge_kwh_opt"]
    feature_columns = [
        "soc",
        "load_kwh",
        "pv_kwh",
        "buy_eur_kwh",
        "sell_eur_kwh",
        "hour",
        "month",
        "dayofweek",
        "min_price_next_4h",
        "max_price_next_4h",
        "mean_price_next_4h",
        "rank_price_day",
    ]
    return TimewiseSplit(
        train_df=train_df,
        test_df=test_df,
        feature_columns=feature_columns,
        label_columns=label_columns,
    )


def split_train_test_timewise(dataset_df: pd.DataFrame, test_ratio: float = 0.2) -> TimewiseSplit:
    """Divide dataset en train/test respetando el orden temporal.

    Entradas:
        dataset_df: Dataset completo con timestamp, features y labels.
        test_ratio: Proporción final para test (sin mezclar filas).

    Salidas:
        TimewiseSplit con dataframes train/test y metadatos de columnas.

    Errores relevantes:
        ValueError: Si el dataset está vacío o test_ratio es inválido.
    """
    if dataset_df.empty:
        raise ValueError("No se puede dividir un dataset vacío.")
    if not 0 < test_ratio < 1:
        raise ValueError("test_ratio debe estar entre 0 y 1.")

    ordered = dataset_df.sort_values("timestamp").reset_index(drop=True)
    split_idx = int(len(ordered) * (1 - test_ratio))
    split_idx = max(1, min(split_idx, len(ordered) - 1))

    label_columns = ["action", "charge_kwh_opt", "discharge_kwh_opt"]
    feature_columns = [
        "soc",
        "load_kwh",
        "pv_kwh",
        "buy_eur_kwh",
        "sell_eur_kwh",
        "hour",
        "month",
        "dayofweek",
        "min_price_next_4h",
        "max_price_next_4h",
        "mean_price_next_4h",
        "rank_price_day",
    ]

    return TimewiseSplit(
        train_df=ordered.iloc[:split_idx].copy(),
        test_df=ordered.iloc[split_idx:].copy(),
        feature_columns=feature_columns,
        label_columns=label_columns,
    )
