"""Entidades de aplicación para encapsular artefactos de modelos ML."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ModelBundle:
    """Bundle tipado con modelos de acción/carga/descarga y metadata."""

    action_model: Any
    charge_model: Any
    discharge_model: Any
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_payload(self) -> dict[str, Any]:
        """Convierte el bundle a payload serializable para ejecución en engine."""
        return {
            "classifier": self.action_model,
            "charge_model": self.charge_model,
            "discharge_model": self.discharge_model,
            **self.metadata,
        }
