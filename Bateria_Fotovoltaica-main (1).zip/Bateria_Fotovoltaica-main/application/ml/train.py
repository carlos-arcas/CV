"""Entrenamiento y evaluación de modelos de imitación supervisada."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

try:  # pragma: no cover - depende entorno
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.metrics import classification_report, mean_absolute_error

    SKLEARN_AVAILABLE = True
except Exception:  # pragma: no cover
    RandomForestClassifier = None
    RandomForestRegressor = None
    classification_report = None
    mean_absolute_error = None
    SKLEARN_AVAILABLE = False


def train_action_classifier(X_train: pd.DataFrame, y_train: pd.Series) -> Any:
    """Entrena un clasificador base para acción {charge, discharge, idle}.

    Entradas:
        X_train: Features de entrenamiento.
        y_train: Etiqueta categórica de acción óptima.

    Salidas:
        Modelo entrenado (RandomForestClassifier).

    Errores relevantes:
        RuntimeError: Si scikit-learn no está disponible en el entorno.
    """
    if not SKLEARN_AVAILABLE:
        raise RuntimeError("instala scikit-learn para modo ML")
    model = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    return model


def train_charge_discharge_regressors(
    X_train: pd.DataFrame,
    y_charge: pd.Series,
    y_discharge: pd.Series,
) -> dict[str, Any]:
    """Entrena regresores para estimar energía de carga y descarga óptima.

    Entradas:
        X_train: Features de entrenamiento.
        y_charge: Objetivo continuo `charge_kwh_opt`.
        y_discharge: Objetivo continuo `discharge_kwh_opt`.

    Salidas:
        Diccionario con dos modelos RandomForestRegressor.

    Errores relevantes:
        RuntimeError: Si scikit-learn no está disponible en el entorno.
    """
    if not SKLEARN_AVAILABLE:
        raise RuntimeError("instala scikit-learn para modo ML")

    charge_model = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
    discharge_model = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
    charge_model.fit(X_train, y_charge)
    discharge_model.fit(X_train, y_discharge)
    return {"charge_model": charge_model, "discharge_model": discharge_model}


def evaluate_models(
    classifier: Any,
    regressors: dict[str, Any],
    X_test: pd.DataFrame,
    y_action: pd.Series,
    y_charge: pd.Series,
    y_discharge: pd.Series,
) -> dict[str, Any]:
    """Evalúa modelos de clasificación y regresión sobre conjunto temporal de test.

    Entradas:
        classifier: Modelo de clasificación entrenado.
        regressors: Diccionario con modelos de carga/descarga.
        X_test: Features de evaluación.
        y_action: Etiquetas reales de acción.
        y_charge: Valores reales de carga óptima.
        y_discharge: Valores reales de descarga óptima.

    Salidas:
        Diccionario de métricas (classification report + MAE regresores).

    Errores relevantes:
        RuntimeError: Si scikit-learn no está disponible en el entorno.
    """
    if not SKLEARN_AVAILABLE:
        raise RuntimeError("instala scikit-learn para modo ML")

    pred_action = classifier.predict(X_test)
    pred_charge = np.clip(regressors["charge_model"].predict(X_test), 0.0, None)
    pred_discharge = np.clip(regressors["discharge_model"].predict(X_test), 0.0, None)

    return {
        "classification_report": classification_report(y_action, pred_action, output_dict=True, zero_division=0),
        "mae_charge": float(mean_absolute_error(y_charge, pred_charge)),
        "mae_discharge": float(mean_absolute_error(y_discharge, pred_discharge)),
    }


def evaluate_models_by_year(
    classifier: Any,
    regressors: dict[str, Any],
    test_df: pd.DataFrame,
    feature_columns: list[str],
) -> dict[str, dict[str, Any]]:
    """Calcula métricas de clasificación/regresión desagregadas por año.

    Entradas:
        classifier: Clasificador de acciones ya entrenado.
        regressors: Diccionario con modelos de carga y descarga entrenados.
        test_df: DataFrame de test que contiene `year` y etiquetas reales.
        feature_columns: Columnas de entrada utilizadas por los modelos.

    Salidas:
        Diccionario indexado por año con métricas homogéneas.

    Errores relevantes:
        RuntimeError: Si scikit-learn no está disponible en el entorno.
        ValueError: Si el DataFrame de test está vacío.
    """
    if not SKLEARN_AVAILABLE:
        raise RuntimeError("instala scikit-learn para modo ML")
    if test_df.empty:
        raise ValueError("No se puede evaluar por año con test vacío.")

    work_df = test_df.copy()
    if "year" not in work_df.columns:
        work_df["year"] = pd.to_datetime(work_df["timestamp"]).dt.year.astype(int)

    metrics_by_year: dict[str, dict[str, Any]] = {}
    for year, year_df in work_df.groupby("year"):
        X_year = year_df[feature_columns]
        metrics_by_year[str(int(year))] = evaluate_models(
            classifier=classifier,
            regressors=regressors,
            X_test=X_year,
            y_action=year_df["action"],
            y_charge=year_df["charge_kwh_opt"],
            y_discharge=year_df["discharge_kwh_opt"],
        )
    return metrics_by_year
