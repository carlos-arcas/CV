"""Motor de estrategias comerciales para recomendar cuota de renting."""

from __future__ import annotations

from dataclasses import dataclass

from application.finance.finance_calculations import compute_monthly_payment_amortization


@dataclass(slots=True)
class OfferResult:
    """Resultado comercial de una estrategia de oferta de renting.

    Propósito comercial:
        Estandarizar cómo se comunica una propuesta al cliente y al equipo de ventas,
        mostrando el equilibrio entre cuota sugerida, beneficio del cliente y margen
        esperado para la empresa.
    """

    strategy: str
    parameters: dict[str, float]
    cuota_recomendada: float
    ahorro_cliente_mensual: float
    margen_total_empresa: float
    margen_mensual_empresa: float
    payback_equivalente_cliente: float | None


def _compute_base_fee(inversion_total: float, plazo_meses: int, coste_capital_anual: float) -> float:
    if inversion_total < 0:
        raise ValueError("inversion_total no puede ser negativo.")
    if plazo_meses <= 0:
        raise ValueError("plazo_meses debe ser mayor que 0.")
    if coste_capital_anual < 0:
        raise ValueError("coste_capital_anual no puede ser negativo.")
    base_fee, _ = compute_monthly_payment_amortization(
        principal_eur=inversion_total,
        annual_interest_pct=coste_capital_anual,
        term_months=plazo_meses,
    )
    return float(base_fee)


def _build_offer_result(
    strategy: str,
    cuota_recomendada: float,
    ahorro_mensual: float,
    base_fee: float,
    plazo_meses: int,
    parameters: dict[str, float],
) -> OfferResult:
    cuota = max(0.0, float(cuota_recomendada))
    ahorro_cliente = float(ahorro_mensual - cuota)
    margen_mensual = float(cuota - base_fee)
    margen_total = float(margen_mensual * plazo_meses)
    payback = None
    if ahorro_mensual > 0:
        payback = float((cuota * plazo_meses) / (ahorro_mensual * 12.0))
    return OfferResult(
        strategy=strategy,
        parameters=parameters,
        cuota_recomendada=cuota,
        ahorro_cliente_mensual=ahorro_cliente,
        margen_total_empresa=margen_total,
        margen_mensual_empresa=margen_mensual,
        payback_equivalente_cliente=payback,
    )


def compute_offer_by_savings_ratio(
    inversion_total: float,
    ahorro_mensual: float,
    plazo_meses: int,
    coste_capital_anual: float,
    max_fee_ratio: float,
    margen_base: float = 0.0,
) -> OfferResult:
    """Prioriza cierre comercial fijando una cuota ligada al ahorro mensual del cliente."""
    if not 0 <= max_fee_ratio <= 1:
        raise ValueError("max_fee_ratio debe estar entre 0 y 1.")
    if margen_base < 0:
        raise ValueError("margen_base no puede ser negativo.")

    base_fee = _compute_base_fee(inversion_total, plazo_meses, coste_capital_anual)
    cuota_objetivo = ahorro_mensual * max_fee_ratio
    cuota = max(0.0, cuota_objetivo)
    return _build_offer_result(
        strategy="Cuota atractiva para cerrar",
        cuota_recomendada=cuota,
        ahorro_mensual=ahorro_mensual,
        base_fee=base_fee,
        plazo_meses=plazo_meses,
        parameters={"max_fee_ratio": max_fee_ratio, "margen_base": margen_base},
    )


def compute_offer_by_payback(
    inversion_total: float,
    ahorro_mensual: float,
    plazo_meses: int,
    coste_capital_anual: float,
    target_payback_years: float,
    margen_base: float = 0.0,
) -> OfferResult:
    """Ajusta la cuota para que la propuesta cumpla un payback objetivo del cliente."""
    if target_payback_years <= 0:
        raise ValueError("target_payback_years debe ser mayor que 0.")
    if margen_base < 0:
        raise ValueError("margen_base no puede ser negativo.")

    base_fee = _compute_base_fee(inversion_total, plazo_meses, coste_capital_anual)
    cuota_max_payback = ahorro_mensual * target_payback_years * 12.0 / plazo_meses

    low, high = 0.0, max(0.0, cuota_max_payback)
    for _ in range(80):
        mid = (low + high) / 2.0
        payback_mid = (mid * plazo_meses) / (ahorro_mensual * 12.0) if ahorro_mensual > 0 else float("inf")
        if payback_mid <= target_payback_years:
            low = mid
        else:
            high = mid
    cuota = max(0.0, low)
    return _build_offer_result(
        strategy="Payback cliente <= N años",
        cuota_recomendada=cuota,
        ahorro_mensual=ahorro_mensual,
        base_fee=base_fee,
        plazo_meses=plazo_meses,
        parameters={"target_payback_years": target_payback_years, "margen_base": margen_base},
    )


def compute_offer_max_margin(
    inversion_total: float,
    ahorro_mensual: float,
    plazo_meses: int,
    coste_capital_anual: float,
    min_customer_savings_eur: float = 0.0,
    min_customer_savings_ratio: float = 0.0,
    margen_base: float = 0.0,
) -> OfferResult:
    """Maximiza margen manteniendo un beneficio mínimo para el cliente cada mes."""
    if min_customer_savings_eur < 0:
        raise ValueError("min_customer_savings_eur no puede ser negativo.")
    if not 0 <= min_customer_savings_ratio <= 1:
        raise ValueError("min_customer_savings_ratio debe estar entre 0 y 1.")
    if margen_base < 0:
        raise ValueError("margen_base no puede ser negativo.")

    base_fee = _compute_base_fee(inversion_total, plazo_meses, coste_capital_anual)
    ahorro_minimo = max(min_customer_savings_eur, ahorro_mensual * min_customer_savings_ratio)
    cuota_maxima = max(0.0, ahorro_mensual - ahorro_minimo)
    cuota = max(0.0, cuota_maxima)
    return _build_offer_result(
        strategy="Maximizar margen",
        cuota_recomendada=cuota,
        ahorro_mensual=ahorro_mensual,
        base_fee=base_fee,
        plazo_meses=plazo_meses,
        parameters={
            "min_customer_savings_eur": min_customer_savings_eur,
            "min_customer_savings_ratio": min_customer_savings_ratio,
            "margen_base": margen_base,
        },
    )


def compute_offer_balanced(
    inversion_total: float,
    ahorro_mensual: float,
    plazo_meses: int,
    coste_capital_anual: float,
    target_payback_years: float,
    max_fee_ratio: float,
    margen_base: float = 0.0,
) -> OfferResult:
    """Equilibra cierre y rentabilidad maximizando cuota bajo límites de cliente."""
    if target_payback_years <= 0:
        raise ValueError("target_payback_years debe ser mayor que 0.")
    if not 0 <= max_fee_ratio <= 1:
        raise ValueError("max_fee_ratio debe estar entre 0 y 1.")
    if margen_base < 0:
        raise ValueError("margen_base no puede ser negativo.")

    base_fee = _compute_base_fee(inversion_total, plazo_meses, coste_capital_anual)
    cuota_limite_payback = ahorro_mensual * target_payback_years * 12.0 / plazo_meses
    cuota_limite_ratio = ahorro_mensual * max_fee_ratio
    cuota_maxima = min(cuota_limite_payback, cuota_limite_ratio)
    cuota = max(0.0, cuota_maxima)

    return _build_offer_result(
        strategy="Equilibrada",
        cuota_recomendada=cuota,
        ahorro_mensual=ahorro_mensual,
        base_fee=base_fee,
        plazo_meses=plazo_meses,
        parameters={"target_payback_years": target_payback_years, "max_fee_ratio": max_fee_ratio, "margen_base": margen_base},
    )
