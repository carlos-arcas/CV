"""Funciones puras de cálculo financiero para escenarios BESS."""

from __future__ import annotations

from typing import Iterable


from domain.finance_models import FinancialScenario, RentalParams


def compute_simple_payback(investment_eur: float, annual_savings_eur: float) -> float | None:
    """Calcula el payback simple en años para una inversión de compra.

    Entradas:
        investment_eur: Inversión total inicial en EUR.
        annual_savings_eur: Ahorro anual esperado en EUR.

    Salidas:
        Años de retorno simple o None si no existe retorno.

    Supuestos:
        No se descuentan flujos ni se modela degradación.

    Errores relevantes:
        ValueError: Si investment_eur es negativo.
    """
    if investment_eur < 0:
        raise ValueError("investment_eur no puede ser negativo.")
    if annual_savings_eur <= 0:
        return None
    return investment_eur / annual_savings_eur


def compute_roi(annual_net_savings_eur: float, investment_eur: float) -> float | None:
    """Calcula ROI anual simple como ahorro neto anual dividido entre inversión.

    Entradas:
        annual_net_savings_eur: Ahorro anual neto (ahorro - OPEX) en EUR.
        investment_eur: Inversión inicial total en EUR.

    Salidas:
        ROI anual en formato decimal (0.15 = 15%) o None si inversión no válida.

    Supuestos:
        ROI estático de un año, sin efecto fiscal.

    Errores relevantes:
        ValueError: Si investment_eur es negativo.
    """
    if investment_eur < 0:
        raise ValueError("investment_eur no puede ser negativo.")
    if investment_eur == 0:
        return None
    return annual_net_savings_eur / investment_eur


def compute_npv(initial_investment_eur: float, annual_cashflows_eur: Iterable[float], discount_rate_annual: float) -> float:
    """Calcula VAN/NPV de una secuencia anual de flujos.

    Entradas:
        initial_investment_eur: Desembolso inicial en EUR (valor positivo).
        annual_cashflows_eur: Flujos anuales esperados en EUR.
        discount_rate_annual: Tasa de descuento anual en formato decimal [0, +inf).

    Salidas:
        VAN en EUR (puede ser negativo).

    Supuestos:
        Flujos ocurren al cierre de cada año y la inversión ocurre en t=0.

    Errores relevantes:
        ValueError: Si inversión o tasa son negativas.
    """
    if initial_investment_eur < 0:
        raise ValueError("initial_investment_eur no puede ser negativo.")
    if discount_rate_annual < 0:
        raise ValueError("discount_rate_annual no puede ser negativo.")
    npv = -initial_investment_eur
    for idx, cashflow in enumerate(annual_cashflows_eur, start=1):
        npv += float(cashflow) / ((1 + discount_rate_annual) ** idx)
    return float(npv)


def compute_monthly_payment_amortization(principal_eur: float, annual_interest_pct: float, term_months: int) -> tuple[float, list[dict[str, float | int]]]:
    """Calcula cuota mensual y tabla de amortización francesa para un préstamo.

    Entradas:
        principal_eur: Principal financiado en EUR.
        annual_interest_pct: Interés nominal anual en porcentaje.
        term_months: Número total de cuotas mensuales.

    Salidas:
        Tupla con cuota mensual fija y lista de filas de amortización mensual.

    Supuestos:
        Sistema francés con interés mensual constante y pagos al final de cada mes.

    Errores relevantes:
        ValueError: Si principal es negativo, plazo inválido o interés negativo.
    """
    if principal_eur < 0:
        raise ValueError("principal_eur no puede ser negativo.")
    if annual_interest_pct < 0:
        raise ValueError("annual_interest_pct no puede ser negativo.")
    if term_months <= 0:
        raise ValueError("term_months debe ser mayor que 0.")

    monthly_rate = (annual_interest_pct / 100.0) / 12.0
    if monthly_rate == 0:
        payment = principal_eur / term_months if term_months else 0.0
    else:
        factor = (1 + monthly_rate) ** term_months
        payment = principal_eur * monthly_rate * factor / (factor - 1)

    balance = principal_eur
    schedule: list[dict[str, float | int]] = []
    for month in range(1, term_months + 1):
        interest = balance * monthly_rate
        principal = payment - interest
        if month == term_months:
            principal = balance
            payment_month = principal + interest
        else:
            payment_month = payment
        balance = max(0.0, balance - principal)
        schedule.append(
            {
                "month": month,
                "payment_eur": float(payment_month),
                "interest_eur": float(interest),
                "principal_eur": float(principal),
                "remaining_balance_eur": float(balance),
            }
        )
    return float(payment), schedule


def compute_rental_quote(capex_total_eur: float, rental_params: RentalParams) -> dict[str, float]:
    """Calcula cuota de renting con coste de capital interno y margen comercial.

    Entradas:
        capex_total_eur: CAPEX a recuperar por la empresa en EUR.
        rental_params: Parámetros de renting (plazo, tasa interna, margen, residual).

    Salidas:
        Diccionario con cuota base, cuota cliente y márgenes total/mensual.

    Supuestos:
        La cuota base se calcula con fórmula de anualidad mensual, descontando valor residual.

    Errores relevantes:
        ValueError: Si capex_total_eur es negativo.
    """
    if capex_total_eur < 0:
        raise ValueError("capex_total_eur no puede ser negativo.")

    residual_value = capex_total_eur * (rental_params.residual_value_pct / 100.0)
    principal_to_recover = max(0.0, capex_total_eur - residual_value)
    base_fee, _ = compute_monthly_payment_amortization(
        principal_eur=principal_to_recover,
        annual_interest_pct=rental_params.annual_cost_of_capital_pct,
        term_months=rental_params.term_months,
    )
    if rental_params.minimum_monthly_fee_eur is not None:
        base_fee = max(base_fee, rental_params.minimum_monthly_fee_eur)

    customer_fee = base_fee * (1 + rental_params.margin_pct / 100.0)
    monthly_margin = customer_fee - base_fee
    total_margin = monthly_margin * rental_params.term_months
    return {
        "base_fee_eur": float(base_fee),
        "customer_fee_eur": float(customer_fee),
        "monthly_margin_eur": float(monthly_margin),
        "total_margin_eur": float(total_margin),
    }


def build_financial_scenarios(
    annual_savings_eur: float,
    scenarios: list[FinancialScenario] | None = None,
) -> list[dict[str, float | str]]:
    """Construye escenarios conservador/base/optimista con multiplicadores configurables.

    Entradas:
        annual_savings_eur: Ahorro anual de referencia del motor energético.
        scenarios: Lista opcional de escenarios con nombre y multiplicador.

    Salidas:
        Lista serializable de escenarios con ahorro ajustado.

    Supuestos:
        Si no se pasa configuración se usan multiplicadores 0.85/1.0/1.15.

    Errores relevantes:
        No aplica; función tolerante para ahorro cero/negativo.
    """
    config = scenarios or [
        FinancialScenario(name="conservador", savings_multiplier=0.85),
        FinancialScenario(name="base", savings_multiplier=1.0),
        FinancialScenario(name="optimista", savings_multiplier=1.15),
    ]
    return [
        {
            "scenario": item.name,
            "multiplier": float(item.savings_multiplier),
            "annual_savings_eur": float(annual_savings_eur * item.savings_multiplier),
        }
        for item in config
    ]


def compute_irr(initial_investment_eur: float, cashflows: Iterable[float]) -> float | None:
    """Calcula TIR/IRR anual con búsqueda binaria sobre el VAN.

    Entradas:
        initial_investment_eur: Inversión inicial positiva en EUR.
        cashflows: Flujos periódicos (anuales) positivos/negativos.

    Salidas:
        TIR en formato decimal o None si no converge en el rango evaluado.

    Supuestos:
        Periodicidad homogénea y único desembolso inicial en t=0.

    Errores relevantes:
        ValueError: Si initial_investment_eur es negativo.
    """
    if initial_investment_eur < 0:
        raise ValueError("initial_investment_eur no puede ser negativo.")

    values = [float(x) for x in cashflows]

    def _npv(rate: float) -> float:
        return compute_npv(initial_investment_eur, values, rate)

    low, high = -0.99, 5.0
    low_val, high_val = _npv(low), _npv(high)
    if low_val == 0:
        return low
    if high_val == 0:
        return high
    if low_val * high_val > 0:
        return None

    for _ in range(120):
        mid = (low + high) / 2
        mid_val = _npv(mid)
        if abs(mid_val) < 1e-6:
            return float(mid)
        if low_val * mid_val < 0:
            high, high_val = mid, mid_val
        else:
            low, low_val = mid, mid_val
    return float((low + high) / 2)
