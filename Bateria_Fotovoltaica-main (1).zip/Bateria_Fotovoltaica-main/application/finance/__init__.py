"""Submódulo de finanzas para análisis CAPEX/OPEX y renting."""
