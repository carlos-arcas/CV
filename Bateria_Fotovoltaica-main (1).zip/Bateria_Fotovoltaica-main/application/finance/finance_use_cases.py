"""Casos de uso para ejecutar análisis financiero sobre resultados energéticos."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from application.dto import ResultsBundleDTO
from application.finance.finance_calculations import (
    build_financial_scenarios,
    compute_irr,
    compute_monthly_payment_amortization,
    compute_npv,
    compute_roi,
    compute_rental_quote,
    compute_simple_payback,
)
from application.finance.offer_strategy import (
    OfferResult,
    compute_offer_balanced,
    compute_offer_by_payback,
    compute_offer_by_savings_ratio,
    compute_offer_max_margin,
)
from domain.finance_models import CapexParams, FinancialResults, FinancingParams, OpexParams, RentalParams


@dataclass(slots=True)
class RunFinancialAnalysisUseCase:
    """Orquesta cálculo de KPIs financieros sin recalcular energía."""

    def execute(
        self,
        results: ResultsBundleDTO,
        capacity_kwh: float,
        power_kw: float,
        capex_params: CapexParams,
        opex_params: OpexParams,
        financing_params: FinancingParams,
        rental_params: RentalParams,
        discount_rate_annual: float = 0.08,
        horizon_years: int = 10,
    ) -> FinancialResults:
        """Calcula compra, préstamo, renting y escenarios de sensibilidad.

        Entradas:
            results: Bundle energético con ahorro anual/mensual pre-calculado.
            capacity_kwh: Capacidad de batería usada para CAPEX.
            power_kw: Potencia de batería usada para CAPEX.
            capex_params: Configuración de costes de inversión.
            opex_params: Configuración de coste operativo anual.
            financing_params: Parámetros de préstamo.
            rental_params: Parámetros de renting con margen.
            discount_rate_annual: Tasa anual para VAN/TIR.
            horizon_years: Horizonte en años para VAN/TIR.

        Salidas:
            FinancialResults con resumen y tabla de amortización.

        Supuestos:
            El ahorro proviene del motor energético y se ajusta solo por OPEX financiero.

        Errores relevantes:
            ValueError: Si horizonte o parámetros económicos son inválidos.
        """
        if horizon_years <= 0:
            raise ValueError("horizon_years debe ser mayor que 0.")
        if discount_rate_annual < 0:
            raise ValueError("discount_rate_annual no puede ser negativo.")

        annual_savings = float(results.kpis.get("total_savings_eur", 0.0))
        monthly_savings = self._extract_monthly_savings(results)

        capex_total = (
            capacity_kwh * capex_params.battery_cost_eur_per_kwh
            + power_kw * capex_params.inverter_cost_eur_per_kw
            + capex_params.installation_fixed_cost_eur
        )
        annual_net_savings = annual_savings - opex_params.annual_maintenance_eur
        payback_years = compute_simple_payback(capex_total, annual_net_savings)
        roi_annual = compute_roi(annual_net_savings, capex_total)

        annual_cashflows = [annual_net_savings for _ in range(horizon_years)]
        npv_eur = compute_npv(capex_total, annual_cashflows, discount_rate_annual)
        _ = compute_irr(capex_total, annual_cashflows)

        principal = max(0.0, capex_total - financing_params.down_payment_eur)
        loan_payment, amortization = compute_monthly_payment_amortization(
            principal_eur=principal,
            annual_interest_pct=financing_params.annual_interest_pct,
            term_months=financing_params.term_months,
        )
        loan_payback_month = self._compute_financed_payback_month(monthly_savings, loan_payment, principal)

        rental_quote = compute_rental_quote(capex_total, rental_params)
        avg_monthly_saving = (sum(monthly_savings) / len(monthly_savings)) if monthly_savings else annual_savings / 12.0
        customer_monthly_benefit = avg_monthly_saving - rental_quote["customer_fee_eur"]

        scenarios = build_financial_scenarios(annual_net_savings)
        return FinancialResults(
            annual_savings_eur=annual_savings,
            monthly_savings_eur=monthly_savings,
            capex_total_eur=float(capex_total),
            purchase_payback_years=payback_years,
            purchase_roi_annual=roi_annual,
            npv_eur=float(npv_eur),
            loan_monthly_payment_eur=float(loan_payment),
            loan_payback_month=loan_payback_month,
            rental_base_fee_eur=rental_quote["base_fee_eur"],
            rental_customer_fee_eur=rental_quote["customer_fee_eur"],
            rental_total_margin_eur=rental_quote["total_margin_eur"],
            rental_monthly_margin_eur=rental_quote["monthly_margin_eur"],
            customer_monthly_benefit_eur=float(customer_monthly_benefit),
            scenarios=scenarios,
            amortization_schedule=amortization,
        )

    def _extract_monthly_savings(self, results: ResultsBundleDTO) -> list[float]:
        monthly = results.kpis.get("monthly")
        if isinstance(monthly, pd.DataFrame) and not monthly.empty and "savings" in monthly.columns:
            return [float(value) for value in monthly["savings"].tolist()]
        return [float(results.kpis.get("total_savings_eur", 0.0) / 12.0)] * 12

    def _compute_financed_payback_month(self, monthly_savings: list[float], payment_eur: float, principal_eur: float) -> int | None:
        cum = -principal_eur
        if not monthly_savings:
            return None
        horizon = max(240, len(monthly_savings) * 20)
        for month in range(1, horizon + 1):
            saving = monthly_savings[(month - 1) % len(monthly_savings)]
            cum += saving - payment_eur
            if cum > 0:
                return month
        return None


@dataclass(slots=True)
class RunOfferOptimizationUseCase:
    """Orquesta estrategias comerciales para recomendar cuota de oferta."""

    def execute(
        self,
        strategy: str,
        inversion_total: float,
        ahorro_mensual: float,
        plazo_meses: int,
        coste_capital_anual: float,
        max_fee_ratio: float = 0.8,
        target_payback_years: float = 6.0,
        min_customer_savings_eur: float = 10.0,
        min_customer_savings_ratio: float = 0.0,
        margen_base: float = 0.0,
    ) -> OfferResult:
        """Calcula la cuota recomendada según estrategia elegida por ventas."""
        if strategy == "Cuota atractiva para cerrar":
            return compute_offer_by_savings_ratio(
                inversion_total=inversion_total,
                ahorro_mensual=ahorro_mensual,
                plazo_meses=plazo_meses,
                coste_capital_anual=coste_capital_anual,
                max_fee_ratio=max_fee_ratio,
                margen_base=margen_base,
            )
        if strategy == "Payback cliente <= N años":
            return compute_offer_by_payback(
                inversion_total=inversion_total,
                ahorro_mensual=ahorro_mensual,
                plazo_meses=plazo_meses,
                coste_capital_anual=coste_capital_anual,
                target_payback_years=target_payback_years,
                margen_base=margen_base,
            )
        if strategy == "Maximizar margen":
            return compute_offer_max_margin(
                inversion_total=inversion_total,
                ahorro_mensual=ahorro_mensual,
                plazo_meses=plazo_meses,
                coste_capital_anual=coste_capital_anual,
                min_customer_savings_eur=min_customer_savings_eur,
                min_customer_savings_ratio=min_customer_savings_ratio,
                margen_base=margen_base,
            )
        if strategy == "Equilibrada":
            return compute_offer_balanced(
                inversion_total=inversion_total,
                ahorro_mensual=ahorro_mensual,
                plazo_meses=plazo_meses,
                coste_capital_anual=coste_capital_anual,
                target_payback_years=target_payback_years,
                max_fee_ratio=max_fee_ratio,
                margen_base=margen_base,
            )
        raise ValueError(f"Estrategia no soportada: {strategy}")
