"""KPIs financieros para transformar ahorro técnico en argumento comercial."""

from __future__ import annotations


def build_cashflow(
    *,
    capex: float,
    annual_savings: float,
    annual_opex: float,
    lifetime_years: int,
    degradation_rate: float = 0.0,
) -> list[float]:
    """Construye flujo anual con inversión en t=0 y ahorro neto degradado."""
    if capex <= 0:
        raise ValueError("capex debe ser mayor que 0.")
    if lifetime_years < 1:
        raise ValueError("lifetime_years debe ser mayor o igual que 1.")

    values = [-float(capex)]
    for year in range(1, lifetime_years + 1):
        gross_savings = float(annual_savings) * ((1.0 - float(degradation_rate)) ** (year - 1))
        values.append(gross_savings - float(annual_opex))
    return values


def npv(rate: float, cashflows: list[float]) -> float:
    """Calcula VAN descontando cada flujo por su año."""
    if rate <= -0.9:
        raise ValueError("rate debe ser mayor que -0.9.")
    return float(sum(cf / ((1.0 + rate) ** idx) for idx, cf in enumerate(cashflows)))


def _d_npv(rate: float, cashflows: list[float]) -> float:
    """Derivada de VAN para Newton-Raphson."""
    total = 0.0
    for idx, cf in enumerate(cashflows[1:], start=1):
        total += -idx * cf / ((1.0 + rate) ** (idx + 1))
    return float(total)


def irr(cashflows: list[float], *, guess: float = 0.1, tol: float = 1e-6, max_iter: int = 100) -> float | None:
    """Calcula TIR con Newton-Raphson y fallback robusto binario."""
    if len(cashflows) < 2:
        return None
    has_pos = any(cf > 0 for cf in cashflows)
    has_neg = any(cf < 0 for cf in cashflows)
    if not (has_pos and has_neg):
        return None

    rate = guess
    for _ in range(max_iter):
        if rate <= -0.9:
            break
        try:
            f_val = npv(rate, cashflows)
            if abs(f_val) <= tol:
                return float(rate)
            df_val = _d_npv(rate, cashflows)
            if abs(df_val) < 1e-12:
                break
            next_rate = rate - (f_val / df_val)
            if not (-0.9 < next_rate < 10.0):
                break
            if abs(next_rate - rate) <= tol:
                return float(next_rate)
            rate = next_rate
        except Exception:
            break

    low, high = -0.9, 1.0
    try:
        low_v = npv(low, cashflows)
        high_v = npv(high, cashflows)
        expand = 0
        while low_v * high_v > 0 and high < 10.0 and expand < 25:
            high = min(10.0, high * 1.8 + 0.2)
            high_v = npv(high, cashflows)
            expand += 1
        if low_v * high_v > 0:
            return None
        for _ in range(max_iter * 2):
            mid = (low + high) / 2.0
            mid_v = npv(mid, cashflows)
            if abs(mid_v) <= tol:
                return float(mid)
            if low_v * mid_v <= 0:
                high, high_v = mid, mid_v
            else:
                low, low_v = mid, mid_v
        return float((low + high) / 2.0)
    except Exception:
        return None


def payback_simple(cashflows: list[float]) -> float | None:
    """Devuelve año fraccionario en que el acumulado no descontado cruza cero."""
    if not cashflows:
        return None
    acc = float(cashflows[0])
    if acc >= 0:
        return 0.0
    for year, flow in enumerate(cashflows[1:], start=1):
        prev = acc
        acc += float(flow)
        if acc >= 0:
            if flow == 0:
                return float(year)
            fraction = -prev / float(flow)
            return float((year - 1) + max(0.0, min(1.0, fraction)))
    return None


def payback_discounted(rate: float, cashflows: list[float]) -> float | None:
    """Devuelve payback fraccionario usando flujos descontados."""
    if rate <= -0.9:
        raise ValueError("rate debe ser mayor que -0.9.")
    discounted = [cf / ((1.0 + rate) ** idx) for idx, cf in enumerate(cashflows)]
    return payback_simple([float(item) for item in discounted])


def roi_total(cashflows: list[float]) -> float:
    """ROI total acumulado: beneficio neto total dividido por inversión inicial."""
    if not cashflows:
        raise ValueError("cashflows no puede estar vacío.")
    initial_investment = -float(cashflows[0])
    if initial_investment <= 0:
        raise ValueError("El flujo inicial debe representar una inversión negativa.")
    total_benefit = float(sum(cashflows[1:])) - initial_investment
    return total_benefit / initial_investment
