"""Casos de uso de aplicación para carga, validación y simulación."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import logging
import time

import pandas as pd

from infrastructure.io.cache_store import CacheStore, build_cache_key, hash_dataframe
from infrastructure.profiling.timer import log_timed

from application.dto import InputDataDTO, InputDatasetCollectionDTO, ResultsBundleDTO
from application.engine import SimulationEngine
from application.ml.dataset import create_imitation_dataset, create_imitation_dataset_multi, split_by_year, split_train_test_timewise
from application.ml.train import (
    SKLEARN_AVAILABLE,
    evaluate_models,
    evaluate_models_by_year,
    train_action_classifier,
    train_charge_discharge_regressors,
)
from domain.models import ScenarioConfig, SimulationMode
from application.ml.model_bundle import ModelBundle
from infrastructure.persistence.model_store import load_model_bundle, save_model_bundle
from infrastructure.io.excel_reader import read_tabular
from application.dataset_validator import validate_dataset
from application.errors import DatasetValidationError
from infrastructure.validators import normalize_timestep_15min

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class LoadDatasetUseCase:
    """Caso de uso para cargar datasets desde CSV/XLSX a DataFrame.

    Entradas:
        file_path: Ruta local de archivo de entrada.

    Salidas:
        InputDataDTO con dataframe original y advertencias vacías.

    Errores relevantes:
        ValueError: Si la ruta no existe o extensión no soportada.
    """

    def execute(self, file_path: str) -> InputDataDTO:
        """Carga un archivo tabular a DataFrame y empaqueta el resultado.

        Entradas:
            file_path: Ruta del archivo CSV o Excel.

        Salidas:
            InputDataDTO listo para etapas de validación.

        Errores relevantes:
            OSError, ValueError: Propagados por la capa de infraestructura.
        """
        logger.info("Cargando dataset desde %s", file_path)
        df, dataset_hash = read_tabular(file_path)
        logger.info("Dataset hash sha256=%s", dataset_hash)
        return InputDataDTO(dataframe=df, source_path=file_path, warnings=[], dataset_hash=dataset_hash)


@dataclass(slots=True)
class LoadDatasetCollectionUseCase:
    """Carga múltiples archivos tabulares y devuelve una colección de DTOs."""

    def execute(self, file_paths: list[str]) -> InputDatasetCollectionDTO:
        """Carga una lista de archivos y preserva trazabilidad por ruta.

        Entradas:
            file_paths: Rutas de archivos CSV/XLSX seleccionados por el usuario.

        Salidas:
            Colección con un DTO por archivo cargado.

        Errores relevantes:
            ValueError: Si no se proporciona ninguna ruta.
        """
        if not file_paths:
            raise ValueError("Debes seleccionar al menos un archivo.")
        loader = LoadDatasetUseCase()
        return InputDatasetCollectionDTO(datasets=[loader.execute(path) for path in file_paths])


@dataclass(slots=True)
class ValidateAndNormalizeCollectionUseCase:
    """Valida y normaliza en lote una colección de datasets multi-año."""

    def execute(self, collection: InputDatasetCollectionDTO) -> InputDatasetCollectionDTO:
        """Aplica validación/escalado temporal a cada dataset de la colección.

        Entradas:
            collection: Colección cruda de datasets por archivo.

        Salidas:
            Colección normalizada en resolución de 15 minutos.

        Errores relevantes:
            ValueError: Si la colección está vacía.
        """
        if not collection.datasets:
            raise ValueError("No hay datasets para normalizar.")
        normalizer = ValidateAndNormalizeUseCase()
        return InputDatasetCollectionDTO(datasets=[normalizer.execute(item) for item in collection.datasets])


@dataclass(slots=True)
class ValidateAndNormalizeUseCase:
    """Caso de uso para validar esquema y normalizar a 15 minutos.

    Entradas:
        input_dto: Datos de entrada cargados.

    Salidas:
        InputDataDTO con contrato canónico y advertencias.

    Errores relevantes:
        DataSchemaError o ValidationError ante datos inválidos.
    """

    strict_warnings: bool = False

    def execute(self, input_dto: InputDataDTO) -> InputDataDTO:
        """Ejecuta validación de esquema y normalización temporal del dataset.

        Entradas:
            input_dto: DTO con dataframe aún no normalizado.

        Salidas:
            DTO actualizado con dataframe normalizado y advertencias.

        Errores relevantes:
            DataSchemaError: Si faltan columnas requeridas.
            ValidationError: Si hay huecos temporales o frecuencia no soportada.
        """
        logger.info("Validando dataset de entrada antes de normalizar.")
        report = validate_dataset(input_dto.dataframe, expected_step_minutes=15)
        if (not report.ok) or (self.strict_warnings and report.warnings):
            raise DatasetValidationError(report.to_text(), report)

        logger.info("Normalizando dataset a resolución de 15 minutos.")
        normalized_df, normalization_warnings = normalize_timestep_15min(input_dto.dataframe)
        warnings = [item.message for item in report.warnings]
        return InputDataDTO(
            dataframe=normalized_df,
            source_path=input_dto.source_path,
            warnings=[*input_dto.warnings, *warnings, *normalization_warnings],
            dataset_hash=input_dto.dataset_hash,
        )


@dataclass(slots=True)
class RunSimulationUseCase:
    """Caso de uso para ejecutar una simulación de extremo a extremo.

    Entradas:
        engine: Motor de simulación inyectado.

    Salidas:
        ResultsBundleDTO con estructura de resultados final.

    Errores relevantes:
        ValueError: Si faltan datos o configuración mínima.
    """

    engine: SimulationEngine

    def execute(
        self,
        input_dto: InputDataDTO,
        scenario: ScenarioConfig,
        *,
        include_detail: bool = True,
        use_cache: bool = True,
        cache_store: CacheStore | None = None,
        debug_mode: bool = False,
        mode: SimulationMode = SimulationMode.OPTIMAL,
    ) -> ResultsBundleDTO:
        """Lanza la simulación usando el engine configurado."""
        logger.info("Ejecutando simulación para el archivo %s", input_dto.source_path)
        logger.info("Config simulación: battery=%s tariff=%s grid=%s", scenario.battery, scenario.tariff, scenario.grid)
        dataset_hash = input_dto.dataset_hash or hash_dataframe(input_dto.dataframe)
        cache_key: str | None = None
        if use_cache and cache_store is not None:
            cache_key = build_cache_key(dataset_hash, scenario, include_detail=include_detail, mode=mode)
            cached = cache_store.get(cache_key)
            if cached is not None:
                logger.info("Cache hit de simulación: %s", cache_key)
                return cached

        with log_timed(logger, "run_simulation"):
            results = self.engine.simulate_year(
                df_norm=input_dto.dataframe,
                config=scenario,
                include_period_detail=include_detail,
                debug_mode=debug_mode,
                mode=mode,
            )
        if use_cache and cache_store is not None and cache_key is not None:
            cache_store.put(cache_key, results)
        return results


@dataclass(slots=True)
class GenerateDatasetUseCase:
    """Genera dataset de imitación a partir del motor óptimo y lo persiste."""

    def execute(self, input_dto: InputDataDTO, scenario: ScenarioConfig, output_path: str) -> pd.DataFrame:
        """Genera dataset para un único archivo normalizado."""
        dataset = create_imitation_dataset(input_dto.dataframe, scenario, teacher_mode="optimal")
        if output_path.endswith(".parquet"):
            dataset.to_parquet(output_path, index=False)
        else:
            dataset.to_csv(output_path, index=False)
        return dataset

    def execute_multi(
        self,
        inputs: InputDatasetCollectionDTO,
        scenario: ScenarioConfig,
        output_path: str,
    ) -> pd.DataFrame:
        """Genera y persiste un dataset multi-año concatenando varios archivos.

        Entradas:
            inputs: Colección de datasets normalizados por archivo/año.
            scenario: Escenario del profesor óptimo.
            output_path: Ruta de salida CSV o Parquet del dataset resultante.

        Salidas:
            DataFrame unificado para entrenamiento ML robusto.

        Errores relevantes:
            ValueError: Si no hay datasets en la colección.
        """
        dataset = create_imitation_dataset_multi(inputs.datasets, scenario)
        if output_path.endswith(".parquet"):
            dataset.to_parquet(output_path, index=False)
        else:
            dataset.to_csv(output_path, index=False)
        return dataset


@dataclass(slots=True)
class TrainImitatorUseCase:
    """Entrena clasificador/regresores de imitación y guarda artefactos."""

    def execute(
        self,
        dataset_df: pd.DataFrame,
        model_output_path: str,
        mode: str = "classification",
        test_years: list[int] | None = None,
    ) -> dict:
        if not SKLEARN_AVAILABLE:
            return {"status": "skipped", "message": "instala scikit-learn para modo ML"}

        split = split_by_year(dataset_df, test_years=test_years) if test_years else split_train_test_timewise(dataset_df)
        X_train = split.train_df[split.feature_columns]
        X_test = split.test_df[split.feature_columns]
        y_train_action = split.train_df["action"]
        y_test_action = split.test_df["action"]
        y_train_charge = split.train_df["charge_kwh_opt"]
        y_test_charge = split.test_df["charge_kwh_opt"]
        y_train_discharge = split.train_df["discharge_kwh_opt"]
        y_test_discharge = split.test_df["discharge_kwh_opt"]

        classifier = train_action_classifier(X_train, y_train_action)
        regressors = train_charge_discharge_regressors(X_train, y_train_charge, y_train_discharge)
        metrics = evaluate_models(
            classifier=classifier,
            regressors=regressors,
            X_test=X_test,
            y_action=y_test_action,
            y_charge=y_test_charge,
            y_discharge=y_test_discharge,
        )
        metrics_by_year = evaluate_models_by_year(
            classifier=classifier,
            regressors=regressors,
            test_df=split.test_df,
            feature_columns=split.feature_columns,
        )
        years_used = sorted(pd.to_datetime(dataset_df["timestamp"]).dt.year.astype(int).unique().tolist())
        metadata = {
            "mode": mode,
            "feature_columns": split.feature_columns,
            "trained_at": datetime.utcnow().isoformat(),
            "metrics": metrics,
            "metrics_by_year": metrics_by_year,
            "years_used": years_used,
            "total_rows": int(len(dataset_df)),
            "test_years": sorted(test_years) if test_years else sorted(pd.to_datetime(split.test_df["timestamp"]).dt.year.astype(int).unique().tolist()),
            "app_version": "1.0.0",
            "schema_version": 1,
        }
        bundle = ModelBundle(
            action_model=classifier,
            charge_model=regressors["charge_model"],
            discharge_model=regressors["discharge_model"],
            metadata=metadata,
        )
        save_model_bundle(bundle, model_output_path)
        return {
            "status": "ok",
            "metrics": metrics,
            "metrics_by_year": metrics_by_year,
            "years_used": years_used,
            "total_rows": int(len(dataset_df)),
            "path": model_output_path,
            "trained_at": metadata["trained_at"],
            "feature_columns": split.feature_columns,
        }


@dataclass(slots=True)
class RunSimulationFastUseCase:
    """Ejecuta simulación rápida basada en modelo ML previamente entrenado."""

    engine: SimulationEngine

    def execute(self, input_dto: InputDataDTO, scenario: ScenarioConfig, model_path: str) -> ResultsBundleDTO:
        if not SKLEARN_AVAILABLE:
            raise RuntimeError("instala scikit-learn para modo ML")
        model_bundle = load_model_bundle(model_path)
        payload = model_bundle.to_payload()
        return self.engine.simulate_year_ml(input_dto.dataframe, scenario, payload)


@dataclass(slots=True)
class CompareSimulationsUseCase:
    """Compara ejecución óptima vs rápida ML con KPIs de error/tiempo."""

    engine: SimulationEngine

    def execute(self, input_dto: InputDataDTO, scenario: ScenarioConfig, model_path: str) -> dict:
        start_opt = time.perf_counter()
        optimal = self.engine.run(input_dto, scenario)
        t_opt = time.perf_counter() - start_opt

        fast_uc = RunSimulationFastUseCase(engine=self.engine)
        start_ml = time.perf_counter()
        ml = fast_uc.execute(input_dto, scenario, model_path)
        t_ml = time.perf_counter() - start_ml

        ahorro_optimo = float(optimal.kpis.get("total_savings_eur", 0.0))
        ahorro_ml = float(ml.kpis.get("total_savings_eur", 0.0))
        delta = ahorro_ml - ahorro_optimo
        delta_pct = 0.0 if abs(ahorro_optimo) < 1e-9 else (delta / ahorro_optimo) * 100.0
        return {
            "optimal": optimal,
            "ml": ml,
            "compare": {
                "ahorro_optimo": ahorro_optimo,
                "ahorro_ml": ahorro_ml,
                "delta_eur": delta,
                "delta_pct": delta_pct,
                "time_opt_s": t_opt,
                "time_ml_s": t_ml,
            },
        }
