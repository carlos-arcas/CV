"""Solver LP diario puro para despacho FV+Batería sin heurísticas.

Modelo matemático (programación lineal):

Variables por periodo ``t``:
    - ``pv_to_load[t]``: energía FV que atiende carga.
    - ``pv_to_batt[t]``: energía FV destinada a carga de batería.
    - ``pv_to_grid[t]``: energía FV exportada a red.
    - ``batt_to_load[t]``: energía descargada de batería hacia carga.
    - ``grid_to_load[t]``: energía importada de red hacia carga.
    - ``soc[t]``: estado de carga al final del periodo.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

from domain.errors import SimulationError
from domain.models import ScenarioConfig


@dataclass(slots=True)
class _LPTemplate:
    idx: dict[str, slice]
    total_vars: int
    a_eq: csr_matrix
    a_ub: csr_matrix | None
    b_ub: np.ndarray | None
    lb: np.ndarray
    ub: np.ndarray


@dataclass(slots=True)
class LPDailySolver:
    """Implementación canónica del solver LP diario."""

    scenario: ScenarioConfig
    sale_price_factor: float = 1.0

    _template_cache: ClassVar[dict[tuple[Any, ...], _LPTemplate]] = {}

    def solve(self, day: Any, soc_start: float) -> dict[str, np.ndarray]:
        n = int(day.load.shape[0])
        template = self._get_template(n)

        c = np.zeros(template.total_vars, dtype=np.float64)
        c[template.idx["grid_to_load"]] = np.asarray(day.buy_price, dtype=np.float64)
        if self.scenario.tariff.allow_sell:
            c[template.idx["pv_to_grid"]] = -np.asarray(day.sell_price, dtype=np.float64) * self.sale_price_factor

        b_eq = np.zeros(3 * n + 1, dtype=np.float64)
        b_eq[0 : 3 * n : 3] = np.asarray(day.load, dtype=np.float64)
        b_eq[1 : 3 * n : 3] = np.asarray(day.pv, dtype=np.float64)
        b_eq[3 * n] = float(soc_start)

        result = linprog(
            c=c,
            A_ub=template.a_ub,
            b_ub=template.b_ub,
            A_eq=template.a_eq,
            b_eq=b_eq,
            bounds=np.column_stack((template.lb, template.ub)),
            method="highs",
            options={
                "presolve": True,
                "primal_feasibility_tolerance": 1e-9,
                "dual_feasibility_tolerance": 1e-9,
            },
        )
        if not result.success:
            raise SimulationError(f"LP diario sin solución óptima: {result.message}")

        x = np.asarray(result.x, dtype=np.float64)
        solution = {name: x[sl] for name, sl in template.idx.items()}
        self._validate_solution(day=day, solution=solution)
        return solution

    def _cache_key(self, n: int) -> tuple[Any, ...]:
        b = self.scenario.battery
        g = self.scenario.grid
        return (
            n,
            b.capacity_kwh,
            b.power_kw,
            b.soc_min_pct,
            b.charge_efficiency,
            b.discharge_efficiency,
            self.scenario.timestep_minutes,
            self.scenario.tariff.allow_sell,
            g.grid_import_limit_kw,
        )

    def _get_template(self, n: int) -> _LPTemplate:
        key = self._cache_key(n)
        template = self._template_cache.get(key)
        if template is None:
            template = self._build_template(n)
            self._template_cache[key] = template
        return template

    def _build_indices(self, n: int) -> dict[str, slice]:
        offset = 0
        idx: dict[str, slice] = {}
        for name in ("pv_to_load", "pv_to_batt", "pv_to_grid", "pv_spill", "batt_to_load", "grid_to_load"):
            idx[name] = slice(offset, offset + n)
            offset += n
        idx["soc"] = slice(offset, offset + n + 1)
        return idx

    def _build_template(self, n: int) -> _LPTemplate:
        idx = self._build_indices(n)
        total_vars = idx["soc"].stop
        eta_c = self.scenario.battery.charge_efficiency
        eta_d = self.scenario.battery.discharge_efficiency

        t = np.arange(n, dtype=np.int64)
        rows = np.concatenate(
            [
                3 * t,
                3 * t,
                3 * t,
                3 * t + 1,
                3 * t + 1,
                3 * t + 1,
                3 * t + 1,
                3 * t + 2,
                3 * t + 2,
                3 * t + 2,
                3 * t + 2,
                np.array([3 * n], dtype=np.int64),
            ]
        )
        cols = np.concatenate(
            [
                idx["pv_to_load"].start + t,
                idx["batt_to_load"].start + t,
                idx["grid_to_load"].start + t,
                idx["pv_to_load"].start + t,
                idx["pv_to_batt"].start + t,
                idx["pv_to_grid"].start + t,
                idx["pv_spill"].start + t,
                idx["soc"].start + t + 1,
                idx["soc"].start + t,
                idx["pv_to_batt"].start + t,
                idx["batt_to_load"].start + t,
                np.array([idx["soc"].start], dtype=np.int64),
            ]
        )
        data = np.concatenate(
            [
                np.ones(3 * n, dtype=np.float64),
                np.ones(4 * n, dtype=np.float64),
                np.ones(n, dtype=np.float64),
                -np.ones(n, dtype=np.float64),
                -eta_c * np.ones(n, dtype=np.float64),
                (1.0 / eta_d) * np.ones(n, dtype=np.float64),
                np.array([1.0], dtype=np.float64),
            ]
        )
        a_eq = csr_matrix((data, (rows, cols)), shape=(3 * n + 1, total_vars), dtype=np.float64)

        e_step_max = self.scenario.battery.power_kw * (self.scenario.timestep_minutes / 60.0)
        ub_rows = [np.arange(n, dtype=np.int64), np.arange(n, 2 * n, dtype=np.int64)]
        ub_cols = [idx["pv_to_batt"].start + t, idx["batt_to_load"].start + t]
        ub_data = [np.ones(n, dtype=np.float64), np.ones(n, dtype=np.float64)]
        b_ub = [np.full(n, e_step_max, dtype=np.float64), np.full(n, e_step_max, dtype=np.float64)]

        if self.scenario.grid.grid_import_limit_kw is not None:
            grid_lim = self.scenario.grid.grid_import_limit_kw * (self.scenario.timestep_minutes / 60.0)
            ub_rows.append(np.arange(2 * n, 3 * n, dtype=np.int64))
            ub_cols.append(idx["grid_to_load"].start + t)
            ub_data.append(np.ones(n, dtype=np.float64))
            b_ub.append(np.full(n, grid_lim, dtype=np.float64))

        rows_ub = np.concatenate(ub_rows)
        cols_ub = np.concatenate(ub_cols)
        data_ub = np.concatenate(ub_data)
        b_ub_arr = np.concatenate(b_ub)
        a_ub = csr_matrix((data_ub, (rows_ub, cols_ub)), shape=(len(b_ub_arr), total_vars), dtype=np.float64)

        soc_min = self.scenario.battery.capacity_kwh * self.scenario.battery.soc_min_pct / 100.0
        soc_max = self.scenario.battery.capacity_kwh
        lb = np.zeros(total_vars, dtype=np.float64)
        ub = np.full(total_vars, np.inf, dtype=np.float64)

        if not self.scenario.tariff.allow_sell:
            ub[idx["pv_to_grid"]] = 0.0

        lb[idx["soc"]] = soc_min
        ub[idx["soc"]] = soc_max

        return _LPTemplate(idx=idx, total_vars=total_vars, a_eq=a_eq, a_ub=a_ub, b_ub=b_ub_arr, lb=lb, ub=ub)

    def _validate_solution(self, day: Any, solution: dict[str, np.ndarray], tol: float = 1e-6) -> None:
        soc_min = self.scenario.battery.capacity_kwh * self.scenario.battery.soc_min_pct / 100.0
        soc_max = self.scenario.battery.capacity_kwh
        eta_c = self.scenario.battery.charge_efficiency
        eta_d = self.scenario.battery.discharge_efficiency

        soc = solution["soc"]
        if np.any(soc < soc_min - tol) or np.any(soc > soc_max + tol):
            raise SimulationError("Validación LP fallida: SoC fuera de límites físicos.")

        for key in ("pv_to_load", "pv_to_batt", "pv_to_grid", "pv_spill", "batt_to_load", "grid_to_load"):
            if np.any(solution[key] < -tol):
                raise SimulationError(f"Validación LP fallida: flujo negativo en {key}.")

        load_balance = solution["pv_to_load"] + solution["batt_to_load"] + solution["grid_to_load"] - day.load
        if np.max(np.abs(load_balance)) > tol:
            raise SimulationError("Validación LP fallida: balance de carga no satisfecho.")

        pv_balance = solution["pv_to_load"] + solution["pv_to_batt"] + solution["pv_to_grid"] + solution["pv_spill"] - day.pv
        if np.max(np.abs(pv_balance)) > tol:
            raise SimulationError("Validación LP fallida: balance FV no satisfecho.")

        soc_dyn = soc[1:] - soc[:-1] - solution["pv_to_batt"] * eta_c + solution["batt_to_load"] / eta_d
        if np.max(np.abs(soc_dyn)) > tol:
            raise SimulationError("Validación LP fallida: dinámica de SoC inconsistente.")
