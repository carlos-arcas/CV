"""Benchmark de performance para simulaciones LP."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from application.engine import SimulationEngine
from domain.models import BatteryParams, GridParams, ScenarioConfig, TariffParams


@dataclass(slots=True)
class PerformanceReport:
    periodos: int
    tiempo_total: float
    tiempo_solver: float
    memoria_estimada: float

    def to_dict(self) -> dict[str, float | int]:
        return {
            "periodos": int(self.periodos),
            "tiempo_total": float(self.tiempo_total),
            "tiempo_solver": float(self.tiempo_solver),
            "memoria_estimada": float(self.memoria_estimada),
        }


def run_benchmark(dataset_path: Path, scenario: ScenarioConfig | None = None) -> PerformanceReport:
    t0 = time.perf_counter()

    load_t0 = time.perf_counter()
    df = pd.read_csv(dataset_path)
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
    load_seconds = time.perf_counter() - load_t0

    scenario = scenario or ScenarioConfig(
        battery=BatteryParams(),
        tariff=TariffParams(allow_sell=True),
        grid=GridParams(allow_grid_charging=False),
    )

    sim_t0 = time.perf_counter()
    result = SimulationEngine().simulate_year(df_norm=df, config=scenario)
    sim_seconds = time.perf_counter() - sim_t0

    timings = result.kpis.get("timings_seconds", {})
    build_seconds = float(timings.get("normalization", 0.0))
    solver_seconds = float(timings.get("solver", 0.0))
    export_seconds = float(timings.get("export", 0.0))

    total_seconds = time.perf_counter() - t0
    memory_est_mb = float(df.memory_usage(index=True, deep=True).sum() / (1024 * 1024))

    print("PerformanceReport")
    print(f"periodos: {len(df)}")
    print(f"tiempo carga datos: {load_seconds:.6f}s")
    print(f"tiempo construcción LP: {build_seconds:.6f}s")
    print(f"tiempo solver: {solver_seconds:.6f}s")
    print(f"tiempo export: {export_seconds:.6f}s")
    print(f"tiempo simulación: {sim_seconds:.6f}s")
    print(f"tiempo total: {total_seconds:.6f}s")
    print(f"memoria estimada: {memory_est_mb:.3f} MB")

    return PerformanceReport(
        periodos=int(len(df)),
        tiempo_total=float(total_seconds),
        tiempo_solver=float(solver_seconds),
        memoria_estimada=float(memory_est_mb),
    )


def write_benchmark_report_json(dataset_path: Path, output_path: Path, scenario: ScenarioConfig | None = None) -> PerformanceReport:
    report = run_benchmark(dataset_path=dataset_path, scenario=scenario)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return report


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Benchmark de performance del motor LP")
    parser.add_argument("dataset", type=Path)
    args = parser.parse_args()
    run_benchmark(args.dataset)
