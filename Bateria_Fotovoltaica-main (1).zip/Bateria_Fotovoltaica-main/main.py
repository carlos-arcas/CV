"""Compatibilidad legacy: delega al CLI empaquetado."""

from fvbess.cli import main

raise SystemExit(main())
