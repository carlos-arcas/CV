"""CLI para operaciones de proyecto (init + batch-run)."""

from __future__ import annotations

import hashlib
import json
import logging
import platform
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

from infrastructure.version import __version__
from application.batch_runner import (
    MAX_GRID_VARIANTS,
    build_battery_grid,
    ensure_batch_structure,
    resolve_metric_key,
    run_batch,
    run_simulation_job,
    scenario_to_dict,
)
from application.engine import SimulationEngine
from application.project_use_cases import LoadProjectUseCase
from application.use_cases import LoadDatasetUseCase, RunSimulationUseCase, ValidateAndNormalizeUseCase
from domain.models import BatteryParams, GridParams, ScenarioConfig, SimulationMode, TariffParams
from domain.models_project import ProjectConfig
from infrastructure.exporters import export_results_to_excel
from infrastructure.io.cache_store import hash_file
from infrastructure.io.simulation_cache import clear_project_cache
from infrastructure.logging.crash_handler import run_with_crash_report
from infrastructure.logging.logging_config import generate_run_id, setup_project_logging, timed_block, write_environment_metadata
from infrastructure.persistence.project_store import load_project, save_project


def init_project(project_dir_arg: str) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    scenario = ScenarioConfig(battery=BatteryParams(), tariff=TariffParams(), grid=GridParams())
    if not (project_dir / "project.json").exists():
        project = ProjectConfig(
            name=project_dir.name,
            data_path="",
            model_folder=str(project_dir / "models"),
            export_folder=str(project_dir / "outputs"),
            scenario=asdict(scenario),
            app_version=__version__,
            schema_version=2,
        )
        save_project(project, str(project_dir))
    ensure_batch_structure(project_dir)
    print(f"Proyecto inicializado: {project_dir}")
    print(f"Entrada batch: {(project_dir / 'batches' / 'input')}")
    return 0


def show_project(project_dir_arg: str) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    try:
        project_config, scenario, _ = load_project(str(project_dir))
    except FileNotFoundError as exc:
        print(f"Error: {exc}")
        print("Tip: ejecuta primero 'fvbess project init <project_dir>'.")
        return 2

    payload = {
        "name": project_config.name,
        "data_path": project_config.data_path,
        "model_folder": project_config.model_folder,
        "export_folder": project_config.export_folder,
        "scenario": scenario,
        "app_version": project_config.app_version,
        "schema_version": project_config.schema_version,
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0


def _scenario_hash(scenario: ScenarioConfig) -> str:
    serialized = json.dumps(scenario_to_dict(scenario), sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _build_environment_context(
    *,
    project_schema_version: int,
    scenario_hash: str,
    dataset_hash: str,
    fast_mode: bool,
    grid_mode: bool,
) -> dict[str, object]:
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "project_schema_version": project_schema_version,
        "scenario_hash": scenario_hash,
        "dataset_hash": dataset_hash,
        "fast_mode": fast_mode,
        "grid_mode": grid_mode,
    }


def run_project(
    project_dir_arg: str,
    fast: bool = False,
    export_detail: bool = False,
    include_executive: bool = True,
    no_cache: bool = False,
) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    try:
        project_config, _, _ = load_project(str(project_dir))
    except FileNotFoundError as exc:
        print(f"Error: {exc}")
        print("Tip: ejecuta primero 'fvbess project init <project_dir>'.")
        return 2

    if not project_config.data_path:
        print("Error: project.json no tiene data_path configurado.")
        return 2

    scenario = LoadProjectUseCase().scenario_from_dict(project_config.scenario)
    source = Path(project_config.data_path).expanduser()
    if not source.exists():
        print(f"Error: dataset no encontrado en {source}")
        return 2

    dataset_hash = hash_file(str(source))
    run_id = generate_run_id(dataset_hash)
    run_dir = setup_project_logging(project_dir, run_id)
    scenario_hash = _scenario_hash(scenario)
    context = _build_environment_context(
        project_schema_version=project_config.schema_version,
        scenario_hash=scenario_hash,
        dataset_hash=dataset_hash,
        fast_mode=fast,
        grid_mode=False,
    )
    write_environment_metadata(run_dir, context)

    def _execute() -> int:
        mode = SimulationMode.FAST if fast else SimulationMode.OPTIMAL
        logging.info("Starting project run run_id=%s dataset=%s mode=%s", run_id, source, mode.value)

        with timed_block("dataset_load_validate_simulation"):
            result_job = run_simulation_job(
                input_path=source,
                scenario=scenario,
                strict_warnings=False,
                mode=mode,
                include_detail=export_detail,
                run_use_case=RunSimulationUseCase(engine=SimulationEngine()),
                load_use_case=LoadDatasetUseCase(),
                normalize_use_case=ValidateAndNormalizeUseCase(),
                project_dir=project_dir,
                use_cache=not no_cache,
            )

        if result_job.error is not None or result_job.results is None:
            logging.error("Error al ejecutar simulación: %s", result_job.error)
            print(f"Error al ejecutar simulación: {result_job.error}")
            return 4 if result_job.error_type == "simulation" else 3

        export_dir = Path(project_config.export_folder).expanduser()
        if not export_dir.is_absolute():
            export_dir = project_dir / export_dir
        export_dir.mkdir(parents=True, exist_ok=True)
        output_path = export_dir / f"{source.stem}__result.xlsx"

        with timed_block("export_results"):
            export_results_to_excel(
                result_job.results,
                str(output_path),
                export_level="full" if export_detail else "kpis_only",
                include_executive=include_executive,
            )

        logging.info("Project run finished run_id=%s export=%s", run_id, output_path)
        print(f"Simulación completada ({mode}). Export: {output_path}")
        return 0

    return run_with_crash_report(_execute, project_dir=project_dir, run_id=run_id, context=context)


def _parse_csv_numbers(raw: str) -> list[float]:
    return [float(item.strip()) for item in raw.split(",") if item.strip()]


def _is_lower_better_metric(metric_key: str) -> bool:
    return metric_key in {"payback_years", "purchase_payback_years", "payback_discounted_years"}


def batch_run_project(
    project_dir_arg: str,
    pattern: str,
    overwrite: bool,
    workers: int,
    strict: bool = False,
    fast: bool = False,
    export_detail: bool = False,
    use_grid: bool = False,
    capacities: str = "",
    powers: str = "",
    metric: str = "roi",
    top_n: int = 3,
    force_grid: bool = False,
    include_executive: bool = True,
    no_cache: bool = False,
) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    ensure_batch_structure(project_dir)

    try:
        project_config, _, _ = load_project(str(project_dir))
    except FileNotFoundError as exc:
        print(f"Error: {exc}")
        print("Tip: ejecuta primero 'fvbess project init <project_dir>'.")
        return 2

    scenario = LoadProjectUseCase().scenario_from_dict(project_config.scenario)
    capacities_override = _parse_csv_numbers(capacities)
    powers_override = _parse_csv_numbers(powers)
    battery_grid = build_battery_grid(
        project_dir=project_dir,
        base_scenario=scenario,
        use_grid=use_grid or bool(capacities_override or powers_override),
        capacities_override=capacities_override,
        powers_override=powers_override,
    )
    if len(battery_grid) > MAX_GRID_VARIANTS and not force_grid:
        print(
            f"Warning: grid de {len(battery_grid)} variantes supera el máximo recomendado ({MAX_GRID_VARIANTS}). "
            "Usa --force-grid o reduce tamaños."
        )
        return 2

    scenario_hash = _scenario_hash(scenario)
    dataset_hash_seed = hashlib.sha256(f"{project_dir}:{pattern}:{scenario_hash}".encode("utf-8")).hexdigest()
    run_id = generate_run_id(dataset_hash_seed)
    run_dir = setup_project_logging(project_dir, run_id)
    context = _build_environment_context(
        project_schema_version=project_config.schema_version,
        scenario_hash=scenario_hash,
        dataset_hash=dataset_hash_seed,
        fast_mode=fast,
        grid_mode=bool(use_grid or capacities_override or powers_override),
    )
    write_environment_metadata(run_dir, context)

    def _execute() -> int:
        logging.info("Starting batch run run_id=%s pattern=%s workers=%s", run_id, pattern, workers)
        with timed_block("batch_run"):
            real_run_id, job_results = run_batch(
                project_dir=project_dir,
                base_scenario=scenario,
                project_schema_version=project_config.schema_version,
                pattern=pattern,
                overwrite=overwrite,
                workers=workers,
                strict_warnings=strict,
                fast=fast,
                export_detail=export_detail,
                battery_grid=battery_grid,
                ranking_metric=metric,
                run_id=run_id,
                include_executive=include_executive,
                use_cache=not no_cache,
            )

        if not job_results:
            print(f"No hay archivos de entrada en {project_dir / 'batches' / 'input'} para pattern='{pattern}'.")
            return 2

        total = len(job_results)
        ok_jobs = [item for item in job_results if item.status == "ok"]
        error_jobs = [item for item in job_results if item.status == "error"]

        print(f"Batch run_id: {real_run_id}")
        print(f"Resumen: total={total} ok={len(ok_jobs)} error={len(error_jobs)}")

        selected_metric = resolve_metric_key(metric, [item.kpis for item in ok_jobs])
        reverse_sort = not _is_lower_better_metric(selected_metric)
        ranked = [item for item in ok_jobs if selected_metric in item.kpis and item.client is not None]
        if ranked:
            print(f"Top {max(1, top_n)} global por {selected_metric}:")
            for row in sorted(ranked, key=lambda item: item.kpis[selected_metric], reverse=reverse_sort)[: max(1, top_n)]:
                print(f"- {row.client} / {row.variant_id}: {row.kpis[selected_metric]:.4f}")

        best_by_client: dict[str, Any] = {}
        for row in ranked:
            prev = best_by_client.get(row.client)
            if prev is None:
                best_by_client[row.client] = row
                continue
            better = row.kpis[selected_metric] < prev.kpis[selected_metric] if not reverse_sort else row.kpis[selected_metric] > prev.kpis[selected_metric]
            if better:
                best_by_client[row.client] = row
        if best_by_client:
            print("Mejor variante por cliente:")
            for client in sorted(best_by_client):
                row = best_by_client[client]
                print(f"- {client}: {row.variant_id} ({selected_metric}={row.kpis[selected_metric]:.4f})")

        run_manifest = project_dir / "batches" / "_runs" / real_run_id / "run_manifest.json"
        if run_manifest.exists():
            summary = json.loads(run_manifest.read_text(encoding="utf-8"))
            print(
                "Totales variantes: "
                f"clientes={summary.get('total_clients', 0)} variantes={summary.get('total_variants', 0)} "
                f"ok={summary.get('ok_variants', 0)} error={summary.get('error_variants', 0)}"
            )

        print(f"Manifests: {project_dir / 'batches' / '_runs' / real_run_id}")

        if ok_jobs:
            return 0
        if error_jobs and all(item.error_type == "validation" for item in error_jobs):
            return 3
        if error_jobs and all(item.error_type in {"simulation", "unsupported", "skipped"} for item in error_jobs):
            return 4
        return 4

    return run_with_crash_report(_execute, project_dir=project_dir, run_id=run_id, context=context)


def cache_clear_project(project_dir_arg: str) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    removed = clear_project_cache(project_dir)
    if removed:
        print(f"Cache eliminada en: {project_dir / 'cache'}")
    else:
        print(f"No existe cache para limpiar en: {project_dir / 'cache'}")
    return 0
