"""Comandos CLI del simulador."""
