from __future__ import annotations

import json
import logging
import statistics
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from application.batch_runner import build_battery_grid, patch_scenario_for_variant
from application.engine import SimulationEngine
from application.project_use_cases import LoadProjectUseCase
from application.use_cases import LoadDatasetUseCase, RunSimulationUseCase, ValidateAndNormalizeUseCase
from domain.models import SimulationMode
from infrastructure.logging.crash_handler import run_with_crash_report
from infrastructure.logging.logging_config import generate_run_id, setup_project_logging, timed_block, write_environment_metadata
from infrastructure.persistence.project_store import load_project


@dataclass(slots=True)
class StageStats:
    mean_sec: float
    std_sec: float
    min_sec: float
    max_sec: float
    total_sec: float


@dataclass(slots=True)
class BenchmarkModeResult:
    mode: str
    runs: int
    dataset_rows: int
    variants: int
    workers: int
    load_stats: StageStats
    simulation_stats: StageStats

    @property
    def total_mean_sec(self) -> float:
        return self.load_stats.mean_sec + self.simulation_stats.mean_sec

    @property
    def rows_per_sec(self) -> float:
        if self.simulation_stats.mean_sec <= 0:
            return 0.0
        return self.dataset_rows / self.simulation_stats.mean_sec

    @property
    def variants_per_sec(self) -> float:
        if self.simulation_stats.mean_sec <= 0:
            return 0.0
        return self.variants / self.simulation_stats.mean_sec


def _stats(values: list[float]) -> StageStats:
    if not values:
        return StageStats(mean_sec=0.0, std_sec=0.0, min_sec=0.0, max_sec=0.0, total_sec=0.0)
    return StageStats(
        mean_sec=statistics.mean(values),
        std_sec=statistics.stdev(values) if len(values) > 1 else 0.0,
        min_sec=min(values),
        max_sec=max(values),
        total_sec=sum(values),
    )


def _run_single_variant(normalized_input, scenario, mode: SimulationMode) -> None:
    RunSimulationUseCase(engine=SimulationEngine()).execute(
        normalized_input,
        scenario,
        include_detail=False,
        use_cache=False,
        mode=mode,
    )


def _run_mode_benchmark(
    *,
    dataset_path: Path,
    scenario,
    mode: SimulationMode,
    runs: int,
    use_grid: bool,
    workers: int,
    project_dir: Path,
) -> BenchmarkModeResult:
    load_use_case = LoadDatasetUseCase()
    normalize_use_case = ValidateAndNormalizeUseCase()

    variants = build_battery_grid(project_dir=project_dir, base_scenario=scenario, use_grid=use_grid)
    load_durations: list[float] = []
    simulation_durations: list[float] = []
    dataset_rows = 0

    for _ in range(runs):
        load_started = time.perf_counter()
        loaded = load_use_case.execute(str(dataset_path))
        if "timestamp" in loaded.dataframe.columns:
            loaded.dataframe["timestamp"] = pd.to_datetime(loaded.dataframe["timestamp"], errors="coerce")
        normalized = normalize_use_case.execute(loaded)
        load_durations.append(time.perf_counter() - load_started)
        dataset_rows = len(normalized.dataframe)

        simulation_started = time.perf_counter()
        if use_grid and len(variants) > 1:
            variant_scenarios = [patch_scenario_for_variant(scenario, variant) for variant in variants]
            if workers > 1:
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    list(executor.map(lambda sc: _run_single_variant(normalized, sc, mode), variant_scenarios))
            else:
                for variant_scenario in variant_scenarios:
                    _run_single_variant(normalized, variant_scenario, mode)
        else:
            _run_single_variant(normalized, scenario, mode)
        simulation_durations.append(time.perf_counter() - simulation_started)

    return BenchmarkModeResult(
        mode=mode.value,
        runs=runs,
        dataset_rows=dataset_rows,
        variants=len(variants),
        workers=max(1, workers),
        load_stats=_stats(load_durations),
        simulation_stats=_stats(simulation_durations),
    )


def _print_mode_result(result: BenchmarkModeResult) -> None:
    total_rows = result.dataset_rows * result.variants
    print("--------------------------------")
    print(f"Benchmark Results ({result.mode})")
    print(f"Dataset rows: {result.dataset_rows:,}")
    print(f"Variants por run: {result.variants}")
    print(f"Rows procesadas por run: {total_rows:,}")
    print(f"Runs: {result.runs}")
    print(f"Carga dataset media: {result.load_stats.mean_sec:.3f} s")
    print(f"Simulación media: {result.simulation_stats.mean_sec:.3f} s")
    print(f"Tiempo total medio: {result.total_mean_sec:.3f} s")
    print(f"Std dev simulación: {result.simulation_stats.std_sec:.3f} s")
    print(f"Min simulación: {result.simulation_stats.min_sec:.3f} s")
    print(f"Max simulación: {result.simulation_stats.max_sec:.3f} s")
    per_1000 = (result.simulation_stats.mean_sec / total_rows * 1000.0) if total_rows else 0.0
    print(f"Tiempo por 1000 filas: {per_1000:.4f} s")
    print(f"Rows/sec: {result.rows_per_sec * result.variants:,.0f}")
    print(f"Runs/sec: {(1.0 / result.simulation_stats.mean_sec) if result.simulation_stats.mean_sec else 0.0:.2f}")
    print(f"Variantes/sec: {result.variants_per_sec:.2f}")
    print("--------------------------------")


def _result_to_json_dict(result: BenchmarkModeResult, timestamp: str) -> dict[str, object]:
    total_rows = result.dataset_rows * result.variants
    return {
        "timestamp": timestamp,
        "mode": result.mode,
        "runs": result.runs,
        "dataset_rows": result.dataset_rows,
        "variants": result.variants,
        "workers": result.workers,
        "rows_processed_per_run": total_rows,
        "load_mean_time_sec": result.load_stats.mean_sec,
        "load_std_sec": result.load_stats.std_sec,
        "simulation_mean_time_sec": result.simulation_stats.mean_sec,
        "simulation_std_sec": result.simulation_stats.std_sec,
        "mean_time_sec": result.total_mean_sec,
        "std_sec": result.simulation_stats.std_sec,
        "rows_per_sec": result.rows_per_sec * result.variants,
        "runs_per_sec": (1.0 / result.simulation_stats.mean_sec) if result.simulation_stats.mean_sec else 0.0,
        "variants_per_sec": result.variants_per_sec,
    }


def benchmark_project(project_dir_arg: str, runs: int = 5, fast: bool = False, use_grid: bool = False, workers: int = 1) -> int:
    project_dir = Path(project_dir_arg).expanduser().resolve()
    if runs <= 0:
        print("Error: --runs debe ser mayor que 0")
        return 2
    if workers <= 0:
        print("Error: --workers debe ser mayor que 0")
        return 2

    try:
        project_config, _, _ = load_project(str(project_dir))
    except FileNotFoundError as exc:
        print(f"Error: {exc}")
        print("Tip: ejecuta primero 'fvbess project init <project_dir>'.")
        return 2

    if not project_config.data_path:
        print("Error: project.json no tiene data_path configurado.")
        return 2

    dataset_path = Path(project_config.data_path).expanduser()
    if not dataset_path.exists():
        print(f"Error: dataset no encontrado en {dataset_path}")
        return 2

    scenario = LoadProjectUseCase().scenario_from_dict(project_config.scenario)
    selected_modes = [SimulationMode.FAST] if fast else [SimulationMode.OPTIMAL, SimulationMode.FAST]

    run_id = generate_run_id()
    run_dir = setup_project_logging(project_dir, run_id)
    context = {
        "benchmark": True,
        "dataset": str(dataset_path),
        "runs": runs,
        "grid_mode": use_grid,
        "workers": workers,
        "forced_no_cache": True,
        "forced_export_detail": False,
    }
    write_environment_metadata(run_dir, context)

    def _execute() -> int:
        logging.info("Starting benchmark run_id=%s dataset=%s modes=%s grid=%s", run_id, dataset_path, [mode.value for mode in selected_modes], use_grid)
        results: list[BenchmarkModeResult] = []
        for mode in selected_modes:
            with timed_block(f"benchmark_{mode.value}"):
                results.append(
                    _run_mode_benchmark(
                        dataset_path=dataset_path,
                        scenario=scenario,
                        mode=mode,
                        runs=runs,
                        use_grid=use_grid,
                        workers=workers,
                        project_dir=project_dir,
                    )
                )

        for result in results:
            _print_mode_result(result)

        if len(results) == 2 and results[1].simulation_stats.mean_sec > 0:
            speedup = results[0].simulation_stats.mean_sec / results[1].simulation_stats.mean_sec
            print(f"Speedup FAST: {speedup:.2f}x")

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        benchmark_dir = project_dir / "benchmark"
        benchmark_dir.mkdir(parents=True, exist_ok=True)
        output_path = benchmark_dir / f"benchmark_{timestamp}.json"

        payload: dict[str, object] = {
            "timestamp": timestamp,
            "project": project_config.name,
            "dataset": str(dataset_path),
            "grid_mode": use_grid,
            "results": [_result_to_json_dict(result, timestamp) for result in results],
        }
        if len(results) == 2 and results[1].simulation_stats.mean_sec > 0:
            payload["speedup_fast_vs_detailed"] = results[0].simulation_stats.mean_sec / results[1].simulation_stats.mean_sec

        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        logging.info("Benchmark finished run_id=%s output=%s", run_id, output_path)
        print(f"Benchmark JSON: {output_path}")
        return 0

    return run_with_crash_report(_execute, project_dir=project_dir, run_id=run_id, context=context)
